const authContent = {
  login: {
    title: "Ingresa a tu cuenta",
    subtitle:
      "Accede con tu correo y contraseña para continuar con tu proceso dentro de Global Imports.",
    email: "correo@globalimports.com",
    button: "Ingresar",
  },
  register: {
    title: "Crea tu cuenta",
    subtitle:
      "Completa tus datos para registrarte y empezar el seguimiento de tu vehiculo.",
    email: "correo@ejemplo.com",
    button: "Registrarme",
  },
};

function resolveApiBaseUrl() {
  const { origin, hostname } = window.location;

  const isPrivateIpv4Address = /^(10\.(?:\d{1,3}\.){2}\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})$/.test(
    hostname
  );

  if (
    hostname === "localhost" ||
    hostname === "127.0.0.1" ||
    hostname === "::1" ||
    isPrivateIpv4Address ||
    hostname === "global-backend-bdbx.onrender.com"
  ) {
    return origin;
  }

  return "https://global-backend-bdbx.onrender.com";
}

function resolveAppPagePath(pageName = "") {
  const normalizedPageName = String(pageName || "").trim().replace(/^\/+/, "");
  return `/${normalizedPageName}`;
}

function isAdministrativeRole(role = "") {
  return ["admin", "manager", "adminUSA", "gerenteUSA", "brokerUSA", "mechanic", "vigilance"].includes(String(role || "").trim());
}

function resolveAuthenticatedLandingPage(role = "") {
  const normalizedRole = String(role || "").trim();
  if (normalizedRole === "mechanic") {
    return resolveAppPagePath("mechanic.html");
  }
  if (normalizedRole === "vigilance") {
    return resolveAppPagePath("vigilance.html");
  }
  return normalizedRole === "brokerUSA"
    ? resolveAppPagePath("admin-tracking.html")
    : resolveAppPagePath("admin.html");
}

function isDirectApiHostCandidate(hostname = "") {
  const normalizedHostname = String(hostname || "").trim().toLowerCase();

  if (!normalizedHostname) {
    return false;
  }

  const isPrivateIpv4Address = /^(10\.(?:\d{1,3}\.){2}\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})$/.test(
    normalizedHostname
  );

  return (
    normalizedHostname === "localhost" ||
    normalizedHostname === "127.0.0.1" ||
    normalizedHostname === "::1" ||
    normalizedHostname === "global-backend-bdbx.onrender.com" ||
    isPrivateIpv4Address
  );
}

function isJsonResponse(response) {
  const contentType = String(response?.headers?.get("content-type") || "").toLowerCase();
  return contentType.includes("application/json");
}

function isProductionApiRequest() {
  const hostname = String(window.location.hostname || "").trim().toLowerCase();
  return !isDirectApiHostCandidate(hostname);
}

function resolveApiBaseUrlCandidates() {
  const { protocol, hostname, port, origin } = window.location;
  const candidates = [];
  const isDirectHost = isDirectApiHostCandidate(hostname);

  function pushCandidate(value) {
    if (!value || candidates.includes(value)) {
      return;
    }

    candidates.push(value);
  }

  if ((protocol === "http:" || protocol === "https:") && isDirectHost) {
    pushCandidate(origin);
  }

  if (hostname && protocol && isDirectHost) {
    pushCandidate(`${protocol}//${hostname}:${port || "10000"}`);
  }

  if (isDirectHost) {
    pushCandidate("http://localhost:10000");
    pushCandidate("http://127.0.0.1:10000");
    pushCandidate("http://192.168.1.95:10000");
  }

  pushCandidate(resolveApiBaseUrl());

  return candidates;
}

async function postJsonWithFallback(path, payload) {
  let lastError = null;

  for (const baseUrl of resolveApiBaseUrlCandidates()) {
    try {
      const response = await fetch(`${baseUrl}${path}`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!isJsonResponse(response)) {
        lastError = new Error("La API respondió con un formato inválido.");
        continue;
      }

      return response;
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError || new Error("No se pudo conectar con la API.");
}

const apiBaseUrl = resolveApiBaseUrl();

const formTitle = document.getElementById("form-title");
const formSubtitle = document.getElementById("form-subtitle");
const nameField = document.getElementById("name-field");
const phoneField = document.getElementById("phone-field");
const nameInput = document.getElementById("name");
const phoneCountryCodeSelect = document.getElementById("phone-country-code");
const phoneInput = document.getElementById("phone");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const togglePasswordButton = document.getElementById("toggle-password");
const submitButton = document.getElementById("submit-button");
const biometricLoginButton = document.getElementById("biometric-login-button");
const biometricLoginHint = document.getElementById("biometric-login-hint");
const loginSubmitRow = document.getElementById("login-submit-row");
const feedbackMessage = document.getElementById("feedback-message");
const loginForm = document.getElementById("login-form");
const signupLink = document.querySelector(".signup-link");
const forgotPasswordButton = document.getElementById("forgot-password-button");
const signupPromptPrefix = document.getElementById("signup-prompt-prefix");
const verificationModal = document.getElementById("verification-modal");
const verificationForm = document.getElementById("verification-form");
const verificationCodeInput = document.getElementById("verification-code");
const verificationFeedback = document.getElementById("verification-feedback");
const verificationSubmitButton = document.getElementById("verification-submit-button");
const verificationResendButton = document.getElementById("verification-resend-button");
const verificationCopy = document.getElementById("verification-copy");
const forgotPasswordModal = document.getElementById("forgot-password-modal");
const forgotPasswordForm = document.getElementById("forgot-password-form");
const forgotPasswordEmailInput = document.getElementById("forgot-password-email");
const forgotPasswordFeedback = document.getElementById("forgot-password-feedback");
const forgotPasswordSubmitButton = document.getElementById("forgot-password-submit");
const logoSymbol = document.getElementById("logo-symbol");
const logoWordmark = document.getElementById("logo-wordmark");
const brandFallback = document.getElementById("brand-fallback");
const utilityRow = document.querySelector(".utility-row");
const VERIFICATION_RESEND_COOLDOWN_SECONDS = 30;
const verificationResendDefaultText =
  String(verificationResendButton?.textContent || "").trim() || "Reenviar código";

let authMode = "login";
let pendingVerificationPayload = null;
let verificationResendSecondsLeft = 0;
let verificationResendIntervalId = null;
let biometricRequestId = 0;
let biometricStatus = {
  supported: false,
  available: false,
  enrolledSession: false,
  biometryType: "biometric",
};

const COUNTRY_CODES = [
  ["Colombia", "+57"], ["Argentina", "+54"], ["Bolivia", "+591"], ["Brasil", "+55"], ["Chile", "+56"], ["Ecuador", "+593"],
  ["Paraguay", "+595"], ["Peru", "+51"], ["Uruguay", "+598"], ["Venezuela", "+58"], ["Mexico", "+52"], ["Estados Unidos", "+1"],
  ["Canada", "+1"], ["Costa Rica", "+506"], ["Cuba", "+53"], ["El Salvador", "+503"], ["Guatemala", "+502"], ["Honduras", "+504"],
  ["Nicaragua", "+505"], ["Panama", "+507"], ["Republica Dominicana", "+1"], ["Puerto Rico", "+1"], ["España", "+34"], ["Portugal", "+351"],
  ["Francia", "+33"], ["Alemania", "+49"], ["Italia", "+39"], ["Reino Unido", "+44"], ["Irlanda", "+353"], ["Paises Bajos", "+31"],
  ["Belgica", "+32"], ["Suiza", "+41"], ["Austria", "+43"], ["Suecia", "+46"], ["Noruega", "+47"], ["Dinamarca", "+45"],
  ["Finlandia", "+358"], ["Polonia", "+48"], ["Grecia", "+30"], ["Turquia", "+90"], ["Rusia", "+7"], ["Ucrania", "+380"],
  ["Marruecos", "+212"], ["Egipto", "+20"], ["Sudafrica", "+27"], ["Nigeria", "+234"], ["Kenia", "+254"], ["India", "+91"],
  ["Pakistan", "+92"], ["China", "+86"], ["Japon", "+81"], ["Corea del Sur", "+82"], ["Indonesia", "+62"], ["Filipinas", "+63"],
  ["Vietnam", "+84"], ["Tailandia", "+66"], ["Malasia", "+60"], ["Singapur", "+65"], ["Australia", "+61"], ["Nueva Zelanda", "+64"],
  ["Emiratos Arabes Unidos", "+971"], ["Arabia Saudita", "+966"], ["Qatar", "+974"], ["Israel", "+972"]
];

function populateCountryCodes() {
  if (!phoneCountryCodeSelect) {
    return;
  }

  const defaultCode = "+57";
  phoneCountryCodeSelect.innerHTML = [
    `<option value="${defaultCode}" data-current="true" selected>${defaultCode}</option>`,
    ...COUNTRY_CODES.map(([country, code]) => `<option value="${code}">${code} ${country}</option>`),
  ].join("");
}

function bindCountryCodeSelector() {
  if (!phoneCountryCodeSelect) {
    return;
  }

  phoneCountryCodeSelect.addEventListener("change", () => {
    const currentOption = phoneCountryCodeSelect.querySelector("option[data-current='true']");
    const selectedCode = String(phoneCountryCodeSelect.value || "+57").trim();

    if (currentOption) {
      currentOption.value = selectedCode;
      currentOption.textContent = selectedCode;
    }

    // Keep the control compact after choosing: closed state shows only code.
    phoneCountryCodeSelect.selectedIndex = 0;
  });
}

function clearAuthState() {
  localStorage.removeItem("globalAppToken");
  localStorage.removeItem("globalAppRole");
  sessionStorage.removeItem("globalAppToken");
  sessionStorage.removeItem("globalAppRole");

  postNativeBiometricMessage("clear-session").then((response) => {
    biometricStatus.enrolledSession = Boolean(response?.enrolledSession);
    updateBiometricButtonVisibility();
  }).catch(() => {
    biometricStatus.enrolledSession = false;
    updateBiometricButtonVisibility();
  });
}

function getBiometryLabel(type = "biometric") {
  if (type === "faceid") {
    return "Face ID";
  }

  if (type === "touchid") {
    return "Touch ID";
  }

  return "biometría";
}

function setBiometricHint(message = "") {
  if (!biometricLoginHint) {
    return;
  }

  const normalizedMessage = String(message || "").trim();
  biometricLoginHint.textContent = normalizedMessage;
  biometricLoginHint.hidden = !normalizedMessage;
}

function updateBiometricButtonVisibility() {
  if (!biometricLoginButton || !loginSubmitRow) {
    return;
  }

  const shouldShow = authMode === "login" && biometricStatus.available && biometricStatus.enrolledSession;
  biometricLoginButton.hidden = !shouldShow;
  loginSubmitRow.classList.toggle("has-biometric", shouldShow);

  if (!shouldShow) {
    setBiometricHint("");
    return;
  }

  const biometryLabel = getBiometryLabel(biometricStatus.biometryType);
  biometricLoginButton.setAttribute("aria-label", `Ingresar con ${biometryLabel}`);
  biometricLoginButton.setAttribute("title", `Ingresar con ${biometryLabel}`);
  setBiometricHint(`Usa ${biometryLabel} para entrar más rápido.`);
}

function postNativeBiometricMessage(command, payload = {}) {
  const handler = window.webkit?.messageHandlers?.globalImportsBiometric;

  if (!handler?.postMessage) {
    return Promise.resolve({
      ok: false,
      error: "Biometría no disponible en este dispositivo.",
    });
  }

  biometricRequestId += 1;
  const requestId = `biometric-${biometricRequestId}`;

  return new Promise((resolve) => {
    const eventName = `globalimports:biometric-response:${requestId}`;
    const timeoutId = window.setTimeout(() => {
      window.removeEventListener(eventName, handleResponse);
      resolve({
        ok: false,
        error: "La respuesta biométrica tardó demasiado.",
      });
    }, 12000);

    function handleResponse(event) {
      window.clearTimeout(timeoutId);
      window.removeEventListener(eventName, handleResponse);
      resolve(event.detail || { ok: false, error: "No recibimos una respuesta válida." });
    }

    window.addEventListener(eventName, handleResponse, { once: true });
    handler.postMessage({
      requestId,
      command,
      ...payload,
    });
  });
}

async function refreshBiometricStatus() {
  const response = await postNativeBiometricMessage("status");

  biometricStatus = {
    supported: Boolean(response?.supported),
    available: Boolean(response?.available),
    enrolledSession: Boolean(response?.enrolledSession),
    biometryType: String(response?.biometryType || "biometric").toLowerCase(),
  };

  updateBiometricButtonVisibility();
}

async function storeBiometricSession(token, role) {
  if (!token || !biometricStatus.available) {
    return;
  }

  const response = await postNativeBiometricMessage("store-session", {
    token,
    role: role || "client",
  });

  biometricStatus.enrolledSession = Boolean(response?.enrolledSession);
  updateBiometricButtonVisibility();

  if (!response?.ok) {
    throw new Error(response?.error || "No pudimos activar el acceso biométrico.");
  }
}

function persistAuthenticatedSession(token, role) {
  localStorage.setItem("globalAppToken", token);

  if (role) {
    localStorage.setItem("globalAppRole", role);
    sessionStorage.setItem("globalAppRole", role);
  } else {
    localStorage.removeItem("globalAppRole");
    sessionStorage.removeItem("globalAppRole");
  }

  sessionStorage.setItem("globalAppToken", token);
}

async function completeAuthenticatedSession({ token, role, user }) {
  const resolvedRole = user?.role || role || "";

  persistAuthenticatedSession(token, resolvedRole);

  try {
    await storeBiometricSession(token, resolvedRole);
  } catch (error) {
    setFeedback(error.message || "No pudimos activar el acceso biométrico.", "error");
  }

  setFeedback("Acceso correcto. Redirigiendo...", "success");

  if (isAdministrativeRole(resolvedRole)) {
    window.setTimeout(() => {
      window.location.href = resolveAuthenticatedLandingPage(resolvedRole);
    }, 250);
    return;
  }

  if (!resolvedRole) {
    redirectAuthenticatedUser().catch(() => {
      clearAuthState();
    });
    return;
  }

  window.setTimeout(() => {
    window.location.href = resolveAppPagePath("client.html");
  }, 250);
}

async function signInWithBiometrics() {
  if (!biometricLoginButton) {
    return;
  }

  const biometryLabel = getBiometryLabel(biometricStatus.biometryType);
  biometricLoginButton.disabled = true;
  setFeedback(`Validando acceso con ${biometryLabel}...`);

  try {
    const response = await postNativeBiometricMessage("authenticate");

    if (!response?.ok || !response?.token) {
      throw new Error(response?.error || `No pudimos completar el acceso con ${biometryLabel}.`);
    }

    await completeAuthenticatedSession({
      token: response.token,
      role: response.role || "client",
    });
  } catch (error) {
    setFeedback(error.message || `No pudimos completar el acceso con ${biometryLabel}.`, "error");
    await refreshBiometricStatus();
  } finally {
    biometricLoginButton.disabled = false;
  }
}

async function redirectAuthenticatedUser() {
  const currentUrl = new URL(window.location.href);

  if (currentUrl.searchParams.get("logout") === "1") {
    clearAuthState();
    currentUrl.searchParams.delete("logout");
    currentUrl.searchParams.delete("t");
    window.history.replaceState({}, document.title, currentUrl.pathname);
    return;
  }

  const token = localStorage.getItem("globalAppToken");
  const role = localStorage.getItem("globalAppRole");

  if (!token) {
    return;
  }

  try {
    const response = await fetch(`${apiBaseUrl}/api/auth/me`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error("Stored session is no longer valid");
    }

    const data = await response.json();
    const resolvedRole = data.user?.role || role;
    const resolvedToken = data.token || token;

    if (!resolvedRole) {
      throw new Error("Stored session is missing role information");
    }

    persistAuthenticatedSession(resolvedToken, resolvedRole);

    if (isAdministrativeRole(resolvedRole)) {
      window.location.replace(resolveAuthenticatedLandingPage(resolvedRole));
      return;
    }

    window.location.replace(resolveAppPagePath("client.html"));
    return;
  } catch {
    clearAuthState();
  }

}

function setFeedback(message, type = "") {
  if (!feedbackMessage) {
    return;
  }

  feedbackMessage.textContent = message;
  feedbackMessage.className = `feedback${type ? ` ${type}` : ""}`;
}

function setVerificationFeedback(message, type = "") {
  if (!verificationFeedback) {
    return;
  }

  verificationFeedback.textContent = message;
  verificationFeedback.className = `feedback${type ? ` ${type}` : ""}`;
}

function setForgotPasswordFeedback(message, type = "") {
  if (!forgotPasswordFeedback) {
    return;
  }

  forgotPasswordFeedback.textContent = message;
  forgotPasswordFeedback.className = `feedback${type ? ` ${type}` : ""}`;
}

function clearVerificationResendCooldown() {
  if (!verificationResendIntervalId) {
    return;
  }

  window.clearInterval(verificationResendIntervalId);
  verificationResendIntervalId = null;
}

function renderVerificationResendButton() {
  if (!verificationResendButton) {
    return;
  }

  if (!pendingVerificationPayload?.email) {
    verificationResendButton.disabled = true;
    verificationResendButton.textContent = verificationResendDefaultText;
    return;
  }

  if (verificationResendSecondsLeft > 0) {
    verificationResendButton.disabled = true;
    verificationResendButton.textContent = `Reenviar en ${verificationResendSecondsLeft}s`;
    return;
  }

  verificationResendButton.disabled = false;
  verificationResendButton.textContent = verificationResendDefaultText;
}

function startVerificationResendCooldown(seconds = VERIFICATION_RESEND_COOLDOWN_SECONDS) {
  verificationResendSecondsLeft = Math.max(0, Number.parseInt(seconds, 10) || 0);
  clearVerificationResendCooldown();
  renderVerificationResendButton();

  if (verificationResendSecondsLeft <= 0) {
    return;
  }

  verificationResendIntervalId = window.setInterval(() => {
    verificationResendSecondsLeft = Math.max(0, verificationResendSecondsLeft - 1);
    renderVerificationResendButton();

    if (verificationResendSecondsLeft <= 0) {
      clearVerificationResendCooldown();
    }
  }, 1000);
}

function openVerificationModal(email) {
  if (!verificationModal) {
    return;
  }

  if (verificationCopy) {
    verificationCopy.textContent = `Te enviamos un código de 6 dígitos a ${email}. Escríbelo para activar tu cuenta.`;
  }

  verificationCodeInput.value = "";
  setVerificationFeedback("Revisa tu bandeja de entrada y escribe el código.");
  startVerificationResendCooldown();
  verificationModal.hidden = false;
  document.body.classList.add("modal-open");
  window.setTimeout(() => verificationCodeInput?.focus(), 50);
}

function closeVerificationModal() {
  if (!verificationModal) {
    return;
  }

  verificationModal.hidden = true;
  document.body.classList.remove("modal-open");
}

function openPasswordResetModal() {
  if (!forgotPasswordModal) {
    return;
  }

  forgotPasswordEmailInput.value = String(emailInput?.value || "").trim();
  setForgotPasswordFeedback("Te enviaremos un enlace seguro a tu correo.");
  forgotPasswordModal.hidden = false;
  document.body.classList.add("modal-open");
  window.setTimeout(() => forgotPasswordEmailInput?.focus(), 50);
}

function closePasswordResetModal() {
  if (!forgotPasswordModal) {
    return;
  }

  forgotPasswordModal.hidden = true;
  document.body.classList.remove("modal-open");
}

function handleQueryStateMessages() {
  const currentUrl = new URL(window.location.href);
  const resetStatus = currentUrl.searchParams.get("reset");

  if (resetStatus === "success") {
    setFeedback("Tu contraseña fue actualizada. Ya puedes ingresar con la nueva clave.", "success");
    currentUrl.searchParams.delete("reset");
    window.history.replaceState({}, document.title, currentUrl.pathname);
  }
}

function applyAuthContent() {
  const content = authContent[authMode];
  const isRegisterMode = authMode === "register";

  formTitle.textContent = content.title;
  formSubtitle.textContent = content.subtitle;
  emailInput.placeholder = content.email;
  submitButton.textContent = content.button;

  if (nameField) {
    nameField.hidden = !isRegisterMode;
    nameField.style.display = isRegisterMode ? "" : "none";
  }

  if (phoneField) {
    phoneField.hidden = !isRegisterMode;
    phoneField.style.display = isRegisterMode ? "" : "none";
  }

  if (nameInput) {
    nameInput.required = isRegisterMode;
    nameInput.disabled = !isRegisterMode;
  }

  if (phoneInput) {
    phoneInput.required = false;
    phoneInput.disabled = !isRegisterMode;
  }

  if (phoneCountryCodeSelect) {
    phoneCountryCodeSelect.disabled = !isRegisterMode;
  }

  if (utilityRow) {
    utilityRow.style.display = isRegisterMode ? "none" : "flex";
  }

  if (signupLink) {
    signupLink.textContent = isRegisterMode ? "Ya tengo cuenta" : "Regístrate ahora";
  }

  if (signupPromptPrefix) {
    signupPromptPrefix.hidden = isRegisterMode;
  }

  updateBiometricButtonVisibility();
  setFeedback(isRegisterMode ? "Completa los campos para crear tu cuenta." : "Ingresa tus credenciales para continuar.");
}

function toggleAuthMode() {
  authMode = authMode === "login" ? "register" : "login";
  closeVerificationModal();
  closePasswordResetModal();
  applyAuthContent();
}

async function updateApiStatus() {
  if (!document.getElementById("api-status")) {
    return;
  }

  const apiStatus = document.getElementById("api-status");

  try {
    const response = await fetch(`${apiBaseUrl}/api/health`);
    const data = await response.json();
    const connected = data.database === "connected";

    apiStatus.textContent = connected ? "API lista" : "API con DB pendiente";
    apiStatus.style.color = connected ? "#0c8b63" : "#c07d16";
  } catch (error) {
    apiStatus.textContent = "API no disponible";
    apiStatus.style.color = "#c54414";
  }
}

function hideMissingAsset(element) {
  if (!element) {
    return;
  }

  element.classList.add("hidden-asset");

  if (brandFallback) {
    brandFallback.style.display = "block";
  }
}

if (logoSymbol) {
  logoSymbol.addEventListener("error", () => hideMissingAsset(logoSymbol));
}

if (logoWordmark) {
  logoWordmark.addEventListener("error", () => hideMissingAsset(logoWordmark));
}

if (togglePasswordButton && passwordInput) {
  togglePasswordButton.addEventListener("click", () => {
    const isVisible = passwordInput.type === "text";

    passwordInput.type = isVisible ? "password" : "text";
    togglePasswordButton.setAttribute("aria-pressed", String(!isVisible));
    togglePasswordButton.setAttribute(
      "aria-label",
      isVisible ? "Mostrar contraseña" : "Ocultar contraseña"
    );
    togglePasswordButton.setAttribute(
      "title",
      isVisible ? "Mostrar contraseña" : "Ocultar contraseña"
    );
  });
}

redirectAuthenticatedUser().catch(() => {
  clearAuthState();
});

refreshBiometricStatus().catch(() => {
  biometricStatus = {
    supported: false,
    available: false,
    enrolledSession: false,
    biometryType: "biometric",
  };
  updateBiometricButtonVisibility();
});

window.addEventListener("load", () => {
  document.body.classList.add("motion-ready");
});

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const formData = new FormData(loginForm);
  const rawPhone = String(formData.get("phone") || "").trim();
  const selectedCode = String(formData.get("phoneCountryCode") || "+57").trim();
  const composedPhone = rawPhone
    ? (rawPhone.startsWith("+") ? rawPhone : `${selectedCode} ${rawPhone}`.trim())
    : "";
  const payload = authMode === "register"
    ? {
        name: String(formData.get("name") || "").trim(),
        email: String(formData.get("email") || "").trim(),
        password: String(formData.get("password") || ""),
        ...(composedPhone ? { phone: composedPhone } : {}),
      }
    : {
        email: formData.get("email"),
        password: formData.get("password"),
      };

  submitButton.disabled = true;
  setFeedback(authMode === "register" ? "Preparando verificación..." : "Validando acceso...", "");

  try {
    const authPath = authMode === "register" ? "/api/auth/register" : "/api/auth/login";
    const response = await postJsonWithFallback(authPath, payload);

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "No se pudo iniciar sesión.");
    }

    if (authMode === "register") {
      pendingVerificationPayload = payload;
      setFeedback("Te enviamos un código de verificación a tu correo.", "success");
      openVerificationModal(payload.email);
      return;
    }

    await completeAuthenticatedSession({
      token: data.token,
      role: data.user?.role || "client",
      user: data.user,
    });
  } catch (error) {
    const errorMessage = error?.message === "Failed to fetch"
      ? isProductionApiRequest()
        ? "No pudimos conectar con el servidor. Entra en https://globalimports.app (sin www) o prueba de nuevo en unos segundos."
        : "No pudimos conectar con la API local. Verifica que el servidor siga corriendo en el puerto 10000."
      : error.message;
    setFeedback(errorMessage, "error");
  } finally {
    submitButton.disabled = false;
  }
});

if (verificationForm) {
  verificationForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (!pendingVerificationPayload?.email) {
      setVerificationFeedback("No hay una verificación pendiente. Vuelve a registrarte.", "error");
      return;
    }

    const code = String(verificationCodeInput?.value || "").replace(/\D/g, "").slice(0, 6);

    if (code.length !== 6) {
      setVerificationFeedback("Ingresa un código válido de 6 dígitos.", "error");
      return;
    }

    verificationSubmitButton.disabled = true;
    setVerificationFeedback("Verificando código...");

    try {
      const response = await postJsonWithFallback("/api/auth/register/verify", {
        email: pendingVerificationPayload.email,
        code,
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "No se pudo verificar el código.");
      }

      localStorage.setItem("globalAppToken", data.token);
      localStorage.setItem("globalAppRole", data.user.role);
      sessionStorage.setItem("globalAppToken", data.token);
      sessionStorage.setItem("globalAppRole", data.user.role);

      setVerificationFeedback("Cuenta verificada correctamente. Redirigiendo...", "success");
      pendingVerificationPayload = null;
      verificationResendSecondsLeft = 0;
      clearVerificationResendCooldown();
      renderVerificationResendButton();

      window.setTimeout(() => {
        window.location.href = resolveAppPagePath("client.html");
      }, 300);
    } catch (error) {
      setVerificationFeedback(error.message, "error");
    } finally {
      verificationSubmitButton.disabled = false;
    }
  });
}

if (verificationResendButton) {
  renderVerificationResendButton();

  verificationResendButton.addEventListener("click", async () => {
    if (!pendingVerificationPayload) {
      setVerificationFeedback("No hay una verificación pendiente.", "error");
      return;
    }

    verificationResendButton.disabled = true;
    setVerificationFeedback("Reenviando código...");

    try {
      const response = await postJsonWithFallback("/api/auth/register", pendingVerificationPayload);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "No se pudo reenviar el código.");
      }

      setVerificationFeedback("Código reenviado correctamente.", "success");
      startVerificationResendCooldown();
    } catch (error) {
      setVerificationFeedback(error.message, "error");
      renderVerificationResendButton();
    }
  });
}

document.querySelectorAll("[data-close-verification-modal]").forEach((element) => {
  element.addEventListener("click", closeVerificationModal);
});

document.querySelectorAll("[data-close-password-reset-modal]").forEach((element) => {
  element.addEventListener("click", closePasswordResetModal);
});

if (forgotPasswordButton) {
  forgotPasswordButton.addEventListener("click", openPasswordResetModal);
}

if (forgotPasswordForm) {
  forgotPasswordForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const email = String(forgotPasswordEmailInput?.value || "").trim();

    if (!email) {
      setForgotPasswordFeedback("Debes escribir tu correo registrado.", "error");
      return;
    }

    forgotPasswordSubmitButton.disabled = true;
    setForgotPasswordFeedback("Enviando enlace de recuperación...");

    try {
      const response = await postJsonWithFallback("/api/auth/forgot-password", { email });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "No se pudo iniciar la recuperación.");
      }

      setForgotPasswordFeedback(data.message || "Revisa tu correo para continuar.", "success");
      window.setTimeout(() => {
        closePasswordResetModal();
      }, 1200);
    } catch (error) {
      setForgotPasswordFeedback(error.message, "error");
    } finally {
      forgotPasswordSubmitButton.disabled = false;
    }
  });
}

biometricLoginButton?.addEventListener("click", () => {
  signInWithBiometrics().catch((error) => {
    setFeedback(error.message || "No pudimos ingresar con biometría.", "error");
  });
});

applyAuthContent();
populateCountryCodes();
bindCountryCodeSelector();
updateApiStatus();
handleQueryStateMessages();

if (signupLink) {
  signupLink.addEventListener("click", toggleAuthMode);
}