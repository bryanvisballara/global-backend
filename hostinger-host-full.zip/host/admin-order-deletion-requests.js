(() => {
const {
  attachLogout,
  canCreateAdministrativeUsers,
  fetchJson,
  formatDate,
  formatDateTimeInBogota,
  loadAdminSession,
  renderEmptyState,
  requireAdminAccess,
  setFeedback,
} = window.AdminApp;

if (requireAdminAccess()) {
  attachLogout();

  const requestsList = document.getElementById("order-deletion-requests-list");
  const requestsCount = document.getElementById("deletion-requests-count");
  const feedback = document.getElementById("deletion-requests-feedback");
  const pendingApprovalIntents = new Map();
  const APPROVAL_INTENT_WINDOW_MS = 7000;

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function buildVehicleLabel(order) {
    return [order?.vehicle?.brand, order?.vehicle?.model, order?.vehicle?.version].filter(Boolean).join(" ") || "Vehículo sin datos";
  }

  function buildClientLabel(order) {
    if (order?.client && typeof order.client === "object") {
      return order.client.name || order.client.email || "Sin cliente";
    }

    return "Sin cliente";
  }

  function buildRequesterLabel(request) {
    if (request?.requestedBy && typeof request.requestedBy === "object") {
      return request.requestedBy.name || request.requestedBy.email || "Administrador";
    }

    return "Administrador";
  }

  function renderOrderRequestCard(order) {
    const request = order.deletionRequest || {};
    const requester = buildRequesterLabel(request);

    return `
      <article class="request-card">
        <div class="request-card-top">
          <div>
            <p class="section-tag">Solicitud de pedido</p>
            <h2>${escapeHtml(buildVehicleLabel(order))}</h2>
          </div>
          <strong>${escapeHtml(order.trackingNumber || "Sin tracking")}</strong>
        </div>

        <div class="request-specs">
          <div><span>Cliente</span><strong>${escapeHtml(buildClientLabel(order))}</strong></div>
          <div><span>VIN</span><strong>${escapeHtml(order?.vehicle?.vin || "Pendiente")}</strong></div>
          <div><span>Destino</span><strong>${escapeHtml(order?.vehicle?.destination || "Sin destino")}</strong></div>
          <div><span>Creado</span><strong>${escapeHtml(formatDate(order.createdAt))}</strong></div>
        </div>

        <div class="request-contact-grid">
          <div><span>Solicitado por</span><strong>${escapeHtml(requester)}</strong></div>
          <div><span>Rol</span><strong>${escapeHtml(request.requestedByRole || "-")}</strong></div>
          <div><span>Fecha solicitud</span><strong>${escapeHtml(formatDateTimeInBogota(request.requestedAt))}</strong></div>
          <div><span>Estado actual</span><strong>${escapeHtml(order.status || "active")}</strong></div>
        </div>

        <div class="request-note-box">
          <span>Motivo</span>
          <p>${escapeHtml(request.reason || "Sin motivo")}</p>
        </div>

        <div class="request-card-actions">
          <button class="primary-button" type="button" data-request-type="order" data-review-order-id="${escapeHtml(order._id || order.id || "")}" data-action="approve">Aprobar y eliminar</button>
          <button class="secondary-button is-danger" type="button" data-request-type="order" data-review-order-id="${escapeHtml(order._id || order.id || "")}" data-action="reject">Rechazar</button>
        </div>
      </article>
    `;
  }

  function renderTrackingEventRequestCard(entry) {
    const request = entry.deletionRequest || {};
    const requester = buildRequesterLabel(request);

    return `
      <article class="request-card">
        <div class="request-card-top">
          <div>
            <p class="section-tag">Solicitud de evento</p>
            <h2>${escapeHtml(buildVehicleLabel(entry))}</h2>
          </div>
          <strong>${escapeHtml(entry.trackingNumber || "Sin tracking")}</strong>
        </div>

        <div class="request-specs">
          <div><span>Cliente</span><strong>${escapeHtml(buildClientLabel(entry))}</strong></div>
          <div><span>Etapa</span><strong>${escapeHtml(`${entry.stateCode || "-"} · ${entry.stateLabel || "Estado"}`)}</strong></div>
          <div><span>Evento</span><strong>${escapeHtml(entry.eventTitle || "Evento sin título")}</strong></div>
          <div><span>Ubicación</span><strong>${escapeHtml(entry.eventLocation || "Sin ubicación")}</strong></div>
        </div>

        <div class="request-contact-grid">
          <div><span>Solicitado por</span><strong>${escapeHtml(requester)}</strong></div>
          <div><span>Rol</span><strong>${escapeHtml(request.requestedByRole || "-")}</strong></div>
          <div><span>Fecha solicitud</span><strong>${escapeHtml(formatDateTimeInBogota(request.requestedAt))}</strong></div>
          <div><span>Última actualización</span><strong>${escapeHtml(formatDateTimeInBogota(entry.eventUpdatedAt || entry.eventCreatedAt))}</strong></div>
        </div>

        <div class="request-note-box">
          <span>Descripción del evento</span>
          <p>${escapeHtml(entry.eventNotes || "Sin descripción")}</p>
        </div>

        <div class="request-note-box request-note-box-secondary">
          <span>Motivo de la solicitud</span>
          <p>${escapeHtml(request.reason || "Sin motivo")}</p>
        </div>

        <div class="request-card-actions">
          <button class="primary-button" type="button" data-request-type="tracking-event" data-review-order-id="${escapeHtml(entry.orderId || "")}" data-review-event-id="${escapeHtml(entry.eventId || "")}" data-action="approve">Aprobar y borrar evento</button>
          <button class="secondary-button is-danger" type="button" data-request-type="tracking-event" data-review-order-id="${escapeHtml(entry.orderId || "")}" data-review-event-id="${escapeHtml(entry.eventId || "")}" data-action="reject">Rechazar</button>
        </div>
      </article>
    `;
  }

  function renderRequests(entries) {
    requestsCount.textContent = String(entries.length);

    if (!entries.length) {
      renderEmptyState(requestsList, "No hay solicitudes de eliminación pendientes.");
      return;
    }

    requestsList.innerHTML = entries.map((entry) => (
      entry?.type === "tracking-event"
        ? renderTrackingEventRequestCard(entry)
        : renderOrderRequestCard(entry)
    )).join("");
  }

  function getActionButtonFromEvent(event) {
    const target = event?.target;

    if (target instanceof Element) {
      return target.closest("[data-review-order-id]");
    }

    if (target?.parentElement instanceof Element) {
      return target.parentElement.closest("[data-review-order-id]");
    }

    return null;
  }

  function consumeApprovalIntent(key) {
    const expiry = pendingApprovalIntents.get(key);

    if (!expiry) {
      return false;
    }

    if (Date.now() > expiry) {
      pendingApprovalIntents.delete(key);
      return false;
    }

    pendingApprovalIntents.delete(key);
    return true;
  }

  function rememberApprovalIntent(key) {
    pendingApprovalIntents.set(key, Date.now() + APPROVAL_INTENT_WINDOW_MS);
  }

  function confirmApprovalWithFallback({ message, key, buttonText }) {
    if (consumeApprovalIntent(key)) {
      return true;
    }

    try {
      if (typeof window.confirm === "function" && window.confirm(message) === true) {
        return true;
      }
    } catch (error) {
      // Ignore and use explicit double-tap fallback below.
    }

    rememberApprovalIntent(key);
    setFeedback(
      feedback,
      `Presiona nuevamente \"${buttonText}\" para confirmar esta acción.`
    );
    return false;
  }

  async function loadDeletionRequestsPage() {
    const user = await loadAdminSession();

    if (!canCreateAdministrativeUsers(user?.role)) {
      window.location.replace("/admin.html");
      return;
    }

    const data = await fetchJson(`/api/admin/orders/deletion-requests?ts=${Date.now()}`);
    const pendingOrders = Array.isArray(data?.orders) ? data.orders.map((order) => ({ ...order, type: "order" })) : [];
    const pendingEventRequests = Array.isArray(data?.trackingEventRequests) ? data.trackingEventRequests : [];
    const pendingEntries = pendingOrders.concat(pendingEventRequests).sort((left, right) => {
      const leftTime = new Date(left?.deletionRequest?.requestedAt || left?.createdAt || 0).getTime();
      const rightTime = new Date(right?.deletionRequest?.requestedAt || right?.createdAt || 0).getTime();
      return rightTime - leftTime;
    });

    renderRequests(pendingEntries);
    setFeedback(feedback, "");
  }

  requestsList?.addEventListener("click", async (event) => {
    const actionButton = getActionButtonFromEvent(event);

    if (!actionButton) {
      return;
    }

    const orderId = String(actionButton.dataset.reviewOrderId || "").trim();
    const eventId = String(actionButton.dataset.reviewEventId || "").trim();
    const requestType = String(actionButton.dataset.requestType || "order").trim();
    const action = String(actionButton.dataset.action || "").trim();

    if (!orderId || !action) {
      return;
    }

    let rejectionReason = "";
    const isTrackingEventRequest = requestType === "tracking-event" && eventId;
    const requestKey = `${requestType}:${orderId}:${eventId || "-"}`;

    if (action === "approve") {
      if (!confirmApprovalWithFallback({
        message: isTrackingEventRequest
          ? "¿Seguro que deseas aprobar esta solicitud y eliminar el evento?"
          : "¿Seguro que deseas aprobar esta solicitud y eliminar el pedido?",
        key: requestKey,
        buttonText: (actionButton.textContent || "Aprobar").trim() || "Aprobar",
      })) {
        return;
      }
    } else {
      rejectionReason = String(window.prompt("Motivo del rechazo (opcional):", "") || "").trim();
    }

    actionButton.disabled = true;
    setFeedback(feedback, action === "approve"
      ? (isTrackingEventRequest ? "Eliminando evento..." : "Eliminando pedido...")
      : "Rechazando solicitud...");

    try {
      const endpoint = isTrackingEventRequest
        ? `/api/admin/orders/${orderId}/tracking-events/${eventId}/deletion-request`
        : `/api/admin/orders/${orderId}/deletion-request`;

      await fetchJson(endpoint, {
        method: "PATCH",
        body: JSON.stringify({ action, rejectionReason }),
      });

      setFeedback(
        feedback,
        action === "approve"
          ? (isTrackingEventRequest ? "Evento eliminado correctamente." : "Pedido eliminado correctamente.")
          : "Solicitud rechazada correctamente.",
        "success"
      );
      await loadDeletionRequestsPage();
    } catch (error) {
      setFeedback(feedback, error.message, "error");
    } finally {
      actionButton.disabled = false;
    }
  });

  loadDeletionRequestsPage().catch((error) => {
    renderEmptyState(requestsList, error.message);
    setFeedback(feedback, error.message, "error");
  });
}
})();
