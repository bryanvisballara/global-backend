const GLOBAL_HERO_GAME_ENABLED = true;

function resolveApiBaseUrl() {
  const { origin, hostname } = window.location;

  const isPrivateIpv4Address = /^(10\.(?:\d{1,3}\.){2}\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})$/.test(
    hostname
  );

  if (
    hostname === "localhost" ||
    hostname === "127.0.0.1" ||
    hostname === "::1" ||
    isPrivateIpv4Address ||
    hostname === "global-backend-bdbx.onrender.com"
  ) {
    return origin;
  }

  return "https://global-backend-bdbx.onrender.com";
}

const apiBaseUrl = resolveApiBaseUrl();
const state = {
  user: null,
  orders: [],
  maintenance: [],
  maintenanceVehicles: [],
  notifications: [],
  activeView: "home",
  registeredPushToken: "",
  registeredPushSignature: "",
  feedPosts: [],
  feedOffset: 0,
  feedHasMore: true,
  isFetchingFeed: false,
  isRefreshingFeed: false,
  selectedLikesPostId: "",
  selectedCommentLikesId: "",
  selectedCommentsPostId: "",
  commentDraft: "",
  feedActionMessage: "",
  pendingFeedLikeIds: new Set(),
  pendingFeedCommentLikeKeys: new Set(),
  virtualDealershipVehicles: [],
  virtualDealershipVisibleCount: 0,
  virtualDealershipExpandedDetails: new Set(),
  maintenanceExpandedDetails: new Set(),
};

const FEED_PAGE_SIZE = 5;
const VIRTUAL_DEALERSHIP_BATCH_SIZE = 3;
const PULL_REFRESH_THRESHOLD = 78;
const TRACKING_HISTORY_MAX_ITEMS = 12;
const TRACKING_PAGE_VERSION = "20260416-clientevents04";
const CLIENT_IMAGE_CACHE_SW_URL = "/sw.js";
const pendingFeedLikeIdsRef = state.pendingFeedLikeIds;
const pendingFeedCommentLikeKeysRef = state.pendingFeedCommentLikeKeys;

function buildTrackingPageUrl(trackingNumber = "") {
  const trackingUrl = new URL("/client-tracking.html", window.location.origin);
  trackingUrl.searchParams.set("v", TRACKING_PAGE_VERSION);

  if (trackingNumber) {
    trackingUrl.searchParams.set("tracking", String(trackingNumber).toUpperCase().trim());
  }

  return trackingUrl;
}

function registerClientImageCacheServiceWorker() {
  if (!("serviceWorker" in navigator)) {
    return;
  }

  window.addEventListener("load", () => {
    navigator.serviceWorker.register(CLIENT_IMAGE_CACHE_SW_URL).catch((error) => {
      console.warn("No se pudo registrar el cache de imagenes del cliente.", error);
    });
  });
}

function installZoomGuards() {
  document.documentElement.style.touchAction = "manipulation";
  document.body?.style?.setProperty("touch-action", "manipulation");

  const preventGesture = (event) => {
    event.preventDefault();
  };

  ["gesturestart", "gesturechange", "gestureend", "dblclick"].forEach((eventName) => {
    document.addEventListener(eventName, preventGesture, { passive: false });
  });

  let lastTouchEndAt = 0;

  document.addEventListener("touchend", (event) => {
    if (event.target.closest(".feed-media-card.video, iframe")) {
      lastTouchEndAt = 0;
      return;
    }

    const now = Date.now();

    if (now - lastTouchEndAt <= 280) {
      event.preventDefault();
    }

    lastTouchEndAt = now;
  }, { passive: false });
}

installZoomGuards();

function getInitialViewFromUrl() {
  const urlView = new URLSearchParams(window.location.search).get("view");
  const allowedViews = new Set(["home", "tracking", "order", "order-options", "order-configurator", "maintenance", "maintenance-includes", "maintenance-detailing", "maintenance-accesorios", "virtual-dealership", "pago-separacion", "pago-exitoso"]);

  if (GLOBAL_HERO_GAME_ENABLED) {
    allowedViews.add("sequoia-game");
  }

  if (allowedViews.has(urlView)) {
    return urlView;
  }

  return "home";
}

function persistViewToUrl(viewName) {
  const nextUrl = new URL(window.location.href);

  if (viewName === "home") {
    nextUrl.searchParams.delete("view");
  } else {
    nextUrl.searchParams.set("view", viewName);
  }

  window.history.replaceState({}, document.title, nextUrl.toString());
}

function redirectToLogin() {
  const loginUrl = new URL("/index.html", window.location.origin);
  loginUrl.searchParams.set("logout", "1");
  loginUrl.searchParams.set("t", String(Date.now()));
  window.location.replace(loginUrl.toString());
}

function buildDeletedAccountPageUrl(feedbackToken = "") {
  const pagePath = "/account-deleted.html";
  const deletedAccountUrl = new URL(pagePath, window.location.origin);

  if (feedbackToken) {
    deletedAccountUrl.searchParams.set("token", String(feedbackToken));
  }

  return deletedAccountUrl.toString();
}

function clearAuth() {
  localStorage.removeItem("globalAppToken");
  localStorage.removeItem("globalAppRole");
  sessionStorage.removeItem("globalAppToken");
  sessionStorage.removeItem("globalAppRole");
}

function requestLogout() {
  return fetch(`${apiBaseUrl}/api/auth/logout`, {
    method: "POST",
    credentials: "include",
    keepalive: true,
  }).catch(() => null);
}

function getToken() {
  return localStorage.getItem("globalAppToken");
}

function getRole() {
  return localStorage.getItem("globalAppRole");
}

if (!getToken()) {
  redirectToLogin();
}

if (["admin", "manager", "adminUSA", "gerenteUSA"].includes(getRole())) {
  window.location.href = "/admin.html";
}

function removeGlobalHeroGameUi() {
  if (GLOBAL_HERO_GAME_ENABLED) {
    return;
  }

  document.querySelectorAll('[data-view-target="sequoia-game"], [data-view="sequoia-game"], .sequoia-game-view').forEach((element) => {
    element.remove();
  });
}

removeGlobalHeroGameUi();

const viewNodes = Array.from(document.querySelectorAll(".client-view"));
const navButtons = Array.from(document.querySelectorAll(".client-nav-button")).filter(
  (button) => GLOBAL_HERO_GAME_ENABLED || button.dataset.viewTarget !== "sequoia-game"
);
const feedContainer = document.getElementById("client-feed");
const trackingForm = document.getElementById("tracking-search-form");
const trackingInput = document.getElementById("tracking-search-input");
const trackingOptions = document.getElementById("tracking-search-options");
const trackingSearchFeedback = document.getElementById("tracking-search-feedback");
const trackingTabSearchButton = document.getElementById("tracking-tab-search");
const trackingTabOrdersButton = document.getElementById("tracking-tab-orders");
const trackingSearchPanel = document.getElementById("tracking-search-panel");
const trackingOrdersPanel = document.getElementById("tracking-orders-panel");
const trackingOrdersList = document.getElementById("tracking-orders-list");
const trackingOrdersClearButton = document.getElementById("tracking-orders-clear");
const requestForm = document.getElementById("client-request-form");
const requestFeedback = document.getElementById("client-request-feedback");
const orderVehicleCarousel = document.getElementById("order-vehicle-carousel");
const orderActionCards = document.getElementById("order-experience-actions");
const orderOptionsBackButton = document.getElementById("order-options-back");
const orderConfigBackButton = document.getElementById("order-config-back");
const maintenanceIncludesBackButton = document.getElementById("maintenance-includes-back");
const maintenanceIncludesStory = document.getElementById("maint-story");
const maintenanceDetailingBackButton = document.getElementById("maintenance-detailing-back");
const detailingStory = document.getElementById("detailing-story");
const detailingCeramicButton = document.getElementById("detailing-ceramic-button");
const detailingPolarizadoButton = document.getElementById("detailing-polarizado-button");
const detailingFeedback = document.getElementById("client-detailing-feedback");
const maintenanceAccesoriosBackButton = document.getElementById("maintenance-accesorios-back");
const accesoriosStory = document.getElementById("accesorios-story");
const accesoriosQuoteButton = document.getElementById("accesorios-quote-button");
const accesoriosFeedback = document.getElementById("client-accesorios-feedback");
const maintenanceVehicleTag = document.getElementById("maintenance-vehicle-tag");
const maintenanceLastServiceField = document.getElementById("maintenance-last-service-field");
const maintenanceMileageField = document.getElementById("maintenance-mileage-field");
const maintenanceDailyKmField = document.getElementById("maintenance-daily-km-field");
const maintenancePreferredDateLabel = document.getElementById("maintenance-preferred-date-label");
const maintenanceDrivingCityField = document.getElementById("maintenance-driving-city-field");
const accessoriesRequestField = document.getElementById("accessories-request-field");
const sequoiaGameRoot = document.getElementById("sequoia-game-root");
const sequoiaConfigImageFrame = document.getElementById("sequoia-config-image-frame");
const sequoiaConfigMainImage = document.getElementById("sequoia-config-main-image");
const sequoiaVisionHint = document.getElementById("sequoia-vision-hint");
const sequoiaInteriorImageFrame = document.getElementById("sequoia-interior-image-frame");
const sequoiaInteriorMainImage = document.getElementById("sequoia-interior-main-image");
const sequoiaInteriorColorName = document.getElementById("sequoia-interior-color-name");
const sequoiaInteriorColors = document.getElementById("sequoia-interior-colors");
const sequoiaConfigPrevButton = document.getElementById("sequoia-config-prev");
const sequoiaConfigNextButton = document.getElementById("sequoia-config-next");
const sequoiaConfigDots = document.getElementById("sequoia-config-dots");
const sequoiaConfigColors = document.getElementById("sequoia-config-colors");
const sequoiaConfigColorName = document.getElementById("sequoia-config-color-name");
const sequoiaConfigTitle = document.getElementById("sequoia-config-title");
const sequoiaConfigPrice = document.getElementById("sequoia-config-price");
const sequoiaConfigSpecs = document.getElementById("sequoia-config-specs");
const sequoiaConfigVersions = document.getElementById("sequoia-config-versions");
const sequoiaSummaryTitle = document.getElementById("sequoia-summary-title");
const sequoiaSummaryDeliveryRange = document.getElementById("sequoia-summary-delivery-range");
const sequoiaDeliveryCityButton = document.getElementById("sequoia-delivery-city-button");
const sequoiaCitySelector = document.getElementById("sequoia-city-selector");
const sequoiaCityFeeNote = document.getElementById("sequoia-city-fee-note");
const sequoiaOrderDetailsToggle = document.getElementById("sequoia-order-details-toggle");
const sequoiaOrderDetails = document.getElementById("sequoia-order-details");
const sequoiaSummaryTotalPrice = document.getElementById("sequoia-summary-total-price");
const sequoiaSummaryFinancingLink = document.getElementById("sequoia-summary-financing-link");
const sequoiaOrderCardButton = document.getElementById("sequoia-order-card-button");
const maintenanceFeedback = document.getElementById("client-maintenance-feedback");
const addMaintenanceVehicleButton = document.getElementById("client-add-maintenance-vehicle-button");
const maintenanceVehicleModal = document.getElementById("maintenance-vehicle-modal");
const maintenanceVehicleOverlay = document.getElementById("maintenance-vehicle-overlay");
const maintenanceVehicleClose = document.getElementById("maintenance-vehicle-close");
const maintenanceVehicleForm = document.getElementById("client-maintenance-vehicle-form");
const maintenanceVehicleTitle = document.getElementById("maintenance-vehicle-title");
const maintenanceVehicleSubmitButton = maintenanceVehicleForm?.querySelector('button[type="submit"]');
const maintenanceList = document.getElementById("client-maintenance-list");
const virtualDealershipClientList = document.getElementById("virtual-dealership-client-list");
const virtualDealershipLoadMoreSentinel = document.getElementById("virtual-dealership-load-more-sentinel");
const virtualDealershipImageModal = document.getElementById("virtual-dealership-image-modal");
const virtualDealershipImageOverlay = document.getElementById("virtual-dealership-image-overlay");
const virtualDealershipImageClose = document.getElementById("virtual-dealership-image-close");
const virtualDealershipImagePrev = document.getElementById("virtual-dealership-image-prev");
const virtualDealershipImageNext = document.getElementById("virtual-dealership-image-next");
const virtualDealershipImageDots = document.getElementById("virtual-dealership-image-dots");
const virtualDealershipImageTrack = document.getElementById("virtual-dealership-image-track");
const virtualDealershipVideoModal = document.getElementById("virtual-dealership-video-modal");
const virtualDealershipVideoOverlay = document.getElementById("virtual-dealership-video-overlay");
const virtualDealershipVideoClose = document.getElementById("virtual-dealership-video-close");
const virtualDealershipVideoDescription = document.getElementById("virtual-dealership-video-modal-description");
const virtualDealershipVideoDate = document.getElementById("virtual-dealership-video-date");
const virtualDealershipVideoSlots = document.getElementById("virtual-dealership-video-slots");
const virtualDealershipVideoConfirm = document.getElementById("virtual-dealership-video-confirm");
const virtualDealershipVideoFeedback = document.getElementById("virtual-dealership-video-feedback");
const notificationsButton = document.getElementById("notifications-button");
const notificationsModal = document.getElementById("notifications-modal");
const notificationsOverlay = document.getElementById("notifications-overlay");
const notificationsClose = document.getElementById("notifications-close");
const notificationsList = document.getElementById("notifications-list");
const notificationCount = document.getElementById("notification-count");
const menuButton = document.getElementById("client-menu-button");
const sessionMenu = document.getElementById("session-menu");
const logoutButton = document.getElementById("client-logout-button");
const deleteAccountOpenButton = document.getElementById("client-delete-account-open");
const deleteAccountModal = document.getElementById("delete-account-modal");
const deleteAccountOverlay = document.getElementById("delete-account-overlay");
const deleteAccountCloseButton = document.getElementById("delete-account-close");
const deleteAccountCancelButton = document.getElementById("delete-account-cancel");
const deleteAccountForm = document.getElementById("delete-account-form");
const deleteAccountPasswordInput = document.getElementById("delete-account-password");
const deleteAccountConfirmButton = document.getElementById("delete-account-confirm");
const deleteAccountFeedback = document.getElementById("delete-account-feedback");
const refreshIndicator = document.getElementById("feed-refresh-indicator");
const refreshLabel = document.getElementById("feed-refresh-label");
const feedLoadMoreSentinel = document.getElementById("feed-load-more-sentinel");
const feedLoadingState = document.getElementById("feed-loading-state");
const feedLikesModal = document.getElementById("feed-likes-modal");
const feedLikesList = document.getElementById("feed-likes-list");
const feedCommentsModal = document.getElementById("feed-comments-modal");
const feedCommentsList = document.getElementById("feed-comments-list");
const feedCommentForm = document.getElementById("feed-comment-form");
const feedCommentInput = document.getElementById("feed-comment-input");
const feedCommentSubmit = document.getElementById("feed-comment-submit");
const feedActionMessage = document.getElementById("feed-action-message");

let feedObserver = null;
let feedVideoObserver = null;
let feedVideoPreloadObserver = null;
let activeFeedVideoCard = null;
const feedVideoVisibility = new Map();
const feedVideoLoadWatchers = new Map();
let feedVideoMessageListenerInstalled = false;
const FEED_VIDEO_AUTOPLAY_MIN_RATIO = 0.55;
let virtualDealershipObserver = null;
let touchStartY = 0;
let pullDistance = 0;
let isPulling = false;
let lastFeedTapAt = 0;
let lastFeedTapPostId = "";
let wheelUpRefreshAccumulator = 0;
let lastWheelRefreshAt = 0;
let trackingHistory = [];
let selectedOrderVehicle = null;
let selectedSequoiaVersion = "sr5";
let selectedSequoiaColor = "lunar-rock";
let selectedSequoiaImageIndex = 0;
let selectedSequoiaInteriorColor = "tela-color-black";
let selectedSequoiaInteriorImageIndex = 0;
let selectedSequoiaDeliveryCity = "barranquilla";
let isSequoiaOrderDetailsExpanded = false;
let sequoiaTouchLastX = 0;
let sequoiaTouchAccumulator = 0;
let isSequoiaTouchDragging = false;
let sequoiaWheelAccumulator = 0;
let sequoiaInteriorTouchLastX = 0;
let sequoiaInteriorTouchAccumulator = 0;
let isSequoiaInteriorTouchDragging = false;
let sequoiaInteriorWheelAccumulator = 0;
let sequoiaVisionHintTimeout = null;
let virtualDealershipModalImages = [];
let virtualDealershipModalImageIndex = 0;
let editingMaintenanceVehicleId = "";
let workshopBookingService = "maintenance";

const WORKSHOP_BOOKING_COPY = {
  maintenance: {
    tag: "Mantenimiento",
    title: "Agenda tu mantenimiento",
    submit: "Agendar ahora",
    dateLabel: "¿Para qué fecha quieres el mantenimiento?",
    whatsappIntro: "Hola Global Imports, quiero cotizar un mantenimiento.",
    saving: "Guardando y preparando tu cotización...",
    success: "Vehículo guardado. Te estamos abriendo WhatsApp para cotizar tu mantenimiento.",
  },
  ceramic: {
    tag: "Detailing",
    title: "Agenda tu tratamiento cerámico",
    submit: "Agendar ahora",
    dateLabel: "¿Para qué fecha quieres el tratamiento cerámico?",
    whatsappIntro: "Hola Global Imports, quiero agendar un tratamiento cerámico.",
    saving: "Guardando y preparando tu agendamiento...",
    success: "Datos guardados. Te estamos abriendo WhatsApp para agendar tu tratamiento cerámico.",
  },
  polarizado: {
    tag: "Detailing",
    title: "Agenda tu polarizado",
    submit: "Agendar ahora",
    dateLabel: "¿Para qué fecha quieres el polarizado?",
    whatsappIntro: "Hola Global Imports, quiero agendar un polarizado.",
    saving: "Guardando y preparando tu agendamiento...",
    success: "Datos guardados. Te estamos abriendo WhatsApp para agendar tu polarizado.",
  },
  accesorios: {
    tag: "Accesorios",
    title: "Cotiza tus accesorios",
    submit: "Cotizar ahora",
    dateLabel: "¿Para qué fecha quieres la cotización o instalación?",
    whatsappIntro: "Hola Global Imports, quiero cotizar accesorios para mi vehículo.",
    saving: "Guardando y preparando tu cotización...",
    success: "Datos guardados. Te estamos abriendo WhatsApp para cotizar tus accesorios.",
  },
};

function resolveWorkshopBookingCopy() {
  return WORKSHOP_BOOKING_COPY[workshopBookingService] || WORKSHOP_BOOKING_COPY.maintenance;
}

function resolveWorkshopFeedback() {
  if (state.activeView === "maintenance-detailing") {
    return detailingFeedback || maintenanceFeedback;
  }

  if (state.activeView === "maintenance-accesorios") {
    return accesoriosFeedback || maintenanceFeedback;
  }

  return maintenanceFeedback;
}

function isWorkshopServiceWithoutMileage() {
  return workshopBookingService === "ceramic"
    || workshopBookingService === "polarizado"
    || workshopBookingService === "accesorios";
}
let virtualDealershipVideoContext = {
  vehicleTitle: "",
  publicationUrl: "",
  selectedDate: "",
  selectedTime: "",
};

const SEQUOIA_SPIN_STEP_PX = 26;
const SEQUOIA_TOUCH_SPIN_STEP_PX = 14;

const ORDER_ACTION_TEMPLATES = [
  { key: "demo", title: "Agenda un Demo Drive.", image: "/runer.jpeg", button: "Explora" },
  { key: "finance", title: "Opciones de financiamiento", image: "/sequ.jpg", button: "Explora" },
  { key: "design", title: "Diseña tu {vehicle}", image: "/sequ.jpg", button: "Explora" },
];

const ORDER_ACTION_IMAGES_BY_VEHICLE = {
  sequoia: {
    demo: "/sequ.jpg",
    finance: "/sequ2.jpg",
    design: "/sequ3.jpg",
  },
};

const GLOBAL_WHATSAPP_NUMBER = "3016698126";
const SEQUOIA_ORDER_RESERVATION_AMOUNT = 1000000;
const SEQUOIA_DELIVERY_OPTIONS = {
  barranquilla: { label: "Barranquilla", fee: 0 },
  bogota: { label: "Bogota", fee: 3500000 },
  medellin: { label: "Medellin", fee: 3500000 },
  bucaramanga: { label: "Bucaramanga", fee: 3500000 },
  cali: { label: "Cali", fee: 5000000 },
};

const DEFAULT_SEQUOIA_VERSION_ORDER = ["sr5", "limited", "platinum", "trd-pro", "capstone", "1794"];
const SEQUOIA_CATALOG_URL = "/sequoia-catalog.json";
const CLIENT_IMAGE_CONFIG_URL = "/client-image-config.json";
const CLIENT_DEV_CONFIG_URL = "/client-dev-config.json";
let localDevFeedPreviewUrl = "";
let localDevFeedPreviewConfigPromise = null;
const EMPTY_SEQUOIA_CATALOG = Object.freeze({
  versionConfig: {},
  versionOrder: DEFAULT_SEQUOIA_VERSION_ORDER,
  interiorConfig: {},
});
const DEFAULT_CLIENT_IMAGE_DELIVERY_CONFIG = Object.freeze({
  strategy: "origin",
  cloudName: "",
  deliveryBaseUrl: "",
});

let sequoiaCatalog = EMPTY_SEQUOIA_CATALOG;
let sequoiaCatalogPromise = null;
let clientImageDeliveryConfig = DEFAULT_CLIENT_IMAGE_DELIVERY_CONFIG;
let clientImageDeliveryConfigPromise = null;

function normalizeClientAssetPath(assetPath = "") {
  const normalizedValue = String(assetPath || "").trim();

  if (!normalizedValue) {
    return "";
  }

  if (/^(?:https?:)?\/\//i.test(normalizedValue)) {
    return normalizedValue;
  }

  return normalizedValue.startsWith("/") ? normalizedValue : "/" + normalizedValue;
}

function resolveOriginClientAssetUrl(assetPath = "") {
  const normalizedPath = normalizeClientAssetPath(assetPath);

  if (!normalizedPath) {
    return "";
  }

  if (/^(?:https?:)?\/\//i.test(normalizedPath)) {
    return normalizedPath;
  }

  return new URL(normalizedPath, window.location.origin).toString();
}

function resolveCdnBaseAssetUrl(assetPath = "") {
  const normalizedPath = normalizeClientAssetPath(assetPath);
  const baseUrl = String(clientImageDeliveryConfig.deliveryBaseUrl || "").trim().replace(/\/$/, "");

  if (!normalizedPath) {
    return "";
  }

  if (!baseUrl) {
    return resolveOriginClientAssetUrl(normalizedPath);
  }

  return baseUrl + normalizedPath;
}

function resolveCloudinaryFetchUrl(assetPath = "") {
  const cloudName = String(clientImageDeliveryConfig.cloudName || "").trim();
  const originAssetUrl = resolveOriginClientAssetUrl(assetPath);

  if (!cloudName || !originAssetUrl) {
    return originAssetUrl;
  }

  return "https://res.cloudinary.com/" + cloudName + "/image/fetch/f_auto,q_auto,dpr_auto/" + encodeURIComponent(originAssetUrl);
}

function resolveClientAssetUrl(assetPath = "") {
  const normalizedPath = normalizeClientAssetPath(assetPath);

  if (!normalizedPath) {
    return "";
  }

  if (/^(?:https?:)?\/\//i.test(normalizedPath)) {
    return normalizedPath;
  }

  switch (String(clientImageDeliveryConfig.strategy || "origin").trim().toLowerCase()) {
    case "cloudinary-fetch":
      return resolveCloudinaryFetchUrl(normalizedPath);
    case "cdn-base":
      return resolveCdnBaseAssetUrl(normalizedPath);
    default:
      return normalizedPath;
  }
}

function mapSequoiaImageCollection(colors = []) {
  if (!Array.isArray(colors)) {
    return [];
  }

  return colors.map((color) => ({
    ...color,
    images: Array.isArray(color?.images) ? color.images.map((imagePath) => resolveClientAssetUrl(imagePath)) : [],
  }));
}

function normalizeSequoiaCatalog(rawCatalog = {}) {
  const rawVersionConfig = rawCatalog?.versionConfig && typeof rawCatalog.versionConfig === "object"
    ? rawCatalog.versionConfig
    : {};
  const rawInteriorConfig = rawCatalog?.interiorConfig && typeof rawCatalog.interiorConfig === "object"
    ? rawCatalog.interiorConfig
    : {};

  const versionConfig = Object.fromEntries(
    Object.entries(rawVersionConfig).map(([versionKey, versionValue]) => [
      versionKey,
      {
        ...versionValue,
        colors: mapSequoiaImageCollection(versionValue?.colors || []),
      },
    ])
  );

  const interiorConfig = Object.fromEntries(
    Object.entries(rawInteriorConfig).map(([versionKey, versionValue]) => [
      versionKey,
      {
        ...versionValue,
        colors: mapSequoiaImageCollection(versionValue?.colors || []),
      },
    ])
  );

  return {
    versionConfig,
    versionOrder: Array.isArray(rawCatalog?.versionOrder) && rawCatalog.versionOrder.length
      ? rawCatalog.versionOrder
      : DEFAULT_SEQUOIA_VERSION_ORDER,
    interiorConfig,
  };
}

function hasSequoiaCatalogLoaded() {
  return Boolean(Object.keys(sequoiaCatalog?.versionConfig || {}).length);
}

async function loadClientImageDeliveryConfig() {
  if (clientImageDeliveryConfigPromise) {
    return clientImageDeliveryConfigPromise;
  }

  clientImageDeliveryConfigPromise = fetch(CLIENT_IMAGE_CONFIG_URL, { cache: "no-cache" })
    .then(async (response) => {
      if (!response.ok) {
        throw new Error("No se pudo cargar la configuracion de imagenes del cliente.");
      }

      const parsedConfig = await response.json();
      clientImageDeliveryConfig = {
        ...DEFAULT_CLIENT_IMAGE_DELIVERY_CONFIG,
        ...(parsedConfig || {}),
      };
      return clientImageDeliveryConfig;
    })
    .catch(() => {
      clientImageDeliveryConfig = DEFAULT_CLIENT_IMAGE_DELIVERY_CONFIG;
      return clientImageDeliveryConfig;
    });

  return clientImageDeliveryConfigPromise;
}

async function loadLocalDevFeedPreviewConfig() {
  if (localDevFeedPreviewConfigPromise) {
    return localDevFeedPreviewConfigPromise;
  }

  localDevFeedPreviewConfigPromise = fetch(CLIENT_DEV_CONFIG_URL, { cache: "no-cache" })
    .then(async (response) => {
      if (!response.ok) {
        return "";
      }

      const config = await response.json();
      localDevFeedPreviewUrl = String(config?.previewFeedVideo || "").trim();
      return localDevFeedPreviewUrl;
    })
    .catch(() => "");

  return localDevFeedPreviewConfigPromise;
}

async function loadSequoiaCatalog() {
  if (hasSequoiaCatalogLoaded()) {
    return sequoiaCatalog;
  }

  if (sequoiaCatalogPromise) {
    return sequoiaCatalogPromise;
  }

  sequoiaCatalogPromise = (async () => {
    await loadClientImageDeliveryConfig();

    const response = await fetch(SEQUOIA_CATALOG_URL, { cache: "no-cache" });

    if (!response.ok) {
      throw new Error("No se pudo cargar el catalogo Sequoia.");
    }

    const rawCatalog = await response.json();
    sequoiaCatalog = normalizeSequoiaCatalog(rawCatalog);
    return sequoiaCatalog;
  })().catch((error) => {
    sequoiaCatalogPromise = null;
    throw error;
  });

  return sequoiaCatalogPromise;
}

function getSequoiaCatalog() {
  return sequoiaCatalog || EMPTY_SEQUOIA_CATALOG;
}

function setSequoiaConfiguratorLoadingState(message = "") {
  if (sequoiaConfigPrice) {
    sequoiaConfigPrice.textContent = message || "";
  }

  if (sequoiaConfigSpecs) {
    sequoiaConfigSpecs.innerHTML = message
      ? '<article class="sequoia-spec-card"><strong>Cargando</strong><span>' + escapeHtml(message) + '</span></article>'
      : "";
  }
}

async function ensureSequoiaConfiguratorReady() {
  if (hasSequoiaCatalogLoaded()) {
    renderSequoiaConfigurator();
    return sequoiaCatalog;
  }

  setSequoiaConfiguratorLoadingState("Cargando configurador...");

  const catalog = await loadSequoiaCatalog();
  const resolvedVersionConfig = catalog.versionConfig || {};
  const fallbackVersionKey = catalog.versionOrder?.[0] || DEFAULT_SEQUOIA_VERSION_ORDER[0];

  if (!resolvedVersionConfig[selectedSequoiaVersion]) {
    selectedSequoiaVersion = fallbackVersionKey;
  }

  const activeVersionConfig = resolvedVersionConfig[selectedSequoiaVersion] || resolvedVersionConfig[fallbackVersionKey] || { colors: [] };
  selectedSequoiaColor = activeVersionConfig.colors?.[0]?.key || selectedSequoiaColor;
  selectedSequoiaInteriorColor = (catalog.interiorConfig?.[selectedSequoiaVersion]?.colors || [])[0]?.key || selectedSequoiaInteriorColor;
  renderSequoiaConfigurator();
  return catalog;
}

function fetchJson(path, options = {}) {
  return fetch(`${apiBaseUrl}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
      ...(options.headers || {}),
    },
  }).then(async (response) => {
    const data = await response.json();

    if (!response.ok) {
      if (
        data.message === "Invalid or expired token" ||
        data.message === "Authentication required" ||
        response.status === 401
      ) {
        clearAuth();
        redirectToLogin();
      }

      throw new Error(data.message || "Request failed");
    }

    return data;
  });
}

function postJson(path, payload = null, options = {}) {
  return fetchJson(path, {
    method: "POST",
    body: payload ? JSON.stringify(payload) : undefined,
    ...options,
  });
}

function toggleFeedPostLike(postId) {
  return postJson(`/api/client/posts/${encodeURIComponent(postId)}/like`);
}

function createFeedComment(postId, payload) {
  return postJson(`/api/client/posts/${encodeURIComponent(postId)}/comments`, payload);
}

function deleteFeedComment(postId, commentId) {
  return fetchJson(`/api/client/posts/${encodeURIComponent(postId)}/comments/${encodeURIComponent(commentId)}`, {
    method: "DELETE",
  });
}

function toggleFeedCommentLike(postId, commentId) {
  return postJson(`/api/client/posts/${encodeURIComponent(postId)}/comments/${encodeURIComponent(commentId)}/like`);
}

async function registerNativePushToken(pushInfo) {
  if (!pushInfo?.token) {
    return;
  }

  const signature = [
    pushInfo.token,
    pushInfo.apsEnvironment || "",
    pushInfo.bundleId || "",
    pushInfo.platform || "ios",
    pushInfo.provider || "apns",
  ].join("|");

  if (state.registeredPushSignature === signature) {
    return;
  }

  await fetchJson("/api/client/push-devices", {
    method: "POST",
    body: JSON.stringify({
      token: pushInfo.token,
      platform: pushInfo.platform || "ios",
      provider: pushInfo.provider || "apns",
      appVersion: pushInfo.appVersion || "ios-webview",
      bundleId: pushInfo.bundleId || "",
      apsEnvironment: pushInfo.apsEnvironment || "",
    }),
  });

  state.registeredPushToken = pushInfo.token;
  state.registeredPushSignature = signature;
}

function syncNativePushToken() {
  const nativePushInfo = window.__globalImportsNativePush;

  if (!nativePushInfo?.token) {
    return;
  }

  registerNativePushToken(nativePushInfo).catch((error) => {
    console.warn("[push][client-portal] No se pudo registrar el token nativo.", error);
  });
}

window.syncNativePushToken = syncNativePushToken;

function setFeedback(element, message, type = "") {
  if (!element) {
    return;
  }

  element.textContent = message;
  element.className = `feedback${type ? ` ${type}` : ""}`;
}

function getTrackingHistoryStorageKey() {
  const userIdentifier =
    state.user?.id
    || state.user?._id
    || state.user?.email
    || state.user?.name
    || "guest";

  return `globalAppTrackingHistory:${String(userIdentifier).toLowerCase()}`;
}

function loadTrackingHistory() {
  try {
    const storedValue = localStorage.getItem(getTrackingHistoryStorageKey());

    if (!storedValue) {
      trackingHistory = [];
      return;
    }

    const parsedValue = JSON.parse(storedValue);
    trackingHistory = Array.isArray(parsedValue)
      ? parsedValue
        .map((item) => ({
          trackingNumber: String(item?.trackingNumber || "").toUpperCase().trim(),
          vehicleLabel: String(item?.vehicleLabel || ""),
          searchedAt: String(item?.searchedAt || ""),
        }))
        .filter((item) => item.trackingNumber)
        .slice(0, TRACKING_HISTORY_MAX_ITEMS)
      : [];
  } catch (error) {
    trackingHistory = [];
  }
}

function persistTrackingHistory() {
  try {
    localStorage.setItem(getTrackingHistoryStorageKey(), JSON.stringify(trackingHistory));
  } catch (error) {
    // Ignore storage write failures to keep tracking search available.
  }
}

function removeTrackingHistoryItem(trackingNumber) {
  const normalizedTrackingNumber = String(trackingNumber || "").toUpperCase().trim();

  if (!normalizedTrackingNumber) {
    return;
  }

  trackingHistory = trackingHistory.filter(
    (item) => item.trackingNumber !== normalizedTrackingNumber
  );
  persistTrackingHistory();
  renderTrackingHistory();
}

function renderTrackingHistory() {
  if (!trackingOrdersList) {
    return;
  }

  if (!trackingHistory.length) {
    trackingOrdersList.innerHTML = '<p class="tracking-orders-empty">Aún no has buscado pedidos. Tus búsquedas aparecerán aquí.</p>';

    if (trackingOrdersClearButton) {
      trackingOrdersClearButton.hidden = true;
    }

    return;
  }

  if (trackingOrdersClearButton) {
    trackingOrdersClearButton.hidden = false;
  }

  trackingOrdersList.innerHTML = trackingHistory
    .map(
      (item) => `
        <article class="tracking-orders-item">
          <button type="button" class="tracking-orders-item-button" data-tracking-history="${escapeHtml(item.trackingNumber)}">
            <strong>Guía ${escapeHtml(item.trackingNumber)}</strong>
            <span>${escapeHtml(item.vehicleLabel || "Pedido guardado")}</span>
            <span>Buscado el ${escapeHtml(formatDate(item.searchedAt))}</span>
          </button>
          <button
            type="button"
            class="tracking-orders-item-remove"
            data-tracking-history-remove="${escapeHtml(item.trackingNumber)}"
            aria-label="Quitar guía ${escapeHtml(item.trackingNumber)} del historial"
          >
            ×
          </button>
        </article>
      `
    )
    .join("");
}

function setTrackingActiveTab(tabName) {
  const isSearchTab = tabName === "search";

  if (trackingSearchPanel) {
    trackingSearchPanel.hidden = !isSearchTab;
  }

  if (trackingOrdersPanel) {
    trackingOrdersPanel.hidden = isSearchTab;
  }

  if (trackingTabSearchButton) {
    trackingTabSearchButton.classList.toggle("is-active", isSearchTab);
    trackingTabSearchButton.setAttribute("aria-selected", String(isSearchTab));
  }

  if (trackingTabOrdersButton) {
    trackingTabOrdersButton.classList.toggle("is-active", !isSearchTab);
    trackingTabOrdersButton.setAttribute("aria-selected", String(!isSearchTab));
  }
}

function rememberTrackingSearch(trackingNumber) {
  const normalizedTrackingNumber = String(trackingNumber || "").toUpperCase().trim();

  if (!normalizedTrackingNumber) {
    return;
  }

  const matchedOrder = state.orders.find(
    (order) => String(order?.trackingNumber || "").toUpperCase().trim() === normalizedTrackingNumber
  );
  const vehicleLabel = [matchedOrder?.vehicle?.brand, matchedOrder?.vehicle?.model, matchedOrder?.vehicle?.version]
    .filter(Boolean)
    .join(" ");

  trackingHistory = [
    {
      trackingNumber: normalizedTrackingNumber,
      vehicleLabel,
      searchedAt: new Date().toISOString(),
    },
    ...trackingHistory.filter((item) => item.trackingNumber !== normalizedTrackingNumber),
  ].slice(0, TRACKING_HISTORY_MAX_ITEMS);

  persistTrackingHistory();
  renderTrackingHistory();
}

function formatDate(dateValue) {
  if (!dateValue) {
    return "Sin fecha";
  }

  return new Date(dateValue).toLocaleDateString("es-VE", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function syncNativeAppBadge(count) {
  const normalizedCount = Number.isFinite(Number(count)) ? Math.max(0, Number(count)) : 0;

  if (window.webkit?.messageHandlers?.globalImportsBadge) {
    window.webkit.messageHandlers.globalImportsBadge.postMessage({ count: normalizedCount });
  }

  if (typeof navigator.setAppBadge === "function") {
    navigator.setAppBadge(normalizedCount).catch(() => null);
  }

  if (normalizedCount === 0 && typeof navigator.clearAppBadge === "function") {
    navigator.clearAppBadge().catch(() => null);
  }
}

function formatCurrency(amount, currency = "USD") {
  return new Intl.NumberFormat("es-VE", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(Number(amount || 0));
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function buildEmbeddedVideoUrl(rawUrl) {
  const url = String(rawUrl || "").trim();

  if (!url) {
    return "";
  }

  try {
    const parsedUrl = new URL(url);
    const host = parsedUrl.hostname.toLowerCase();

    if (host.includes("youtu.be") || host.includes("youtube.com")) {
      let videoId = "";

      if (host.includes("youtu.be")) {
        videoId = parsedUrl.pathname.split("/").filter(Boolean)[0] || "";
      } else {
        const pathSegments = parsedUrl.pathname.split("/").filter(Boolean);

        videoId =
          parsedUrl.searchParams.get("v") ||
          (pathSegments[0] === "embed" ? pathSegments[1] || "" : "") ||
          (pathSegments[0] === "shorts" ? pathSegments[1] || "" : "") ||
          (pathSegments[0] === "live" ? pathSegments[1] || "" : "") ||
          (pathSegments[0] === "v" ? pathSegments[1] || "" : "");
      }

      if (!videoId) {
        return "";
      }

      return `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?controls=1&playsinline=1&rel=0&modestbranding=1&enablejsapi=1`;
    }

    if (host.includes("vimeo.com")) {
      const segments = parsedUrl.pathname.split("/").filter(Boolean);
      const videoId = segments[segments.length - 1] || "";

      if (!videoId) {
        return "";
      }

      return `https://player.vimeo.com/video/${encodeURIComponent(videoId)}?app_id=122963&title=0&byline=0&portrait=0&playsinline=1&controls=0&pip=0&transparent=0&dnt=1`;
    }
  } catch {
    return "";
  }

  return "";
}

function isVerticalVideoSource(url) {
  return /youtube\.com\/shorts\//i.test(String(url || ""));
}

async function fetchEmbedAspectRatio(sourceUrl) {
  const url = String(sourceUrl || "").trim();

  if (!url) {
    return null;
  }

  try {
    const parsedUrl = new URL(url);
    const host = parsedUrl.hostname.toLowerCase();
    let oembedEndpoint = "";

    if (host.includes("vimeo.com")) {
      oembedEndpoint = `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`;
    } else if (host.includes("youtube.com") || host.includes("youtu.be")) {
      oembedEndpoint = `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`;
    } else {
      return null;
    }

    const response = await fetch(oembedEndpoint);

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    const width = Number(data.width);
    const height = Number(data.height);

    if (!width || !height) {
      return null;
    }

    return {
      width,
      height,
      isPortrait: height > width,
      thumbnailUrl: String(data.thumbnail_url || "").trim(),
    };
  } catch {
    return null;
  }
}

function appendEmbedAutoplayParam(embedUrl) {
  const url = String(embedUrl || "").trim();

  if (!url) {
    return "";
  }

  try {
    const parsedUrl = new URL(url);
    parsedUrl.searchParams.set("autoplay", "1");
    parsedUrl.searchParams.set("muted", "1");
    return parsedUrl.toString();
  } catch {
    return url.includes("?") ? `${url}&autoplay=1` : `${url}?autoplay=1`;
  }
}

function resolveEmbedPosterUrl(sourceUrl, meta) {
  const thumbnailUrl = String(meta?.thumbnailUrl || "").trim();

  if (!thumbnailUrl) {
    return "";
  }

  try {
    const host = new URL(sourceUrl).hostname.toLowerCase();

    if (meta?.isPortrait && host.includes("vimeo.com") && thumbnailUrl.includes("vimeocdn.com")) {
      return thumbnailUrl.replace(/-d_\d+x\d+/, "-d");
    }
  } catch {
    return thumbnailUrl;
  }

  return thumbnailUrl;
}

function postEmbeddedVideoCommand(card, command) {
  const iframe = card?.querySelector(".feed-video-iframe");
  const sourceUrl = String(card?.dataset?.feedEmbedSource || "").trim();

  if (!iframe?.contentWindow || !sourceUrl) {
    return;
  }

  try {
    const host = new URL(sourceUrl).hostname.toLowerCase();

    if (host.includes("youtube.com") || host.includes("youtu.be")) {
      const func = command === "play" ? "playVideo" : "pauseVideo";
      iframe.contentWindow.postMessage(
        JSON.stringify({ event: "command", func, args: "" }),
        "*"
      );
      return;
    }

    if (host.includes("vimeo.com")) {
      iframe.contentWindow.postMessage(JSON.stringify({ method: command }), "*");
    }
  } catch {
    // Ignore malformed embed URLs.
  }
}

function postEmbeddedVideoMuted(card, isMuted) {
  const iframe = card?.querySelector(".feed-video-iframe");
  const sourceUrl = String(card?.dataset?.feedEmbedSource || "").trim();

  if (!iframe?.contentWindow || !sourceUrl || !card.classList.contains("is-playing")) {
    return;
  }

  try {
    const host = new URL(sourceUrl).hostname.toLowerCase();

    if (host.includes("youtube.com") || host.includes("youtu.be")) {
      iframe.contentWindow.postMessage(
        JSON.stringify({ event: "command", func: isMuted ? "mute" : "unMute", args: "" }),
        "*"
      );

      if (!isMuted) {
        iframe.contentWindow.postMessage(
          JSON.stringify({ event: "command", func: "setVolume", args: [100] }),
          "*"
        );
      }

      return;
    }

    if (host.includes("vimeo.com")) {
      iframe.contentWindow.postMessage(JSON.stringify({ method: "setMuted", value: isMuted }), "*");

      if (!isMuted) {
        iframe.contentWindow.postMessage(JSON.stringify({ method: "setVolume", value: 1 }), "*");
      }
    }
  } catch {
    // Ignore malformed embed URLs.
  }
}

function updateFeedVideoMutedUi(card, isMuted) {
  card?.classList.toggle("is-muted", isMuted);

  if (card) {
    card.dataset.feedVideoMuted = isMuted ? "true" : "false";
  }

  const soundTrigger = card?.querySelector(".feed-video-sound-trigger");
  soundTrigger?.setAttribute("aria-label", isMuted ? "Activar sonido" : "Silenciar video");
  soundTrigger?.setAttribute("aria-pressed", isMuted ? "true" : "false");
}

function showFeedVideoSoundTrigger(card) {
  const soundTrigger = card?.querySelector(".feed-video-sound-trigger");

  if (soundTrigger) {
    soundTrigger.hidden = false;
  }
}

function setFeedVideoMuted(card, isMuted) {
  if (!card) {
    return;
  }

  updateFeedVideoMutedUi(card, isMuted);

  if (isFeedEmbedVideoCard(card)) {
    postEmbeddedVideoMuted(card, isMuted);
    return;
  }

  const video = card.querySelector("video");

  if (video) {
    video.muted = isMuted;
  }
}

function toggleFeedVideoSound(card) {
  setFeedVideoMuted(card, !card?.classList.contains("is-muted"));
}

function setFeedEmbeddedVideoPaused(card, isPaused) {
  const playTrigger = card?.querySelector(".feed-video-play-trigger");

  card?.classList.toggle("is-paused", isPaused);
  card.dataset.feedVideoPaused = isPaused ? "true" : "false";
  playTrigger?.setAttribute("aria-label", isPaused ? "Reproducir video" : "Pausar video");
  postEmbeddedVideoCommand(card, isPaused ? "pause" : "play");
}

function toggleFeedEmbeddedVideoPlayback(card) {
  if (!card?.classList.contains("is-playing")) {
    activateFeedEmbeddedVideo(card);
    card.dataset.feedVideoUserPaused = "false";
    activeFeedVideoCard = card;
    return;
  }

  const willPause = !card.classList.contains("is-paused");
  setFeedEmbeddedVideoPaused(card, willPause);
  card.dataset.feedVideoUserPaused = willPause ? "true" : "false";
}

function isFeedEmbedVideoCard(card) {
  return Boolean(card?.dataset?.feedEmbedSource);
}

function resumeFeedEmbeddedVideo(card) {
  if (!card) {
    return;
  }

  if (!card.classList.contains("is-playing")) {
    activateFeedEmbeddedVideo(card);
    return;
  }

  if (card.classList.contains("is-paused")) {
    setFeedEmbeddedVideoPaused(card, false);
  }
}

function preloadFeedEmbeddedVideo(card) {
  if (!isFeedEmbedVideoCard(card) || card.dataset.feedVideoUserPaused === "true") {
    return;
  }

  loadFeedEmbeddedVideoFrame(card);
}

function pauseFeedEmbeddedVideoForScroll(card) {
  if (!card?.classList.contains("is-playing")) {
    return;
  }

  setFeedEmbeddedVideoPaused(card, true);
  delete card.dataset.feedVideoUserPaused;
}

function resumeFeedNativeVideo(card) {
  const video = card?.querySelector("video");

  if (!video) {
    return;
  }

  video.play().catch(() => null);
  card.classList.add("is-playing");
  card.classList.remove("is-paused");
  showFeedVideoSoundTrigger(card);
}

function pauseFeedNativeVideoForScroll(card) {
  const video = card?.querySelector("video");

  if (!video) {
    return;
  }

  video.pause();
  card.classList.add("is-paused");
  card.classList.remove("is-playing");
  delete card.dataset.feedVideoUserPaused;
}

function resumeFeedVideoCard(card) {
  if (isFeedEmbedVideoCard(card)) {
    resumeFeedEmbeddedVideo(card);
    return;
  }

  resumeFeedNativeVideo(card);
}

function pauseFeedVideoCardForScroll(card) {
  if (isFeedEmbedVideoCard(card)) {
    pauseFeedEmbeddedVideoForScroll(card);
    return;
  }

  pauseFeedNativeVideoForScroll(card);
}

function pickDominantFeedVideoCard() {
  let dominantCard = null;
  let dominantRatio = FEED_VIDEO_AUTOPLAY_MIN_RATIO;

  feedVideoVisibility.forEach((ratio, card) => {
    if (ratio > dominantRatio) {
      dominantRatio = ratio;
      dominantCard = card;
    }
  });

  return dominantCard;
}

function syncFeedVideoScrollAutoplay() {
  if (state.activeView !== "home") {
    if (activeFeedVideoCard) {
      pauseFeedVideoCardForScroll(activeFeedVideoCard);
      activeFeedVideoCard = null;
    }

    return;
  }

  const dominantCard = pickDominantFeedVideoCard();

  if (dominantCard === activeFeedVideoCard) {
    if (
      dominantCard &&
      dominantCard.dataset.feedVideoUserPaused !== "true" &&
      dominantCard.classList.contains("is-paused")
    ) {
      resumeFeedVideoCard(dominantCard);
    }

    return;
  }

  if (activeFeedVideoCard) {
    pauseFeedVideoCardForScroll(activeFeedVideoCard);
  }

  activeFeedVideoCard = dominantCard || null;

  if (dominantCard && dominantCard.dataset.feedVideoUserPaused !== "true") {
    resumeFeedVideoCard(dominantCard);
  }
}

function handleFeedVideoIntersection(entries) {
  entries.forEach((entry) => {
    const card = entry.target;

    if (entry.isIntersecting) {
      feedVideoVisibility.set(card, entry.intersectionRatio);
    } else {
      feedVideoVisibility.delete(card);
    }
  });

  syncFeedVideoScrollAutoplay();
}

function resetFeedVideoScrollAutoplay() {
  activeFeedVideoCard = null;
  feedVideoVisibility.clear();

  if (feedVideoObserver) {
    feedVideoObserver.disconnect();
    feedVideoObserver = null;
  }

  if (feedVideoPreloadObserver) {
    feedVideoPreloadObserver.disconnect();
    feedVideoPreloadObserver = null;
  }
}

function bindFeedVideoScrollAutoplay(root = document) {
  resetFeedVideoScrollAutoplay();

  const cards = Array.from(root.querySelectorAll(".feed-media-card.video"));

  if (!cards.length) {
    return;
  }

  feedVideoObserver = new IntersectionObserver(handleFeedVideoIntersection, {
    threshold: [0, 0.25, 0.45, 0.55, 0.7, 0.9, 1],
    rootMargin: "-12% 0px -12% 0px",
  });

  cards.forEach((card) => {
    feedVideoObserver.observe(card);
  });

  feedVideoPreloadObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) {
        return;
      }

      preloadFeedEmbeddedVideo(entry.target);
      feedVideoPreloadObserver?.unobserve(entry.target);
    });
  }, {
    rootMargin: "900px 0px 900px 0px",
    threshold: 0,
  });

  cards.filter(isFeedEmbedVideoCard).forEach((card) => {
    feedVideoPreloadObserver.observe(card);
  });
}

function applyEmbeddedVideoAspectRatio(card, meta) {
  if (!card || !meta?.isPortrait) {
    return;
  }

  card.classList.add("is-portrait");
  card.style.setProperty("--feed-video-aspect-ratio", `${meta.width} / ${meta.height}`);
  card.style.aspectRatio = `${meta.width} / ${meta.height}`;
}

async function prepareFeedEmbeddedVideoCard(card) {
  const sourceUrl = card?.dataset?.feedEmbedSource;

  if (!card || !sourceUrl || card.dataset.embedPrepared === "true") {
    return;
  }

  card.dataset.embedPrepared = "true";

  const meta = await fetchEmbedAspectRatio(sourceUrl);

  if (isVerticalVideoSource(sourceUrl)) {
    applyEmbeddedVideoAspectRatio(card, { width: 9, height: 16, isPortrait: true });
  } else {
    applyEmbeddedVideoAspectRatio(card, meta);
  }

  if (meta?.thumbnailUrl) {
    const poster = card.querySelector(".feed-video-poster");
    const posterUrl = resolveEmbedPosterUrl(sourceUrl, meta);

    if (poster && posterUrl) {
      poster.src = posterUrl;
      poster.hidden = false;
      poster.decode?.().catch(() => null);
    }
  }
}

function preloadInitialFeedVideo(root = document) {
  const firstEmbedVideo = root.querySelector(".feed-media-card.video[data-feed-embed-source]");

  if (!firstEmbedVideo) {
    return;
  }

  const bounds = firstEmbedVideo.getBoundingClientRect();
  const isAlreadyVisible = bounds.top < window.innerHeight && bounds.bottom > 0;

  if (state.activeView === "home" && isAlreadyVisible) {
    activeFeedVideoCard = firstEmbedVideo;
  }

  preloadFeedEmbeddedVideo(firstEmbedVideo);
}

function showFeedVideoLoading(card) {
  if (!card) {
    return;
  }

  card.dataset.feedVideoLoading = "true";
  card.classList.add("is-loading");
  card.classList.remove("is-video-ready");

  const loading = card.querySelector(".feed-video-loading");

  if (loading) {
    loading.hidden = false;
    loading.querySelector("[data-feed-video-loading-text]").textContent = "Cargando video";
  }
}

function hideFeedVideoLoading(card) {
  if (!card || card.dataset.feedVideoLoading !== "true") {
    return;
  }

  card.dataset.feedVideoLoading = "false";
  card.classList.remove("is-loading");
  card.classList.add("is-video-ready");

  const loading = card.querySelector(".feed-video-loading");

  if (loading) {
    loading.hidden = true;
  }
}

function installFeedVideoMessageListener() {
  if (feedVideoMessageListenerInstalled) {
    return;
  }

  feedVideoMessageListenerInstalled = true;

  window.addEventListener("message", (event) => {
    const origin = String(event.origin || "");

    if (!origin.includes("vimeo.com") && !origin.includes("youtube.com")) {
      return;
    }

    let data = null;

    try {
      data = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
    } catch {
      return;
    }

    const eventName = String(data?.event || "");

    feedVideoLoadWatchers.forEach((watcher, iframe) => {
      if (iframe.contentWindow !== event.source) {
        return;
      }

      if (eventName === "ready") {
        watcher.registerPlayerEvents();
        return;
      }

      if (eventName === "bufferend") {
        watcher.finishLoading();
        return;
      }

      if (eventName === "timeupdate") {
        const seconds = Number(data?.data?.seconds ?? 0);

        if (seconds > 0.08) {
          watcher.finishLoading();
        }

        return;
      }

      if (eventName === "play" || eventName === "playing") {
        watcher.scheduleRevealFallback();
        return;
      }

      if (eventName === "onStateChange" && data?.info === 1) {
        watcher.scheduleRevealFallback();
      }
    });
  });
}

function bindFeedEmbeddedVideoLoadWatcher(card, iframe) {
  installFeedVideoMessageListener();
  showFeedVideoLoading(card);

  let finished = false;
  let revealFallbackTimer = null;
  let timeoutTimer = null;

  const finishLoading = () => {
    if (finished) {
      return;
    }

    finished = true;

    if (revealFallbackTimer) {
      window.clearTimeout(revealFallbackTimer);
    }

    if (timeoutTimer) {
      window.clearTimeout(timeoutTimer);
    }

    window.setTimeout(() => {
      hideFeedVideoLoading(card);
      showFeedVideoSoundTrigger(card);

      if (activeFeedVideoCard !== card && card.dataset.feedVideoUserPaused !== "true") {
        setFeedEmbeddedVideoPaused(card, true);
        delete card.dataset.feedVideoUserPaused;
      }

      feedVideoLoadWatchers.delete(iframe);
    }, 180);
  };

  const scheduleRevealFallback = () => {
    if (finished || revealFallbackTimer) {
      return;
    }

    revealFallbackTimer = window.setTimeout(finishLoading, 2600);
  };

  const registerPlayerEvents = () => {
    const sourceUrl = String(card?.dataset?.feedEmbedSource || "").trim();

    if (!iframe.contentWindow || !sourceUrl.includes("vimeo.com")) {
      return;
    }

    ["play", "playing", "bufferend", "timeupdate"].forEach((eventName) => {
      iframe.contentWindow.postMessage(JSON.stringify({ method: "addEventListener", value: eventName }), "*");
    });
  };

  feedVideoLoadWatchers.set(iframe, {
    finishLoading,
    registerPlayerEvents,
    scheduleRevealFallback,
  });

  iframe.addEventListener("load", () => {
    registerPlayerEvents();
    window.setTimeout(registerPlayerEvents, 600);
  }, { once: true });

  timeoutTimer = window.setTimeout(() => {
    const loading = card.querySelector(".feed-video-loading");

    if (loading) {
      loading.querySelector("[data-feed-video-loading-text]").textContent = "El video está tardando";
    }
  }, 7000);
}

function loadFeedEmbeddedVideoFrame(card) {
  const iframe = card?.querySelector(".feed-video-iframe");
  const autoplaySrc = card?.dataset.feedEmbedAutoplaySrc || card?.dataset.feedEmbedSrc;

  if (!iframe || !autoplaySrc) {
    return null;
  }

  if (iframe.dataset.activated === "true") {
    return iframe;
  }

  iframe.dataset.activated = "true";
  iframe.src = autoplaySrc;
  iframe.classList.remove("is-dormant");
  card.classList.add("is-playing");
  card.classList.remove("is-paused");
  card.classList.add("is-muted");
  card.dataset.feedVideoPaused = "false";
  card.dataset.feedVideoMuted = "true";

  const playTrigger = card.querySelector(".feed-video-play-trigger");

  if (playTrigger) {
    playTrigger.classList.add("is-playback-control");
    playTrigger.setAttribute("aria-label", "Pausar video");
  }

  bindFeedEmbeddedVideoLoadWatcher(card, iframe);
  return iframe;
}

function activateFeedEmbeddedVideo(card) {
  const iframe = loadFeedEmbeddedVideoFrame(card);

  if (!iframe) {
    return;
  }

  if (card.dataset.feedVideoLoading === "true") {
    card.classList.remove("is-paused");
    card.dataset.feedVideoPaused = "false";
    postEmbeddedVideoCommand(card, "play");
    return;
  }

  if (card.classList.contains("is-paused")) {
    setFeedEmbeddedVideoPaused(card, false);
    return;
  }

  postEmbeddedVideoCommand(card, "play");
}

function bindFeedVideoPlayTriggers(root = document) {
  root.querySelectorAll(".feed-media-card.video .feed-video-play-trigger").forEach((button) => {
    if (button.dataset.bound === "true") {
      return;
    }

    button.dataset.bound = "true";

    const handleActivate = (event) => {
      event.preventDefault();
      event.stopPropagation();

      const card = button.closest(".feed-media-card.video");

      if (card?.classList.contains("is-playing")) {
        toggleFeedEmbeddedVideoPlayback(card);
        return;
      }

      activateFeedEmbeddedVideo(card);
    };

    button.addEventListener("click", handleActivate);
  });
}

function bindFeedVideoSoundTriggers(root = document) {
  root.querySelectorAll(".feed-video-sound-trigger").forEach((button) => {
    if (button.dataset.bound === "true") {
      return;
    }

    button.dataset.bound = "true";

    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      toggleFeedVideoSound(button.closest(".feed-media-card.video"));
    });
  });
}

function renderFeedVideoLoadingOverlay() {
  return `
    <div class="feed-video-loading" aria-live="polite">
      <span class="feed-video-loading-spinner" aria-hidden="true"></span>
      <p data-feed-video-loading-text>Cargando video</p>
    </div>
  `;
}

function renderFeedVideoSoundButton() {
  return `
    <button type="button" class="feed-video-sound-trigger" aria-label="Activar sonido" aria-pressed="true" hidden>
      <svg class="feed-video-sound-icon feed-video-sound-icon-muted" viewBox="0 0 24 24" focusable="false" aria-hidden="true">
        <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3 3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4 9.91 6.09 12 8.18V4z" />
      </svg>
      <svg class="feed-video-sound-icon feed-video-sound-icon-on" viewBox="0 0 24 24" focusable="false" aria-hidden="true">
        <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
      </svg>
    </button>
  `;
}

async function bindFeedEmbeddedVideoOrientation(root = document) {
  const cards = root.querySelectorAll(".feed-media-card.video[data-feed-embed-source]");

  await Promise.all(Array.from(cards).map((card) => prepareFeedEmbeddedVideoCard(card)));
}

function bindFeedVideoOrientation(root = document) {
  root.querySelectorAll(".feed-media-card.video video").forEach((video) => {
    const card = video.closest(".feed-media-card");
    if (!card) {
      return;
    }

    const applyOrientation = () => {
      const { videoWidth, videoHeight } = video;
      if (!videoWidth || !videoHeight) {
        return;
      }

      const isPortrait = videoHeight > videoWidth;
      card.classList.toggle("is-portrait", isPortrait);
      card.classList.toggle("is-landscape", !isPortrait);

      if (isPortrait) {
        card.style.aspectRatio = `${videoWidth} / ${videoHeight}`;
      } else {
        card.style.removeProperty("aspect-ratio");
      }
    };

    if (video.readyState >= 1) {
      applyOrientation();
    } else {
      video.addEventListener("loadedmetadata", applyOrientation, { once: true });
    }
  });
}

function renderFeedVideoMedia(url) {
  const embeddedUrl = buildEmbeddedVideoUrl(url);
  const portraitClass = isVerticalVideoSource(url) ? " is-portrait" : "";

  if (embeddedUrl) {
    const autoplayUrl = appendEmbedAutoplayParam(embeddedUrl);

    return `
      <div
        class="feed-media-card video is-muted is-loading${portraitClass}"
        data-feed-embed-source="${escapeHtml(url)}"
        data-feed-embed-src="${escapeHtml(embeddedUrl)}"
        data-feed-embed-autoplay-src="${escapeHtml(autoplayUrl)}"
        data-feed-video-muted="true"
        data-feed-video-loading="true"
      >
        <button type="button" class="feed-video-play-trigger" aria-label="Reproducir video">
          <span class="feed-video-play-icon" aria-hidden="true"></span>
        </button>
        ${renderFeedVideoSoundButton()}
        ${renderFeedVideoLoadingOverlay()}
        <img class="feed-video-poster" alt="" loading="lazy" hidden />
        <iframe
          class="feed-video-iframe is-dormant"
          title="Video"
          allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share"
          allowfullscreen
          referrerpolicy="strict-origin-when-cross-origin"
        ></iframe>
      </div>
    `;
  }

  return `
    <div class="feed-media-card video is-muted" data-feed-video-muted="true">
      <video controls playsinline preload="metadata" muted controlsList="nodownload noplaybackrate" src="${escapeHtml(url)}"></video>
      ${renderFeedVideoSoundButton()}
    </div>
  `;
}

function getLocalFeedVideoPreviewUrl() {
  return new URLSearchParams(window.location.search).get("previewFeedVideo") || localDevFeedPreviewUrl || "";
}

function prependLocalFeedVideoPreview() {
  const previewUrl = getLocalFeedVideoPreviewUrl();

  if (!previewUrl || !feedContainer) {
    return;
  }

  const existingPreview = feedContainer.querySelector("[data-feed-video-preview]");

  if (existingPreview?.dataset.previewUrl === previewUrl) {
    return;
  }

  existingPreview?.remove();

  const previewMarkup = `
    <article class="feed-card" data-feed-video-preview="true" data-preview-url="${escapeHtml(previewUrl)}">
      <div class="feed-author-row">
        <div class="feed-author-meta">
          <div class="feed-author-avatar">
            <img src="/logoblancoleon.png" alt="Logo Global Imports" loading="lazy" />
          </div>
          <div>
            <strong>Vista previa local</strong>
            <p class="feed-author-credit">No publicada · sin notificaciones</p>
            <p>Preview desde .env</p>
          </div>
        </div>
      </div>
      <div class="feed-media-shell">
        <div class="feed-media-strip">${renderFeedVideoMedia(previewUrl)}</div>
      </div>
      <div class="feed-story-copy">
        <h3>Preview del video</h3>
        <p class="feed-card-copy">Este bloque solo aparece en local con LOCAL_FEED_VIDEO_PREVIEW_URL.</p>
      </div>
    </article>
  `;

  feedContainer.insertAdjacentHTML("afterbegin", previewMarkup);
}

async function applyFeedMediaLayout() {
  if (!feedContainer) {
    return;
  }

  bindFeedCarousels();
  bindFeedVideoOrientation(feedContainer);
  prependLocalFeedVideoPreview();
  preloadInitialFeedVideo(feedContainer);
  await bindFeedEmbeddedVideoOrientation(feedContainer);
  bindFeedVideoPlayTriggers(feedContainer);
  bindFeedVideoSoundTriggers(feedContainer);
  bindFeedVideoScrollAutoplay(feedContainer);
}

function renderEmptyState(container, message) {
  container.innerHTML = `<div class="empty-state">${escapeHtml(message)}</div>`;
}

function updateSummary() {
  if (state.user) {
    document.getElementById("client-greeting").textContent = `Hola, ${state.user.name}`;
    const requestName = document.getElementById("request-name");
    const requestEmail = document.getElementById("request-email");

    if (requestName) {
      requestName.value = state.user.name || "";
    }

    if (requestEmail) {
      requestEmail.value = state.user.email || "";
    }
  }
}

function getFeedPostId(post = {}) {
  return String(post._id || post.id || "");
}

function findFeedPost(postId) {
  const normalizedPostId = String(postId || "");
  return state.feedPosts.find((post) => getFeedPostId(post) === normalizedPostId) || null;
}

function getFeedArticleElement(postId) {
  const normalizedPostId = String(postId || "");
  return Array.from(feedContainer.querySelectorAll("[data-feed-post-id]")).find(
    (element) => String(element.dataset.feedPostId || "") === normalizedPostId
  ) || null;
}

function getFeedHeartIcon(isLiked) {
  return `
    <svg class="${isLiked ? "is-filled" : "is-outline"}" viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false">
      <path d="M12 20.1 4.5 12.6A4.7 4.7 0 0 1 11.2 6l.8.9.8-.9a4.7 4.7 0 0 1 6.7 6.6L12 20.1Z" />
    </svg>
  `;
}

function syncFeedArticleSocialState(post) {
  const postId = getFeedPostId(post);
  const article = getFeedArticleElement(postId);

  if (!article) {
    return;
  }

  const likes = Array.isArray(post.likes) ? post.likes : [];
  const likesCount = Number(post.likesCount ?? likes.length ?? 0);
  const commentsCount = Number(post.commentsCount ?? post.comments?.length ?? 0);
  const likeButton = article.querySelector("[data-feed-like]");
  const likeIcon = likeButton?.querySelector(".feed-heart-icon");
  const likesCounter = article.querySelector("[data-feed-likes-open].feed-action-count");
  const commentsCounter = article.querySelector("[data-feed-comments-open].feed-action-count");

  if (likeButton) {
    likeButton.classList.toggle("is-liked", Boolean(post.likedByMe));
    likeButton.disabled = pendingFeedLikeIdsRef.has(postId);
  }

  if (likeIcon) {
    likeIcon.innerHTML = getFeedHeartIcon(Boolean(post.likedByMe));
  }

  if (likesCounter) {
    likesCounter.textContent = String(likesCount);
  }

  if (commentsCounter) {
    commentsCounter.textContent = String(commentsCount);
  }
}

function replaceFeedItem(updatedItem, options = {}) {
  const updatedPostId = getFeedPostId(updatedItem);
  const shouldRender = options.render !== false;

  if (!updatedPostId) {
    return;
  }

  state.feedPosts = state.feedPosts.map((post) => (getFeedPostId(post) === updatedPostId ? updatedItem : post));

  if (shouldRender) {
    renderFeed();
  } else {
    syncFeedArticleSocialState(updatedItem);
  }

  renderActiveFeedSocialSheet();
}

function playFeedLikeAnimation(postId) {
  const article = getFeedArticleElement(postId);
  const target = article?.querySelector(".feed-media-shell") || article?.querySelector(".feed-story-copy");

  if (!target) {
    return;
  }

  target.querySelectorAll(".feed-like-burst").forEach((element) => element.remove());
  const burst = document.createElement("span");
  burst.className = "feed-like-burst feed-heart-icon";
  burst.setAttribute("aria-hidden", "true");
  burst.innerHTML = getFeedHeartIcon(true);
  target.appendChild(burst);
  window.setTimeout(() => burst.remove(), 760);
}

function formatFeedSocialCount(count, singular, plural) {
  const total = Number(count || 0);
  return `${total} ${total === 1 ? singular : plural}`;
}

function renderFeedLikesPreview(likes = []) {
  if (!likes.length) {
    return "Sé el primero en dar me gusta";
  }

  const firstName = String(likes[0]?.name || "Cliente").trim() || "Cliente";
  const remainingCount = likes.length - 1;

  return remainingCount > 0
    ? `A ${firstName} y ${remainingCount} más les gusta`
    : `A ${firstName} le gusta`;
}

function setFeedActionMessage(message = "", type = "") {
  state.feedActionMessage = message;

  if (!feedActionMessage) {
    return;
  }

  feedActionMessage.textContent = message;
  feedActionMessage.className = `feedback${type ? ` ${type}` : ""}`;
}

function renderFeedPersonList(container, likes = [], emptyMessage = "Todavía no hay likes.") {
  if (!container) {
    return;
  }

  if (!likes.length) {
    container.innerHTML = `<div class="empty-state">${escapeHtml(emptyMessage)}</div>`;
    return;
  }

  container.innerHTML = likes
    .map((like) => {
      const name = String(like?.name || "Cliente").trim() || "Cliente";
      return `
        <div class="feed-social-person">
          <span>${escapeHtml(name.charAt(0).toUpperCase())}</span>
          <strong>${escapeHtml(name)}</strong>
        </div>
      `;
    })
    .join("");
}

function renderFeedCommentsList(post) {
  if (!feedCommentsList) {
    return;
  }

  const comments = Array.isArray(post?.comments) ? post.comments : [];

  if (!comments.length) {
    feedCommentsList.innerHTML = `<div class="empty-state">Sé el primero en comentar.</div>`;
    return;
  }

  feedCommentsList.innerHTML = comments
    .map((comment) => {
      const commentId = String(comment?.id || comment?._id || "");
      const likeKey = `${getFeedPostId(post)}:${commentId}`;
      const isPending = pendingFeedCommentLikeKeysRef.has(likeKey);
      const likedClass = comment?.likedByMe ? " is-liked" : "";
      const disabledAttr = isPending ? " disabled" : "";
      const deleteMarkup = comment?.canDelete
        ? `<button class="feed-comment-delete" type="button" data-feed-comment-delete="${escapeHtml(commentId)}">Eliminar</button>`
        : "";

      return `
        <article class="feed-comment-item">
          <div class="feed-comment-avatar">${escapeHtml(String(comment?.name || "C").charAt(0).toUpperCase())}</div>
          <div class="feed-comment-body">
            <div class="feed-comment-bubble">
              <strong>${escapeHtml(comment?.name || "Cliente")}</strong>
              <p>${escapeHtml(comment?.body || "")}</p>
            </div>
            <div class="feed-comment-actions">
              <button class="feed-comment-like${likedClass}" type="button" data-feed-comment-like="${escapeHtml(commentId)}" aria-label="Me gusta"${disabledAttr}>
                <span class="feed-comment-heart-icon" aria-hidden="true">${getFeedHeartIcon(Boolean(comment?.likedByMe))}</span>
              </button>
              <button class="feed-comment-likes-count" type="button" data-feed-comment-likes-open="${escapeHtml(commentId)}">
                ${formatFeedSocialCount(comment?.likesCount || 0, "like", "likes")}
              </button>
              ${deleteMarkup}
            </div>
          </div>
        </article>
      `;
    })
    .join("");
}

function renderActiveFeedSocialSheet() {
  if (state.selectedLikesPostId) {
    const post = findFeedPost(state.selectedLikesPostId);
    const comment = state.selectedCommentLikesId
      ? (post?.comments || []).find((item) => String(item?.id || item?._id || "") === state.selectedCommentLikesId)
      : null;
    renderFeedPersonList(feedLikesList, comment ? comment.likes || [] : post?.likes || [], "Todavía no hay likes.");
  }

  if (state.selectedCommentsPostId) {
    const post = findFeedPost(state.selectedCommentsPostId);
    renderFeedCommentsList(post);
  }
}

function hasOpenClientModal() {
  return [
    feedLikesModal,
    feedCommentsModal,
    maintenanceVehicleModal,
    notificationsModal,
    virtualDealershipImageModal,
    virtualDealershipVideoModal,
  ].some((modal) => modal && !modal.hidden);
}

function setFeedSocialOpenState(isOpen) {
  document.body.classList.toggle("feed-social-open", Boolean(isOpen));
}

function syncFeedSocialOpenState() {
  setFeedSocialOpenState(Boolean(
    (feedLikesModal && !feedLikesModal.hidden) || (feedCommentsModal && !feedCommentsModal.hidden)
  ));
}

function openFeedLikesSheet(postId) {
  const post = findFeedPost(postId);

  if (!post || !feedLikesModal) {
    return;
  }

  state.selectedLikesPostId = getFeedPostId(post);
  state.selectedCommentLikesId = "";
  renderFeedPersonList(feedLikesList, post.likes || [], "Todavía no hay likes.");
  feedLikesModal.classList.remove("is-raised");
  feedLikesModal.hidden = false;
  setFeedSocialOpenState(true);
  document.body.classList.add("modal-open");
}

function openFeedCommentLikesSheet(postId, commentId) {
  const post = findFeedPost(postId);
  const comment = (post?.comments || []).find((item) => String(item?.id || item?._id || "") === String(commentId || ""));

  if (!post || !comment || !feedLikesModal) {
    return;
  }

  state.selectedLikesPostId = getFeedPostId(post);
  state.selectedCommentLikesId = String(commentId || "");
  renderFeedPersonList(feedLikesList, comment.likes || [], "Todavía no hay likes.");
  feedLikesModal.classList.add("is-raised");
  feedLikesModal.hidden = false;
  setFeedSocialOpenState(true);
  document.body.classList.add("modal-open");
}

function openFeedCommentsSheet(postId) {
  const post = findFeedPost(postId);

  if (!post || !feedCommentsModal) {
    return;
  }

  state.selectedCommentsPostId = getFeedPostId(post);
  state.commentDraft = "";
  if (feedCommentInput) {
    feedCommentInput.value = "";
  }
  setFeedActionMessage("");
  renderFeedCommentsList(post);
  feedCommentsModal.hidden = false;
  setFeedSocialOpenState(true);
  document.body.classList.add("modal-open");
}

function closeFeedSocialSheets() {
  state.selectedLikesPostId = "";
  state.selectedCommentLikesId = "";
  state.selectedCommentsPostId = "";
  state.commentDraft = "";

  if (feedLikesModal) {
    feedLikesModal.classList.remove("is-raised");
    feedLikesModal.hidden = true;
  }

  if (feedCommentsModal) {
    feedCommentsModal.hidden = true;
  }

  if (feedCommentInput) {
    feedCommentInput.value = "";
  }

  setFeedActionMessage("");
  syncFeedSocialOpenState();
  document.body.classList.toggle("modal-open", hasOpenClientModal());
}

function closeFeedLikesSheet() {
  state.selectedLikesPostId = "";
  state.selectedCommentLikesId = "";

  if (feedLikesModal) {
    feedLikesModal.classList.remove("is-raised");
    feedLikesModal.hidden = true;
  }

  syncFeedSocialOpenState();
  document.body.classList.toggle("modal-open", hasOpenClientModal());
}

function renderFeed() {
  if (!state.feedPosts.length && !state.isFetchingFeed) {
    renderEmptyState(feedContainer, "Todavía no hay publicaciones activas para tu feed.");
    feedLoadingState.textContent = "";
    void applyFeedMediaLayout();
    return;
  }

  feedContainer.innerHTML = state.feedPosts
    .map((post, index) => {
      const mediaMarkup = (post.media || [])
        .map((item) => {
          if (item.type === "video") {
            return renderFeedVideoMedia(item.url);
          }

          return `
            <div class="feed-media-card">
              <img src="${escapeHtml(item.url)}" alt="${escapeHtml(item.caption || post.title)}" loading="lazy" />
            </div>
          `;
        })
        .join("");
      const carouselDotsMarkup = post.media?.length > 1
        ? `
            <div class="feed-carousel-indicators" data-feed-carousel-indicators>
              ${post.media
                .map(
                  (_, mediaIndex) => `
                    <button
                      class="feed-carousel-dot ${mediaIndex === 0 ? "is-active" : ""}"
                      type="button"
                      data-feed-carousel-dot
                      data-feed-carousel-index="${mediaIndex}"
                      aria-label="Ir a la imagen ${mediaIndex + 1}"
                    ></button>
                  `
                )
                .join("")}
            </div>
          `
        : "";

      const authorName = "Global Imports";
      const publishedDate = new Date(post.publishedAt || post.createdAt);
      const relativeDate = publishedDate.toLocaleDateString("es-VE", {
        month: "short",
        day: "numeric",
      });
      const relativeTime = publishedDate.toLocaleTimeString("es-VE", {
        hour: "numeric",
        minute: "2-digit",
      });
      const postKey = escapeHtml(post._id || `feed-post-${index}`);
      const rawPostKey = getFeedPostId(post) || `feed-post-${index}`;
      const likes = Array.isArray(post.likes) ? post.likes : [];
      const likesCount = Number(post.likesCount ?? likes.length ?? 0);
      const commentsCount = Number(post.commentsCount ?? post.comments?.length ?? 0);
      const isLikePending = pendingFeedLikeIdsRef.has(rawPostKey);
      const likeButtonClass = post.likedByMe ? " is-liked" : "";
      const likeButtonDisabled = isLikePending ? " disabled" : "";
      const heartIcon = getFeedHeartIcon(Boolean(post.likedByMe));

      return `
        <article class="feed-card" data-feed-post-id="${postKey}">
          <div class="feed-author-row">
            <div class="feed-author-meta">
              <div class="feed-author-avatar">
                <img src="/logoblancoleon.png" alt="Logo Global Imports" loading="lazy" />
              </div>
              <div>
                <strong>${authorName}</strong>
                <p>${escapeHtml(relativeDate)} · ${escapeHtml(relativeTime)}</p>
              </div>
            </div>
          </div>
          ${mediaMarkup ? `
            <div class="feed-media-shell" data-feed-like-zone>
              <div class="feed-media-strip ${post.media?.length > 1 ? "is-carousel" : ""}" ${post.media?.length > 1 ? 'data-feed-carousel' : ""}>${mediaMarkup}</div>
              ${carouselDotsMarkup}
            </div>
          ` : ""}
          <div class="feed-action-row">
            <div class="feed-action-group">
              <button class="feed-action-button${likeButtonClass}" type="button" data-feed-like="${postKey}"${likeButtonDisabled} aria-label="Me gusta">
                <span class="feed-action-icon feed-heart-icon" aria-hidden="true">${heartIcon}</span>
              </button>
              <button class="feed-action-count" type="button" data-feed-likes-open="${postKey}" aria-label="Ver likes">
                ${likesCount}
              </button>
            </div>
            <div class="feed-action-group">
              <button class="feed-action-button" type="button" data-feed-comments-open="${postKey}" aria-label="Comentar">
                <span class="feed-action-icon feed-comment-main-icon" aria-hidden="true">
                  <svg viewBox="0 0 24 24" focusable="false">
                    <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 8.7 8.7 0 0 1-3.7-.8L3 21l1.8-5.5a8.7 8.7 0 0 1-.8-3.7A8.5 8.5 0 0 1 12.5 3h.5a8 8 0 0 1 8 8v.5Z" />
                  </svg>
                </span>
              </button>
              <button class="feed-action-count" type="button" data-feed-comments-open="${postKey}" aria-label="Ver comentarios">
                ${commentsCount}
              </button>
            </div>
          </div>
          <div class="feed-story-copy" data-feed-like-zone>
            <h3>${escapeHtml(post.title)}</h3>
            <div class="feed-card-copy-shell">
              <p class="feed-card-copy is-collapsed" data-feed-copy>${escapeHtml(post.body)}</p>
              <button class="feed-card-toggle" type="button" data-feed-toggle hidden>
                <span class="feed-card-toggle-prefix">...</span>
                <span class="feed-card-toggle-label">ver más</span>
              </button>
            </div>
          </div>
        </article>
      `;
    })
    .join("");

  syncFeedCopyClamp();
  void applyFeedMediaLayout();

  if (state.isFetchingFeed && state.feedPosts.length) {
    feedLoadingState.textContent = "Cargando más publicaciones...";
  } else if (!state.feedHasMore && state.feedPosts.length) {
    feedLoadingState.textContent = "Ya viste las publicaciones disponibles.";
  } else {
    feedLoadingState.textContent = "";
  }
}

function updateCarouselDots(carouselElement) {
  const shell = carouselElement.closest(".feed-media-shell");
  const dots = Array.from(shell?.querySelectorAll("[data-feed-carousel-dot]") || []);

  if (!dots.length) {
    return;
  }

  const activeIndex = Math.round(carouselElement.scrollLeft / Math.max(carouselElement.clientWidth, 1));

  dots.forEach((dot, index) => {
    dot.classList.toggle("is-active", index === activeIndex);
  });
}

function bindFeedCarousels() {
  feedContainer.querySelectorAll("[data-feed-carousel]").forEach((carouselElement) => {
    if (carouselElement.dataset.carouselBound === "true") {
      updateCarouselDots(carouselElement);
      return;
    }

    carouselElement.dataset.carouselBound = "true";
    updateCarouselDots(carouselElement);

    carouselElement.addEventListener("scroll", () => {
      updateCarouselDots(carouselElement);
    }, { passive: true });
  });
}

function syncFeedCopyClamp() {
  feedContainer.querySelectorAll("[data-feed-copy]").forEach((copyElement) => {
    const toggleButton = copyElement.parentElement?.querySelector("[data-feed-toggle]");

    if (!toggleButton) {
      return;
    }

    copyElement.classList.remove("is-expanded");
    copyElement.classList.add("is-collapsed");
    toggleButton.classList.remove("is-expanded");
    toggleButton.querySelector(".feed-card-toggle-label").textContent = "ver más";

    const hasOverflow = copyElement.scrollHeight > copyElement.clientHeight + 2;
    toggleButton.hidden = !hasOverflow;
  });
}

function updateRefreshIndicator() {
  if (!refreshIndicator || !refreshLabel) {
    return;
  }

  refreshIndicator.style.setProperty("--pull-distance", `${Math.min(pullDistance, 96)}px`);

  if (state.isRefreshingFeed) {
    refreshIndicator.classList.add("is-active");
    refreshIndicator.classList.add("is-refreshing");
    refreshLabel.textContent = "Actualizando publicaciones...";
    return;
  }

  refreshIndicator.classList.remove("is-refreshing");
  refreshIndicator.classList.toggle("is-active", pullDistance > 8);
  refreshLabel.textContent =
    pullDistance >= PULL_REFRESH_THRESHOLD
      ? "Suelta para actualizar"
      : "Desliza hacia abajo para actualizar";
}

function isPullRefreshAvailable() {
  if (!refreshIndicator || !refreshLabel) {
    return false;
  }

  if (document.body.classList.contains("modal-open")) {
    return false;
  }

  return true;
}

async function loadFeedPage({ reset = false } = {}) {
  if (state.isFetchingFeed) {
    return;
  }

  if (!reset && !state.feedHasMore) {
    return;
  }

  state.isFetchingFeed = true;

  await loadLocalDevFeedPreviewConfig().catch(() => null);

  if (reset) {
    state.feedOffset = 0;
    state.feedHasMore = true;
    state.feedPosts = [];
    feedLoadingState.textContent = "Actualizando publicaciones...";
  }

  let requestFailed = false;
  let requestErrorMessage = "";

  try {
    const data = await fetchJson(`/api/client/posts?offset=${state.feedOffset}&limit=${FEED_PAGE_SIZE}`);
    const nextPosts = data.posts || [];

    state.feedPosts = reset ? nextPosts : state.feedPosts.concat(nextPosts);
    state.feedOffset = data.pagination?.nextOffset || state.feedPosts.length;
    state.feedHasMore = Boolean(data.pagination?.hasMore);
  } catch (error) {
    requestFailed = true;
    requestErrorMessage = error?.message || "No se pudieron cargar más publicaciones.";
    throw error;
  } finally {
    state.isFetchingFeed = false;

    if (state.isRefreshingFeed) {
      state.isRefreshingFeed = false;
      pullDistance = 0;
      updateRefreshIndicator();
    }

    renderFeed();

    if (requestFailed && state.feedPosts.length) {
      feedLoadingState.textContent = requestErrorMessage;
    } else if (state.feedPosts.length && state.feedHasMore) {
      feedLoadingState.textContent = "Desliza hacia abajo para ver más publicaciones.";
    }
  }
}

async function refreshFeed() {
  if (state.isRefreshingFeed) {
    return;
  }

  if (state.activeView !== "home") {
    state.isRefreshingFeed = true;
    updateRefreshIndicator();

    try {
      await loadDashboard();

      if (state.activeView === "virtual-dealership") {
        await loadVirtualDealership();
      }
    } finally {
      state.isRefreshingFeed = false;
      pullDistance = 0;
      updateRefreshIndicator();
    }

    return;
  }

  state.isRefreshingFeed = true;
  updateRefreshIndicator();
  await loadFeedPage({ reset: true });
}

function handleWheelRefresh(event) {
  if (!isPullRefreshAvailable() || state.isRefreshingFeed || state.isFetchingFeed) {
    wheelUpRefreshAccumulator = 0;
    return;
  }

  if (window.scrollY > 2) {
    wheelUpRefreshAccumulator = 0;
    return;
  }

  const deltaY = Number(event.deltaY || 0);

  if (deltaY >= 0) {
    wheelUpRefreshAccumulator = 0;
    return;
  }

  // Track continuous upward wheel motion at the top to trigger a feed refresh.
  wheelUpRefreshAccumulator += Math.abs(deltaY);

  if (wheelUpRefreshAccumulator < 120) {
    return;
  }

  const now = Date.now();

  if (now - lastWheelRefreshAt < 1200) {
    return;
  }

  wheelUpRefreshAccumulator = 0;
  lastWheelRefreshAt = now;

  refreshFeed().catch((error) => {
    state.isRefreshingFeed = false;
    pullDistance = 0;
    updateRefreshIndicator();
    feedLoadingState.textContent = error.message;
  });
}

function setupInfiniteScroll() {
  if (!feedLoadMoreSentinel) {
    return;
  }

  if (feedObserver) {
    feedObserver.disconnect();
  }

  feedObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting && state.activeView === "home") {
          loadFeedPage().catch((error) => {
            feedLoadingState.textContent = error.message;
          });
        }
      });
    },
    {
      root: null,
      rootMargin: "0px 0px 240px 0px",
      threshold: 0.01,
    }
  );

  feedObserver.observe(feedLoadMoreSentinel);
}

function setupVirtualDealershipInfiniteScroll() {
  if (!virtualDealershipLoadMoreSentinel) {
    return;
  }

  if (virtualDealershipObserver) {
    virtualDealershipObserver.disconnect();
  }

  virtualDealershipObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting || state.activeView !== "virtual-dealership") {
          return;
        }

        if (state.virtualDealershipVisibleCount >= state.virtualDealershipVehicles.length) {
          return;
        }

        state.virtualDealershipVisibleCount = Math.min(
          state.virtualDealershipVisibleCount + VIRTUAL_DEALERSHIP_BATCH_SIZE,
          state.virtualDealershipVehicles.length
        );
        renderVirtualDealership();
      });
    },
    {
      root: null,
      rootMargin: "0px 0px 260px 0px",
      threshold: 0.01,
    }
  );

  virtualDealershipObserver.observe(virtualDealershipLoadMoreSentinel);
}

async function handleFeedPostLike(postId) {
  if (!postId || pendingFeedLikeIdsRef.has(postId)) {
    return;
  }

  const currentPost = findFeedPost(postId);
  const shouldAnimateLike = !currentPost?.likedByMe;
  const likeButton = getFeedArticleElement(postId)?.querySelector("[data-feed-like]");

  if (shouldAnimateLike) {
    playFeedLikeAnimation(postId);
  }

  pendingFeedLikeIdsRef.add(postId);
  if (likeButton) {
    likeButton.disabled = true;
  }

  try {
    const data = await toggleFeedPostLike(postId);
    if (data.post) {
      replaceFeedItem(data.post, { render: false });
    }
  } catch (error) {
    feedLoadingState.textContent = error.message || "No se pudo actualizar el like.";
  } finally {
    pendingFeedLikeIdsRef.delete(postId);
    const updatedPost = findFeedPost(postId);
    if (updatedPost) {
      syncFeedArticleSocialState(updatedPost);
    }
    renderActiveFeedSocialSheet();
  }
}

async function handleCreateFeedComment(event) {
  event.preventDefault();

  const postId = state.selectedCommentsPostId;
  const body = String(feedCommentInput?.value || "").trim();

  if (!postId) {
    return;
  }

  if (!body) {
    setFeedActionMessage("Escribe un comentario antes de publicar.", "error");
    return;
  }

  if (body.length > 800) {
    setFeedActionMessage("El comentario no puede superar 800 caracteres.", "error");
    return;
  }

  if (feedCommentSubmit) {
    feedCommentSubmit.disabled = true;
  }
  setFeedActionMessage("Publicando comentario...");

  try {
    const data = await createFeedComment(postId, { body });
    if (data.post) {
      replaceFeedItem(data.post);
    }
    if (feedCommentInput) {
      feedCommentInput.value = "";
    }
    state.commentDraft = "";
    setFeedActionMessage("Comentario publicado.", "success");
  } catch (error) {
    setFeedActionMessage(error.message || "No se pudo publicar el comentario.", "error");
  } finally {
    if (feedCommentSubmit) {
      feedCommentSubmit.disabled = false;
    }
  }
}

async function handleDeleteFeedComment(postId, commentId) {
  if (!postId || !commentId) {
    return;
  }

  setFeedActionMessage("Eliminando comentario...");

  try {
    const data = await deleteFeedComment(postId, commentId);
    if (data.post) {
      replaceFeedItem(data.post);
    }
    setFeedActionMessage("Comentario eliminado.", "success");
  } catch (error) {
    setFeedActionMessage(error.message || "No se pudo eliminar el comentario.", "error");
  }
}

async function handleFeedCommentLike(postId, commentId) {
  const likeKey = `${postId}:${commentId}`;

  if (!postId || !commentId || pendingFeedCommentLikeKeysRef.has(likeKey)) {
    return;
  }

  pendingFeedCommentLikeKeysRef.add(likeKey);
  renderActiveFeedSocialSheet();

  try {
    const data = await toggleFeedCommentLike(postId, commentId);
    if (data.post) {
      replaceFeedItem(data.post);
    }
  } catch (error) {
    setFeedActionMessage(error.message || "No se pudo actualizar el like.", "error");
  } finally {
    pendingFeedCommentLikeKeysRef.delete(likeKey);
    renderActiveFeedSocialSheet();
  }
}

function isFeedVideoInteractionTarget(target) {
  return Boolean(
    target?.closest?.(".feed-media-card.video, iframe, .feed-video-play-trigger, .feed-video-sound-trigger")
  );
}

function shouldIgnoreFeedLikeGesture(target) {
  return Boolean(target.closest("button, a, input, textarea, select, label, iframe, .feed-media-card.video"));
}

function getFeedLikeZonePostId(target) {
  if (shouldIgnoreFeedLikeGesture(target)) {
    return "";
  }

  const likeZone = target.closest("[data-feed-like-zone]");
  const article = likeZone?.closest("[data-feed-post-id]");
  return String(article?.dataset.feedPostId || "");
}

function registerFeedDoubleTapLike(postId) {
  if (!postId) {
    return;
  }

  handleFeedPostLike(postId).catch(() => null);
}

feedContainer.addEventListener("dblclick", (event) => {
  const postId = getFeedLikeZonePostId(event.target);

  if (!postId) {
    return;
  }

  event.preventDefault();
  registerFeedDoubleTapLike(postId);
});

feedContainer.addEventListener("touchend", (event) => {
  if (pullDistance > 8 || event.changedTouches.length !== 1) {
    return;
  }

  const postId = getFeedLikeZonePostId(event.target);

  if (!postId) {
    return;
  }

  const now = Date.now();
  const isDoubleTap = postId === lastFeedTapPostId && now - lastFeedTapAt <= 340;

  lastFeedTapAt = now;
  lastFeedTapPostId = postId;

  if (isDoubleTap) {
    lastFeedTapAt = 0;
    lastFeedTapPostId = "";
    registerFeedDoubleTapLike(postId);
  }
}, { passive: true });

feedContainer.addEventListener("click", (event) => {
  const likeButton = event.target.closest("[data-feed-like]");

  if (likeButton) {
    handleFeedPostLike(likeButton.dataset.feedLike).catch(() => null);
    return;
  }

  const likesOpenButton = event.target.closest("[data-feed-likes-open]");

  if (likesOpenButton) {
    openFeedLikesSheet(likesOpenButton.dataset.feedLikesOpen);
    return;
  }

  const commentsOpenButton = event.target.closest("[data-feed-comments-open]");

  if (commentsOpenButton) {
    openFeedCommentsSheet(commentsOpenButton.dataset.feedCommentsOpen);
    return;
  }

  const carouselDot = event.target.closest("[data-feed-carousel-dot]");

  if (carouselDot) {
    const carouselShell = carouselDot.closest(".feed-media-shell");
    const carouselElement = carouselShell?.querySelector("[data-feed-carousel]");
    const targetIndex = Number(carouselDot.dataset.feedCarouselIndex || 0);

    if (carouselElement) {
      carouselElement.scrollTo({
        left: carouselElement.clientWidth * targetIndex,
        behavior: "smooth",
      });
    }

    return;
  }

  const toggleButton = event.target.closest("[data-feed-toggle]");

  if (!toggleButton) {
    return;
  }

  const copyElement = toggleButton.parentElement?.querySelector("[data-feed-copy]");

  if (!copyElement) {
    return;
  }

  const willExpand = !copyElement.classList.contains("is-expanded");
  copyElement.classList.toggle("is-expanded", willExpand);
  copyElement.classList.toggle("is-collapsed", !willExpand);
  toggleButton.classList.toggle("is-expanded", willExpand);
  toggleButton.querySelector(".feed-card-toggle-label").textContent = willExpand ? "ver menos" : "ver más";
});

feedCommentForm?.addEventListener("submit", handleCreateFeedComment);

feedCommentInput?.addEventListener("input", () => {
  state.commentDraft = feedCommentInput.value;
});

feedCommentsList?.addEventListener("click", (event) => {
  const postId = state.selectedCommentsPostId;
  const deleteButton = event.target.closest("[data-feed-comment-delete]");

  if (deleteButton) {
    handleDeleteFeedComment(postId, deleteButton.dataset.feedCommentDelete).catch(() => null);
    return;
  }

  const likeButton = event.target.closest("[data-feed-comment-like]");

  if (likeButton) {
    handleFeedCommentLike(postId, likeButton.dataset.feedCommentLike).catch(() => null);
    return;
  }

  const likesOpenButton = event.target.closest("[data-feed-comment-likes-open]");

  if (likesOpenButton) {
    openFeedCommentLikesSheet(postId, likesOpenButton.dataset.feedCommentLikesOpen);
  }
});

document.querySelectorAll("[data-feed-social-close]").forEach((button) => {
  button.addEventListener("click", (event) => {
    const modal = event.target.closest(".feed-social-modal");

    if (modal === feedLikesModal && feedCommentsModal && !feedCommentsModal.hidden) {
      closeFeedLikesSheet();
      return;
    }

    closeFeedSocialSheets();
  });
});

function handlePullStart(event) {
  if (!isPullRefreshAvailable() || window.scrollY > 0 || state.isRefreshingFeed) {
    isPulling = false;
    return;
  }

  if (isFeedVideoInteractionTarget(event.target)) {
    isPulling = false;
    return;
  }

  touchStartY = event.touches[0].clientY;
  pullDistance = 0;
  isPulling = true;
  updateRefreshIndicator();
}

function handlePullMove(event) {
  if (!isPulling) {
    return;
  }

  if (isFeedVideoInteractionTarget(event.target)) {
    isPulling = false;
    pullDistance = 0;
    updateRefreshIndicator();
    return;
  }

  const currentY = event.touches[0].clientY;
  const deltaY = currentY - touchStartY;

  if (deltaY <= 0) {
    pullDistance = 0;
    updateRefreshIndicator();
    return;
  }

  pullDistance = Math.min(deltaY * 0.6, 110);
  updateRefreshIndicator();

  if (pullDistance > 0) {
    event.preventDefault();
  }
}

function handlePullEnd() {
  if (!isPulling) {
    return;
  }

  isPulling = false;

  if (pullDistance >= PULL_REFRESH_THRESHOLD) {
    refreshFeed().catch((error) => {
      state.isRefreshingFeed = false;
      pullDistance = 0;
      updateRefreshIndicator();
      feedLoadingState.textContent = error.message;
    });
    return;
  }

  pullDistance = 0;
  updateRefreshIndicator();
}

function renderTrackingOptions() {
  trackingOptions.innerHTML = state.orders
    .map((order) => `<option value="${escapeHtml(order.trackingNumber)}"></option>`)
    .join("");
}

function formatCopCurrency(amount) {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0,
  }).format(Number(amount || 0));
}

function addDays(date, days) {
  const nextDate = new Date(date);
  nextDate.setDate(nextDate.getDate() + days);
  return nextDate;
}

function formatDateRange(startDate, endDate) {
  const formatter = new Intl.DateTimeFormat("es-CO", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return `${formatter.format(startDate)} - ${formatter.format(endDate)}`;
}

function resolveMaintenanceVehicleKey(vehicle, index) {
  return String(vehicle?._id || vehicle?.id || `maintenance-vehicle-${index}`);
}

function setMaintenanceVehicleModalMode(mode) {
  const isEdit = mode === "edit";
  const copy = resolveWorkshopBookingCopy();
  const quoteFields = document.getElementById("maintenance-quote-schedule-fields");
  const preferredDateInput = maintenanceVehicleForm?.elements?.preferredMaintenanceDate;
  const preferredTimeInput = maintenanceVehicleForm?.elements?.preferredMaintenanceTime;
  if (maintenanceVehicleTag) {
    maintenanceVehicleTag.textContent = isEdit ? "Mantenimiento" : copy.tag;
  }

  if (maintenanceVehicleTitle) {
    maintenanceVehicleTitle.textContent = isEdit ? "Edita tu vehículo" : copy.title;
  }

  if (maintenanceVehicleSubmitButton) {
    maintenanceVehicleSubmitButton.textContent = isEdit ? "Guardar cambios" : copy.submit;
  }

  if (maintenancePreferredDateLabel) {
    maintenancePreferredDateLabel.textContent = copy.dateLabel;
  }

  const hideMileageFields = !isEdit && isWorkshopServiceWithoutMileage();
  const mileageInput = maintenanceVehicleForm?.elements?.currentMileage;
  const dailyKmInput = maintenanceVehicleForm?.elements?.usualDailyKm;

  if (maintenanceMileageField) {
    maintenanceMileageField.hidden = hideMileageFields;
  }

  if (maintenanceDailyKmField) {
    maintenanceDailyKmField.hidden = hideMileageFields;
  }

  const mileagePlateRow = document.getElementById("maintenance-mileage-plate-row");
  if (mileagePlateRow) {
    mileagePlateRow.classList.toggle("is-single-field", hideMileageFields);
  }

  if (mileageInput) {
    mileageInput.required = !hideMileageFields;
    if (hideMileageFields) {
      mileageInput.value = "";
    }
  }

  if (dailyKmInput) {
    dailyKmInput.required = !hideMileageFields;
    if (hideMileageFields) {
      dailyKmInput.value = "";
    }
  }

  const drivingCityInput = maintenanceVehicleForm?.elements?.drivingCity;
  if (maintenanceDrivingCityField) {
    maintenanceDrivingCityField.hidden = hideMileageFields;
  }

  if (drivingCityInput) {
    drivingCityInput.required = !hideMileageFields;
    if (hideMileageFields) {
      drivingCityInput.value = "";
    }
  }

  const isAccessoriesBooking = !isEdit && workshopBookingService === "accesorios";
  const accessoryInput = maintenanceVehicleForm?.elements?.desiredAccessory;

  if (accessoriesRequestField) {
    accessoriesRequestField.hidden = !isAccessoriesBooking;
  }

  if (accessoryInput) {
    accessoryInput.required = isAccessoriesBooking;
    if (!isAccessoriesBooking) {
      accessoryInput.value = "";
    }
  }

  if (quoteFields) {
    quoteFields.hidden = isEdit || isAccessoriesBooking;
  }

  if (preferredDateInput) {
    preferredDateInput.required = !isEdit && !isAccessoriesBooking;
    if (isEdit || isAccessoriesBooking) {
      preferredDateInput.value = "";
    }
  }

  if (preferredTimeInput) {
    preferredTimeInput.required = !isEdit && !isAccessoriesBooking;
    if (isEdit || isAccessoriesBooking) {
      preferredTimeInput.value = "";
    }
  }
}

function setMaintenanceVehicleFormValues(vehicle) {
  if (!maintenanceVehicleForm || !vehicle) {
    return;
  }

  maintenanceVehicleForm.elements.brand.value = vehicle.brand || "";
  maintenanceVehicleForm.elements.model.value = vehicle.model || "";
  maintenanceVehicleForm.elements.version.value = vehicle.version || "";
  maintenanceVehicleForm.elements.year.value = vehicle.year || "";
  maintenanceVehicleForm.elements.currentMileage.value = vehicle.currentMileage || "";
  maintenanceVehicleForm.elements.plate.value = vehicle.plate || "";
  maintenanceVehicleForm.elements.usualDailyKm.value = vehicle.usualDailyKm || "";
  maintenanceVehicleForm.elements.drivingCity.value = vehicle.drivingCity || "";

  if (vehicle.lastPreventiveMaintenanceDate) {
    const dateValue = new Date(vehicle.lastPreventiveMaintenanceDate);
    if (!Number.isNaN(dateValue.getTime())) {
      maintenanceVehicleForm.elements.lastPreventiveMaintenanceDate.value = dateValue.toISOString().slice(0, 10);
    }
  }

  if (maintenanceVehicleForm.elements.preferredMaintenanceDate && vehicle.preferredMaintenanceDate) {
    const preferredDate = new Date(vehicle.preferredMaintenanceDate);
    if (!Number.isNaN(preferredDate.getTime())) {
      maintenanceVehicleForm.elements.preferredMaintenanceDate.value = preferredDate.toISOString().slice(0, 10);
    }
  }

  if (maintenanceVehicleForm.elements.preferredMaintenanceTime) {
    maintenanceVehicleForm.elements.preferredMaintenanceTime.value = vehicle.preferredMaintenanceTime || "";
  }
}

function openMaintenanceVehicleModal(vehicle = null) {
  if (!maintenanceVehicleModal) {
    return;
  }

  if (maintenanceVehicleForm) {
    maintenanceVehicleForm.reset();
  }

  if (vehicle && (vehicle._id || vehicle.id)) {
    editingMaintenanceVehicleId = String(vehicle._id || vehicle.id);
    setMaintenanceVehicleModalMode("edit");
    setMaintenanceVehicleFormValues(vehicle);
  } else {
    editingMaintenanceVehicleId = "";
    setMaintenanceVehicleModalMode("create");
  }

  maintenanceVehicleModal.hidden = false;
  document.body.classList.add("modal-open");
}

function closeMaintenanceVehicleModal() {
  if (!maintenanceVehicleModal) {
    return;
  }

  editingMaintenanceVehicleId = "";
  if (maintenanceVehicleForm) {
    maintenanceVehicleForm.reset();
  }
  setMaintenanceVehicleModalMode("create");

  maintenanceVehicleModal.hidden = true;
  const shouldKeepModalOpen = (notificationsModal && !notificationsModal.hidden)
    || (virtualDealershipImageModal && !virtualDealershipImageModal.hidden)
    || (virtualDealershipVideoModal && !virtualDealershipVideoModal.hidden);
  document.body.classList.toggle("modal-open", Boolean(shouldKeepModalOpen));
}

function resolveVirtualVehicleKey(vehicle, index) {
  return String(vehicle?._id || vehicle?.id || `virtual-vehicle-${index}`);
}

function renderVirtualDealershipImageModal(animated = false) {
  if (!virtualDealershipImageTrack) {
    return;
  }

  const safeIndex = Math.min(
    Math.max(virtualDealershipModalImageIndex, 0),
    Math.max(virtualDealershipModalImages.length - 1, 0)
  );
  const currentImage = virtualDealershipModalImages[safeIndex] || null;

  if (!currentImage) {
    virtualDealershipImageTrack.innerHTML = "";
    if (virtualDealershipImageDots) {
      virtualDealershipImageDots.innerHTML = "";
    }
    return;
  }

  virtualDealershipModalImageIndex = safeIndex;

  const existingSlides = virtualDealershipImageTrack.querySelectorAll(".virtual-dealership-image-slide");
  if (existingSlides.length !== virtualDealershipModalImages.length) {
    virtualDealershipImageTrack.innerHTML = virtualDealershipModalImages
      .map(
        (image) => `
          <div class="virtual-dealership-image-slide">
            <img src="${escapeHtml(image.url || "")}" alt="${escapeHtml(image.alt || "Imagen del vehículo")}" loading="eager" />
          </div>
        `
      )
      .join("");
    animated = false;
  }

  if (!animated) {
    virtualDealershipImageTrack.classList.add("no-transition");
    virtualDealershipImageTrack.style.transform = `translateX(-${safeIndex * 100}%)`;
    void virtualDealershipImageTrack.offsetWidth;
    virtualDealershipImageTrack.classList.remove("no-transition");
  } else {
    virtualDealershipImageTrack.style.transform = `translateX(-${safeIndex * 100}%)`;
  }

  if (virtualDealershipImageDots) {
    const existingDots = virtualDealershipImageDots.querySelectorAll(".virtual-dealership-image-dot");
    if (existingDots.length === virtualDealershipModalImages.length) {
      existingDots.forEach((dot, i) => dot.classList.toggle("is-active", i === safeIndex));
    } else {
      virtualDealershipImageDots.innerHTML = virtualDealershipModalImages
        .map((_, index) => `<button type="button" class="virtual-dealership-image-dot ${index === safeIndex ? "is-active" : ""}" data-virtual-modal-dot-index="${index}" aria-label="Ver imagen ${index + 1}"></button>`)
        .join("");
    }
  }

  const hasMultipleImages = virtualDealershipModalImages.length > 1;

  if (virtualDealershipImagePrev) {
    virtualDealershipImagePrev.hidden = !hasMultipleImages;
  }

  if (virtualDealershipImageNext) {
    virtualDealershipImageNext.hidden = !hasMultipleImages;
  }
}

function stepVirtualDealershipImageModal(direction) {
  if (virtualDealershipModalImages.length <= 1) {
    return;
  }

  const nextIndex = (virtualDealershipModalImageIndex + direction + virtualDealershipModalImages.length)
    % virtualDealershipModalImages.length;
  virtualDealershipModalImageIndex = nextIndex;
  renderVirtualDealershipImageModal(true);
}

function openVirtualDealershipImageModal(vehicleKey, startIndex = 0) {
  if (!virtualDealershipImageModal || !virtualDealershipImageTrack || !vehicleKey) {
    return;
  }

  const matchedVehicle = (state.virtualDealershipVehicles || []).find(
    (vehicle, index) => resolveVirtualVehicleKey(vehicle, index) === String(vehicleKey)
  );

  const images = Array.isArray(matchedVehicle?.images)
    ? matchedVehicle.images.filter((item) => item && item.url)
    : [];

  if (!images.length) {
    return;
  }

  virtualDealershipModalImages = images.map((item, index) => ({
    url: String(item.url || ""),
    alt: String(item.caption || `${matchedVehicle?.brand || "Vehículo"} ${matchedVehicle?.model || ""} foto ${index + 1}`).trim(),
  }));
  virtualDealershipModalImageIndex = Math.min(Math.max(Number(startIndex) || 0, 0), virtualDealershipModalImages.length - 1);
  virtualDealershipImageTrack.innerHTML = "";

  renderVirtualDealershipImageModal(false);
  virtualDealershipImageModal.hidden = false;
  document.body.classList.add("modal-open");
}

function closeVirtualDealershipImageModal() {
  if (!virtualDealershipImageModal) {
    return;
  }

  virtualDealershipImageModal.hidden = true;

  if (virtualDealershipImageTrack) {
    virtualDealershipImageTrack.innerHTML = "";
  }

  virtualDealershipModalImages = [];
  virtualDealershipModalImageIndex = 0;

  if (virtualDealershipImageDots) {
    virtualDealershipImageDots.innerHTML = "";
  }

  const shouldKeepModalOpen = (notificationsModal && !notificationsModal.hidden)
    || (maintenanceVehicleModal && !maintenanceVehicleModal.hidden)
    || (virtualDealershipVideoModal && !virtualDealershipVideoModal.hidden);
  document.body.classList.toggle("modal-open", Boolean(shouldKeepModalOpen));
}

function formatVideoSlotLabel(hours, minutes) {
  const suffix = hours >= 12 ? "p. m." : "a. m.";
  const normalizedHour = hours % 12 || 12;
  const normalizedMinutes = String(minutes).padStart(2, "0");
  return `${normalizedHour}:${normalizedMinutes} ${suffix}`;
}

function getTodayInLocalDateInputFormat() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseDateInputValue(dateValue) {
  const value = String(dateValue || "").trim();

  if (!value) {
    return null;
  }

  const parts = value.split("-").map((part) => Number(part));

  if (parts.length !== 3 || parts.some((part) => Number.isNaN(part))) {
    return null;
  }

  const [year, month, day] = parts;
  return new Date(year, month - 1, day);
}

function isWeekday(date) {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    return false;
  }

  const day = date.getDay();
  return day >= 1 && day <= 5;
}

function getVideoSlotsForDate(dateValue) {
  const selectedDate = parseDateInputValue(dateValue);

  if (!selectedDate || !isWeekday(selectedDate)) {
    return [];
  }

  const now = new Date();
  const isToday = selectedDate.toDateString() === now.toDateString();
  const slots = [];

  for (let hour = 9; hour <= 15; hour += 1) {
    for (let minute = 0; minute < 60; minute += 15) {
      const slotDate = new Date(
        selectedDate.getFullYear(),
        selectedDate.getMonth(),
        selectedDate.getDate(),
        hour,
        minute,
        0,
        0
      );

      if (isToday && slotDate.getTime() <= now.getTime()) {
        continue;
      }

      const value = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
      slots.push({
        value,
        label: formatVideoSlotLabel(hour, minute),
      });
    }
  }

  return slots;
}

function setVirtualDealershipVideoFeedback(message, type = "") {
  if (!virtualDealershipVideoFeedback) {
    return;
  }

  virtualDealershipVideoFeedback.textContent = message || "";
  virtualDealershipVideoFeedback.classList.remove("is-error", "is-success");

  if (type === "error") {
    virtualDealershipVideoFeedback.classList.add("is-error");
  }

  if (type === "success") {
    virtualDealershipVideoFeedback.classList.add("is-success");
  }
}

function renderVirtualDealershipVideoSlots() {
  if (!virtualDealershipVideoSlots) {
    return;
  }

  const slots = getVideoSlotsForDate(virtualDealershipVideoContext.selectedDate);

  if (!virtualDealershipVideoContext.selectedDate) {
    virtualDealershipVideoSlots.innerHTML = '<option value="" disabled selected>Primero selecciona una fecha</option>';
    return;
  }

  if (!slots.length) {
    virtualDealershipVideoContext.selectedTime = "";
    virtualDealershipVideoSlots.innerHTML = '<option value="" disabled selected>Sin horarios disponibles para esta fecha</option>';
    return;
  }

  const currentSelected = virtualDealershipVideoContext.selectedTime;
  const hasCurrentSelected = slots.some((slot) => slot.value === currentSelected);

  if (!hasCurrentSelected) {
    virtualDealershipVideoContext.selectedTime = "";
  }

  virtualDealershipVideoSlots.innerHTML =
    '<option value="" disabled' + (virtualDealershipVideoContext.selectedTime ? '' : ' selected') + '>Elige un horario</option>' +
    slots
      .map((slot) => `<option value="${slot.value}"${slot.value === virtualDealershipVideoContext.selectedTime ? ' selected' : ''}>${slot.label}</option>`)
      .join("");
}

function openVirtualDealershipVideoModal(vehicleTitle, publicationUrl) {
  if (!virtualDealershipVideoModal || !vehicleTitle || !publicationUrl) {
    return;
  }

  const today = getTodayInLocalDateInputFormat();
  virtualDealershipVideoContext.vehicleTitle = String(vehicleTitle);
  virtualDealershipVideoContext.publicationUrl = String(publicationUrl);
  virtualDealershipVideoContext.selectedDate = today;
  virtualDealershipVideoContext.selectedTime = "";

  if (virtualDealershipVideoDescription) {
    virtualDealershipVideoDescription.textContent = `Mira ${vehicleTitle} en vivo y en directo con la ayuda de nuestro equipo. Selecciona fecha y hora (lunes a viernes, 9:00 a. m. a 4:00 p. m.).`;
  }

  if (virtualDealershipVideoDate) {
    virtualDealershipVideoDate.min = today;
    virtualDealershipVideoDate.value = today;
  }

  setVirtualDealershipVideoFeedback("");
  renderVirtualDealershipVideoSlots();
  virtualDealershipVideoModal.hidden = false;
  document.body.classList.add("modal-open");
}

function closeVirtualDealershipVideoModal() {
  if (!virtualDealershipVideoModal) {
    return;
  }

  virtualDealershipVideoModal.hidden = true;
  virtualDealershipVideoContext.selectedTime = "";
  setVirtualDealershipVideoFeedback("");

  const shouldKeepModalOpen = (notificationsModal && !notificationsModal.hidden)
    || (maintenanceVehicleModal && !maintenanceVehicleModal.hidden)
    || (virtualDealershipImageModal && !virtualDealershipImageModal.hidden)
    || (deleteAccountModal && !deleteAccountModal.hidden);
  document.body.classList.toggle("modal-open", Boolean(shouldKeepModalOpen));
}

function openDeleteAccountModal() {
  if (!deleteAccountModal) {
    return;
  }

  if (notificationsModal && !notificationsModal.hidden) {
    closeNotifications();
  }

  if (sessionMenu) {
    sessionMenu.hidden = true;
  }

  deleteAccountForm?.reset();
  setFeedback(deleteAccountFeedback, "");
  deleteAccountModal.hidden = false;
  document.body.classList.add("modal-open");
  window.setTimeout(() => deleteAccountPasswordInput?.focus(), 60);
}

function closeDeleteAccountModal() {
  if (!deleteAccountModal) {
    return;
  }

  deleteAccountModal.hidden = true;
  const shouldKeepModalOpen = (notificationsModal && !notificationsModal.hidden)
    || (maintenanceVehicleModal && !maintenanceVehicleModal.hidden)
    || (virtualDealershipImageModal && !virtualDealershipImageModal.hidden)
    || (virtualDealershipVideoModal && !virtualDealershipVideoModal.hidden);
  document.body.classList.toggle("modal-open", Boolean(shouldKeepModalOpen));
}

async function submitDeleteAccount() {
  const password = String(deleteAccountPasswordInput?.value || "");

  if (!password) {
    setFeedback(deleteAccountFeedback, "Escribe tu contraseña para confirmar.", "error");
    return;
  }

  if (deleteAccountConfirmButton) {
    deleteAccountConfirmButton.disabled = true;
  }

  setFeedback(deleteAccountFeedback, "Eliminando cuenta...");

  try {
    const response = await fetchJson("/api/auth/delete-account", {
      method: "POST",
      body: JSON.stringify({ password }),
    });

    await requestLogout();
    clearAuth();
    window.location.replace(buildDeletedAccountPageUrl(response.feedbackToken || ""));
  } catch (error) {
    setFeedback(deleteAccountFeedback, error.message, "error");
  } finally {
    if (deleteAccountConfirmButton) {
      deleteAccountConfirmButton.disabled = false;
    }
  }
}

function resetWorkshopStory(storyNode) {
  storyNode?.classList.remove("is-ready");
}

function playWorkshopStory(storyNode) {
  if (!storyNode) {
    return;
  }

  resetWorkshopStory(storyNode);
  window.requestAnimationFrame(() => {
    window.requestAnimationFrame(() => {
      storyNode.classList.add("is-ready");
    });
  });
}

function refreshMaintenanceButtonLabel() {
  if (!addMaintenanceVehicleButton) {
    return;
  }

  addMaintenanceVehicleButton.textContent = state.maintenanceVehicles.length
    ? "Agenda otro mantenimiento"
    : "Agenda tu mantenimiento";
}

function renderMaintenanceList() {
  const allItems = [];

  state.maintenanceVehicles.forEach((vehicle, index) => {
    allItems.push({
      source: "client-vehicle",
      vehicle,
      key: resolveMaintenanceVehicleKey(vehicle, index),
    });
  });

  state.maintenance.forEach((item) => {
    allItems.push({
      source: "order-maintenance",
      item,
    });
  });

  if (!allItems.length) {
    renderEmptyState(maintenanceList, "Todavía no tienes vehículos registrados en mantenimiento.");
    refreshMaintenanceButtonLabel();
    return;
  }

  maintenanceList.innerHTML = allItems
    .map((entry) => {
      if (entry.source === "client-vehicle") {
        const vehicle = entry.vehicle;
        const vehicleKey = entry.key;
        const detailsExpanded = state.maintenanceExpandedDetails.has(vehicleKey);
        const vehicleTitle = [vehicle.brand || "Vehículo", vehicle.model || "", vehicle.version || ""]
          .join(" ")
          .replace(/\s+/g, " ")
          .trim();

        return `
          <article class="maintenance-card">
            <div class="maintenance-card-top maintenance-card-top-compact">
              <div>
                <strong>${escapeHtml(vehicleTitle || "Vehículo")}</strong>
                <p>Último mantenimiento realizado: ${escapeHtml(vehicle.lastPreventiveMaintenanceDate ? formatDate(vehicle.lastPreventiveMaintenanceDate) : "Sin fecha")}</p>
                <button type="button" class="maintenance-details-link" data-maintenance-toggle-details="${escapeHtml(vehicleKey)}" aria-expanded="${detailsExpanded ? "true" : "false"}">Ver más detalles</button>
              </div>
              <div class="maintenance-card-actions-inline">
                <button type="button" class="maintenance-action-icon" data-maintenance-edit="${escapeHtml(vehicle._id || vehicle.id || "")}" aria-label="Editar vehículo">
                  <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zm14.71-9.04a1.003 1.003 0 0 0 0-1.42l-2.5-2.5a1.003 1.003 0 0 0-1.42 0L11.13 6.95l3.75 3.75 2.83-2.49z"></path></svg>
                </button>
                <button type="button" class="maintenance-action-icon is-danger" data-maintenance-delete="${escapeHtml(vehicle._id || vehicle.id || "")}" aria-label="Eliminar vehículo">
                  <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M18.3 5.71 12 12l6.3 6.29-1.41 1.42L10.59 13.4 4.29 19.7 2.88 18.3 9.17 12 2.88 5.71 4.29 4.29l6.3 6.3 6.29-6.3z"></path></svg>
                </button>
              </div>
            </div>
            <div class="maintenance-meta-grid ${detailsExpanded ? "is-open" : "is-collapsed"}">
              <div><span>Año</span><strong>${escapeHtml(vehicle.year || "N/A")}</strong></div>
              <div><span>Kilometraje actual</span><strong>${escapeHtml(vehicle.currentMileage || "0")}</strong></div>
              <div><span>Km diarios usuales</span><strong>${escapeHtml(vehicle.usualDailyKm || "N/A")}</strong></div>
              <div><span>Ubicación</span><strong>${escapeHtml(vehicle.drivingCity || "Sin ubicación")}</strong></div>
              <div><span>Placa</span><strong>${escapeHtml(vehicle.plate || "N/A")}</strong></div>
              <div><span>Creado</span><strong>${escapeHtml(vehicle.createdAt ? formatDate(vehicle.createdAt) : "Ahora")}</strong></div>
            </div>
            <p class="maintenance-note ${detailsExpanded ? "is-open" : "is-collapsed"}">Recibirás ofertas y cupones especiales para este vehículo.</p>
          </article>
        `;
      }

      const item = entry.item;

      return `
        <article class="maintenance-card">
          <div class="maintenance-card-top">
            <div>
              <strong>${escapeHtml(item.order?.vehicle?.brand || "Vehículo")} ${escapeHtml(item.order?.vehicle?.model || "")}</strong>
              <p>Guía ${escapeHtml(item.order?.trackingNumber || "Sin guía")}</p>
            </div>
            <span>${escapeHtml(item.status || "scheduled")}</span>
          </div>
          <div class="maintenance-meta-grid">
            <div><span>Próximo mantenimiento</span><strong>${escapeHtml(formatDate(item.dueDate))}</strong></div>
            <div><span>Kilometraje reportado</span><strong>${escapeHtml(item.reportedMileage || "Sin reporte")}</strong></div>
            <div><span>Último servicio</span><strong>${escapeHtml(item.lastServiceDate ? formatDate(item.lastServiceDate) : "Sin fecha")}</strong></div>
            <div><span>Última actualización</span><strong>${escapeHtml(item.lastClientUpdateAt ? formatDate(item.lastClientUpdateAt) : "Pendiente")}</strong></div>
          </div>
          <p class="maintenance-note">${escapeHtml(item.clientNotes || item.contactNotes || "Sin notas registradas.")}</p>
        </article>
      `;
    })
    .join("");

  refreshMaintenanceButtonLabel();
}

function buildMaintenanceQuoteWhatsappMessage(payload = {}) {
  const userName = String(state.user?.name || state.user?.fullName || "Cliente").trim() || "Cliente";
  const userEmail = String(state.user?.email || "").trim();
  const userPhone = String(state.user?.phone || "").trim();
  const vehicleTitle = [
    payload.brand,
    payload.model,
    payload.version,
    payload.year,
  ]
    .filter(Boolean)
    .join(" ")
    .trim();

  return [
    resolveWorkshopBookingCopy().whatsappIntro,
    "",
    `Servicio: ${resolveWorkshopBookingCopy().title.replace(/^Agenda tu /i, "").trim()}`,
    `Nombre: ${userName}`,
    userEmail ? `Email: ${userEmail}` : "",
    userPhone ? `Teléfono: ${userPhone}` : "",
    `Vehículo: ${vehicleTitle || "Sin detalle"}`,
    `Placa: ${payload.plate || "N/A"}`,
    workshopBookingService === "maintenance" ? `Kilometraje actual: ${payload.currentMileage || "N/A"}` : "",
    workshopBookingService === "maintenance" ? `Km diarios usuales: ${payload.usualDailyKm || "N/A"}` : "",
    workshopBookingService === "maintenance" ? `Ciudad: ${payload.drivingCity || "N/A"}` : "",
    workshopBookingService === "accesorios" ? `Accesorio a instalar: ${payload.desiredAccessory || "N/A"}` : `Último mantenimiento: ${payload.lastPreventiveMaintenanceDate || "N/A"}`,
    workshopBookingService === "accesorios" ? "" : `Fecha deseada: ${payload.preferredMaintenanceDate || "N/A"}`,
    workshopBookingService === "accesorios" ? "" : `Hora deseada: ${payload.preferredMaintenanceTime || "N/A"}`,
  ]
    .filter((line) => line !== "")
    .join("\n");
}

function openMaintenanceQuoteWhatsapp(message) {
  const whatsappUrl = new URL("https://api.whatsapp.com/send");
  whatsappUrl.searchParams.set("phone", "573016698126");
  whatsappUrl.searchParams.set("text", String(message || "").trim());
  openExternalBrowserUrl(whatsappUrl.toString());
  return whatsappUrl.toString();
}

async function submitMaintenanceVehicleForm() {
  if (!maintenanceVehicleForm) {
    return;
  }

  const formData = new FormData(maintenanceVehicleForm);
  const isEditing = Boolean(editingMaintenanceVehicleId);
  const skipMileageFields = !isEditing && isWorkshopServiceWithoutMileage();
  const isAccessoriesBooking = !isEditing && workshopBookingService === "accesorios";
  const usualDailyKm = skipMileageFields ? 10 : Number(formData.get("usualDailyKm"));
  const desiredAccessory = String(formData.get("desiredAccessory") || "").trim();

  if (!skipMileageFields && (Number.isNaN(usualDailyKm) || usualDailyKm < 10 || usualDailyKm > 200)) {
    throw new Error("Los kms diarios deben estar entre 10 y 200");
  }

  if (isAccessoriesBooking && !desiredAccessory) {
    throw new Error("Indica qué accesorio deseas instalar en tu vehículo.");
  }

  const todayInBogota = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Bogota" }).format(new Date());

  const payload = {
    brand: formData.get("brand"),
    model: formData.get("model"),
    version: formData.get("version"),
    year: formData.get("year"),
    currentMileage: skipMileageFields ? 0 : formData.get("currentMileage"),
    usualDailyKm,
    drivingCity: skipMileageFields ? "Bogota" : formData.get("drivingCity"),
    plate: formData.get("plate"),
    lastPreventiveMaintenanceDate: formData.get("lastPreventiveMaintenanceDate"),
    preferredMaintenanceDate: isAccessoriesBooking ? todayInBogota : formData.get("preferredMaintenanceDate"),
    preferredMaintenanceTime: isAccessoriesBooking ? "09:00" : formData.get("preferredMaintenanceTime"),
    desiredAccessory,
  };

  if (!isEditing && !isAccessoriesBooking) {
    if (!String(payload.preferredMaintenanceDate || "").trim()) {
      throw new Error("Indica la fecha en la que quieres el servicio.");
    }

    if (!String(payload.preferredMaintenanceTime || "").trim()) {
      throw new Error("Indica la hora en la que quieres el servicio.");
    }
  }

  const bookingCopy = resolveWorkshopBookingCopy();

  setFeedback(
    resolveWorkshopFeedback(),
    isEditing ? "Actualizando vehículo..." : bookingCopy.saving
  );

  await fetchJson(isEditing
    ? `/api/client/maintenance-vehicles/${encodeURIComponent(editingMaintenanceVehicleId)}`
    : "/api/client/maintenance-vehicles", {
    method: isEditing ? "PATCH" : "POST",
    body: JSON.stringify(payload),
  });

  closeMaintenanceVehicleModal();

  if (!isEditing) {
    openMaintenanceQuoteWhatsapp(buildMaintenanceQuoteWhatsappMessage(payload));
    setFeedback(
      resolveWorkshopFeedback(),
      bookingCopy.success,
      "success"
    );
  } else {
    setFeedback(resolveWorkshopFeedback(), "Vehículo actualizado correctamente.", "success");
  }

  await loadDashboard();
}

async function deleteMaintenanceVehicle(vehicleId) {
  const id = String(vehicleId || "").trim();

  if (!id) {
    return;
  }

  await fetchJson(`/api/client/maintenance-vehicles/${encodeURIComponent(id)}`, {
    method: "DELETE",
  });

  state.maintenanceExpandedDetails.delete(id);
  setFeedback(maintenanceFeedback, "Vehículo eliminado correctamente.", "success");
  await loadDashboard();
}

function getSelectedDeliveryOption() {
  return SEQUOIA_DELIVERY_OPTIONS[selectedSequoiaDeliveryCity] || SEQUOIA_DELIVERY_OPTIONS.barranquilla;
}

function getSequoiaOrderSummaryData() {
  const versionConfig = getActiveSequoiaConfig();
  const exteriorColor = getActiveSequoiaColor();
  const interiorColor = getActiveSequoiaInteriorColor();
  const deliveryOption = getSelectedDeliveryOption();
  const vehiclePrice = Number(versionConfig.price || 0);
  const deliveryFee = Number(deliveryOption.fee || 0);

  return {
    brand: "Toyota",
    model: "Sequoia",
    versionName: versionConfig.name,
    exteriorColorName: exteriorColor?.name || "No definido",
    interiorColorName: interiorColor?.name || "No definido",
    deliveryCityLabel: deliveryOption.label,
    vehiclePrice,
    deliveryFee,
    totalPrice: vehiclePrice + deliveryFee,
  };
}

function buildSequoiaWhatsappUrl(message) {
  const whatsappUrl = new URL("https://api.whatsapp.com/send");
  whatsappUrl.searchParams.set("phone", GLOBAL_WHATSAPP_NUMBER);

  if (message) {
    whatsappUrl.searchParams.set("text", message);
  }

  return whatsappUrl.toString();
}

function openExternalBrowserUrl(url, pendingWindow = null) {
  const resolvedUrl = String(url || "").trim();

  if (!resolvedUrl) {
    if (pendingWindow && !pendingWindow.closed) {
      pendingWindow.close();
    }
    return false;
  }

  const nativeExternalLinkHandler = window.webkit?.messageHandlers?.globalImportsExternalLink;

  if (nativeExternalLinkHandler?.postMessage) {
    try {
      if (pendingWindow && !pendingWindow.closed) {
        pendingWindow.close();
      }

      nativeExternalLinkHandler.postMessage({ url: resolvedUrl });
      return true;
    } catch (error) {
      console.warn("No se pudo abrir el enlace en el handler nativo.", error);
    }
  }

  if (pendingWindow && !pendingWindow.closed) {
    pendingWindow.opener = null;
    pendingWindow.location.replace(resolvedUrl);
    return true;
  }

  const openedWindow = window.open(resolvedUrl, "_blank", "noopener,noreferrer");

  if (openedWindow) {
    openedWindow.opener = null;
    return true;
  }

  const externalLink = document.createElement("a");
  externalLink.href = resolvedUrl;
  externalLink.target = "_blank";
  externalLink.rel = "noopener noreferrer external";
  (document.body || document.documentElement).appendChild(externalLink);
  externalLink.click();
  externalLink.remove();

  if (document.visibilityState === "visible") {
    window.location.assign(resolvedUrl);
  }

  return true;
}

function openSequoiaWhatsappChat(message) {
  const normalizedMessage = String(message || "").trim();
  const webUrl = buildSequoiaWhatsappUrl(normalizedMessage);
  openExternalBrowserUrl(webUrl);
  return webUrl;
}

function getSelectedOrderVehicleLabel() {
  if (!selectedOrderVehicle) {
    return "el vehículo";
  }

  const parts = [selectedOrderVehicle.brand, selectedOrderVehicle.model];

  if (selectedOrderVehicle.key === "sequoia") {
    const activeVersion = getActiveSequoiaConfig()?.name;

    if (activeVersion) {
      parts.push(activeVersion);
    }
  }

  return parts.filter(Boolean).join(" ").trim() || "el vehículo";
}

function renderSequoiaOrderSummary() {
  if (!sequoiaSummaryTitle) {
    return;
  }

  const summary = getSequoiaOrderSummaryData();
  const orderDate = new Date();
  const estimatedStartDate = addDays(orderDate, 75);
  const estimatedEndDate = addDays(orderDate, 90);

  sequoiaSummaryTitle.textContent = `${summary.brand} ${summary.model} ${summary.versionName}`;

  if (sequoiaSummaryDeliveryRange) {
    sequoiaSummaryDeliveryRange.textContent = formatDateRange(estimatedStartDate, estimatedEndDate);
  }

  if (sequoiaDeliveryCityButton) {
    sequoiaDeliveryCityButton.textContent = `Entrega en: ${summary.deliveryCityLabel}`;
  }

  if (sequoiaCitySelector) {
    sequoiaCitySelector.innerHTML = Object.entries(SEQUOIA_DELIVERY_OPTIONS)
      .map(([key, option]) => {
        const feeLabel = option.fee > 0 ? `+ ${formatCopCurrency(option.fee)}` : "Gratis";
        return `
          <button
            type="button"
            class="sequoia-city-option ${key === selectedSequoiaDeliveryCity ? "is-active" : ""}"
            data-delivery-city="${key}"
          >
            <span>${escapeHtml(option.label)}</span>
            <small>${escapeHtml(feeLabel)}</small>
          </button>
        `;
      })
      .join("");
  }

  if (sequoiaCityFeeNote) {
    sequoiaCityFeeNote.textContent = selectedSequoiaDeliveryCity === "barranquilla"
      ? "Entrega en el showroom de nuestra sede."
      : `${summary.deliveryCityLabel} ${formatCopCurrency(summary.deliveryFee)} por servicio de Niñera Express privada`;
  }

  if (sequoiaOrderDetails) {
    sequoiaOrderDetails.innerHTML = `
      <p><strong>Marca:</strong> ${escapeHtml(summary.brand)}</p>
      <p><strong>Modelo:</strong> ${escapeHtml(summary.model)}</p>
      <p><strong>Versión:</strong> ${escapeHtml(summary.versionName)}</p>
      <p><strong>Color:</strong> ${escapeHtml(summary.exteriorColorName)}</p>
      <p><strong>Cojinería:</strong> ${escapeHtml(summary.interiorColorName)}</p>
      <p><strong>Precio del vehículo:</strong> ${escapeHtml(formatCopCurrency(summary.vehiclePrice))}</p>
      <p><strong>Precio Niñera Express privada:</strong> ${escapeHtml(formatCopCurrency(summary.deliveryFee))}</p>
      <p><strong>Total:</strong> ${escapeHtml(formatCopCurrency(summary.totalPrice))}</p>
    `;
  }

  if (sequoiaSummaryTotalPrice) {
    sequoiaSummaryTotalPrice.textContent = formatCopCurrency(summary.totalPrice);
  }

  if (sequoiaSummaryFinancingLink) {
    const financeMessage = `Hola, quiero explorar financiamiento para una ${summary.brand} ${summary.model} ${summary.versionName}. Precio total estimado: ${formatCopCurrency(summary.totalPrice)}.`;
    sequoiaSummaryFinancingLink.href = buildSequoiaWhatsappUrl(financeMessage);
    sequoiaSummaryFinancingLink.setAttribute("data-whatsapp-message", encodeURIComponent(financeMessage));
  }

  if (sequoiaOrderDetails) {
    sequoiaOrderDetails.hidden = !isSequoiaOrderDetailsExpanded;
  }

  if (sequoiaOrderDetailsToggle) {
    sequoiaOrderDetailsToggle.textContent = isSequoiaOrderDetailsExpanded ? "Ocultar los detalles del pedido" : "Mostrar los detalles del pedido";
    sequoiaOrderDetailsToggle.setAttribute("aria-expanded", String(isSequoiaOrderDetailsExpanded));
  }
}

function getActiveSequoiaConfig() {
  const catalog = getSequoiaCatalog();
  const versionConfig = catalog.versionConfig || {};
  const fallbackVersionKey = catalog.versionOrder?.[0] || DEFAULT_SEQUOIA_VERSION_ORDER[0];

  return versionConfig[selectedSequoiaVersion] || versionConfig[fallbackVersionKey] || { name: "Sequoia", price: 0, specs: [], colors: [] };
}

function getActiveSequoiaColor() {
  const versionConfig = getActiveSequoiaConfig();
  return versionConfig.colors.find((item) => item.key === selectedSequoiaColor) || versionConfig.colors[0];
}

function getActiveSequoiaInteriorConfig() {
  const catalog = getSequoiaCatalog();
  const interiorConfig = catalog.interiorConfig || {};
  const fallbackVersionKey = catalog.versionOrder?.[0] || DEFAULT_SEQUOIA_VERSION_ORDER[0];

  return interiorConfig[selectedSequoiaVersion] || interiorConfig[fallbackVersionKey] || { colors: [] };
}

function getActiveSequoiaInteriorColor() {
  const interiorConfig = getActiveSequoiaInteriorConfig();
  return interiorConfig.colors.find((item) => item.key === selectedSequoiaInteriorColor) || interiorConfig.colors[0];
}

function renderSequoiaCarouselDots(images) {
  if (!sequoiaConfigDots) {
    return;
  }

  sequoiaConfigDots.innerHTML = images
    .map(
      (_, index) => `
        <button
          type="button"
          class="sequoia-config-dot ${index === selectedSequoiaImageIndex ? "is-active" : ""}"
          data-sequoia-dot-index="${index}"
          aria-label="Ir a imagen ${index + 1}"
        ></button>
      `
    )
    .join("");
}

function updateSequoiaMainImage() {
  const activeColor = getActiveSequoiaColor();

  if (!activeColor || !sequoiaConfigMainImage || !activeColor.images?.length) {
    return;
  }

  const safeIndex = ((selectedSequoiaImageIndex % activeColor.images.length) + activeColor.images.length) % activeColor.images.length;
  selectedSequoiaImageIndex = safeIndex;
  sequoiaConfigMainImage.src = activeColor.images[safeIndex];
  sequoiaConfigMainImage.alt = `Toyota Sequoia ${activeColor.name}`;
  sequoiaConfigImageFrame?.style.setProperty("--sequoia-color-tint", activeColor.tint || "rgba(0, 0, 0, 0)");
  renderSequoiaCarouselDots(activeColor.images);
}

function spinSequoiaImage(step) {
  const activeColor = getActiveSequoiaColor();

  if (!activeColor?.images?.length) {
    return;
  }

  selectedSequoiaImageIndex += step;
  updateSequoiaMainImage();
}

function updateSequoiaInteriorImage() {
  const activeInteriorColor = getActiveSequoiaInteriorColor();

  if (!activeInteriorColor || !sequoiaInteriorMainImage || !activeInteriorColor.images?.length) {
    return;
  }

  const safeIndex = ((selectedSequoiaInteriorImageIndex % activeInteriorColor.images.length) + activeInteriorColor.images.length) % activeInteriorColor.images.length;
  selectedSequoiaInteriorImageIndex = safeIndex;
  sequoiaInteriorMainImage.src = activeInteriorColor.images[safeIndex];
  sequoiaInteriorMainImage.alt = `Interior Toyota Sequoia ${activeInteriorColor.name}`;
}

function spinSequoiaInteriorImage(step) {
  const activeInteriorColor = getActiveSequoiaInteriorColor();

  if (!activeInteriorColor?.images?.length) {
    return;
  }

  selectedSequoiaInteriorImageIndex += step;
  updateSequoiaInteriorImage();
}

function renderSequoiaInterior() {
  const interiorConfig = getActiveSequoiaInteriorConfig();
  const activeInteriorColor = getActiveSequoiaInteriorColor();

  if (sequoiaInteriorColorName && activeInteriorColor) {
    sequoiaInteriorColorName.textContent = String(activeInteriorColor.name || "").toUpperCase();
  }

  if (sequoiaInteriorColors) {
    sequoiaInteriorColors.innerHTML = (interiorConfig.colors || [])
      .map(
        (color) => `
          <button
            type="button"
            class="sequoia-color-swatch ${color.key === selectedSequoiaInteriorColor ? "is-active" : ""}"
            data-sequoia-interior-color="${escapeHtml(color.key)}"
            aria-label="Color interior ${escapeHtml(color.name)}"
            title="${escapeHtml(color.name)}"
          >
            <span style="--swatch-color:${escapeHtml(color.hex)}"></span>
          </button>
        `
      )
      .join("");
  }

  if (!activeInteriorColor) {
    return;
  }

  if (!activeInteriorColor.images[selectedSequoiaInteriorImageIndex]) {
    selectedSequoiaInteriorImageIndex = 0;
  }

  updateSequoiaInteriorImage();
  renderSequoiaOrderSummary();
}

function showSequoiaVisionHint() {
  if (!sequoiaVisionHint) {
    return;
  }

  sequoiaVisionHint.classList.remove("is-hidden");

  if (sequoiaVisionHintTimeout) {
    clearTimeout(sequoiaVisionHintTimeout);
  }

  sequoiaVisionHintTimeout = setTimeout(() => {
    sequoiaVisionHint.classList.add("is-hidden");
  }, 3000);
}

function renderSequoiaConfigurator() {
  const catalog = getSequoiaCatalog();
  const versionConfig = getActiveSequoiaConfig();
  const activeColor = getActiveSequoiaColor();

  if (!catalog.versionOrder?.length || !versionConfig.colors?.length) {
    setSequoiaConfiguratorLoadingState("Cargando configurador...");
    return;
  }

  if (sequoiaConfigTitle) {
    sequoiaConfigTitle.textContent = `Toyota Sequoia ${versionConfig.name}`;
  }

  if (sequoiaConfigPrice) {
    sequoiaConfigPrice.textContent = formatCopCurrency(versionConfig.price);
  }

  if (sequoiaConfigColorName && activeColor) {
    sequoiaConfigColorName.textContent = String(activeColor.name || "").toUpperCase();
  }

  if (sequoiaConfigSpecs) {
    sequoiaConfigSpecs.innerHTML = versionConfig.specs
      .map(
        (spec) => `
          <article class="sequoia-spec-card">
            <strong>${escapeHtml(spec.value)}</strong>
            <span>${escapeHtml(spec.label)}</span>
          </article>
        `
      )
      .join("");
  }

  if (sequoiaConfigVersions) {
    sequoiaConfigVersions.innerHTML = catalog.versionOrder.map((versionKey) => {
      const current = catalog.versionConfig?.[versionKey];

      if (!current) {
        return "";
      }

      return `
        <button
          type="button"
          class="sequoia-version-card ${versionKey === selectedSequoiaVersion ? "is-active" : ""}"
          data-sequoia-version="${versionKey}"
        >
          <strong>${escapeHtml(current.name)}</strong>
          <span>${escapeHtml(formatCopCurrency(current.price))}</span>
        </button>
      `;
    }).join("");
  }

  if (sequoiaConfigColors) {
    sequoiaConfigColors.innerHTML = versionConfig.colors
      .map(
        (color) => `
          <button
            type="button"
            class="sequoia-color-swatch ${color.key === selectedSequoiaColor ? "is-active" : ""}"
            data-sequoia-color="${escapeHtml(color.key)}"
            aria-label="Color ${escapeHtml(color.name)}"
            title="${escapeHtml(color.name)}"
          >
            <span style="--swatch-color:${escapeHtml(color.hex)}"></span>
          </button>
        `
      )
      .join("");
  }

  if (!activeColor) {
    return;
  }

  if (!activeColor.images[selectedSequoiaImageIndex]) {
    selectedSequoiaImageIndex = 0;
  }

  updateSequoiaMainImage();
  renderSequoiaInterior();
  renderSequoiaOrderSummary();
}

function renderOrderActionCards(vehicleInfo) {
  if (!orderActionCards || !vehicleInfo) {
    return;
  }

  const vehicleTitle = `${vehicleInfo.brand} ${vehicleInfo.model}`.trim();
  const vehicleImages = ORDER_ACTION_IMAGES_BY_VEHICLE[vehicleInfo.key] || null;

  orderActionCards.innerHTML = ORDER_ACTION_TEMPLATES.map((item) => {
    const cardTitle = item.title.replace("{vehicle}", vehicleTitle);
    const imageUrl = resolveClientAssetUrl(vehicleImages?.[item.key] || item.image);

    return `
      <button
        class="order-action-card"
        type="button"
        data-order-action="${item.key}"
        style="--action-image:url('${imageUrl}')"
      >
        <strong>${escapeHtml(cardTitle)}</strong>
        <span>${escapeHtml(item.button)}</span>
      </button>
    `;
  }).join("");

  orderActionCards.hidden = false;
}

function activateOrderVehicleCard(cardButton) {
  if (!cardButton) {
    return;
  }

  orderVehicleCarousel?.querySelectorAll(".order-vehicle-card").forEach((button) => {
    button.classList.toggle("is-active", button === cardButton);
  });

  selectedOrderVehicle = {
    key: cardButton.dataset.vehicleKey || "",
    brand: cardButton.dataset.vehicleBrand || "",
    model: cardButton.dataset.vehicleModel || "",
  };

  const brandField = requestForm?.elements?.brand;
  if (brandField) {
    brandField.value = selectedOrderVehicle.brand;
  }

  const modelField = requestForm?.elements?.model;
  if (modelField) {
    modelField.value = selectedOrderVehicle.model;
  }

  renderOrderActionCards(selectedOrderVehicle);
  setActiveView("order-options", { direction: "forward" });
}

function bindOrderExperience() {
  if (!orderVehicleCarousel || !orderActionCards) {
    return;
  }

  orderVehicleCarousel.addEventListener("click", (event) => {
    const vehicleButton = event.target.closest(".order-vehicle-card");

    if (!vehicleButton) {
      return;
    }

    activateOrderVehicleCard(vehicleButton);
  });

  orderActionCards.addEventListener("click", (event) => {
    const actionButton = event.target.closest("[data-order-action]");

    if (!actionButton || !selectedOrderVehicle) {
      return;
    }

    const action = actionButton.dataset.orderAction;
    const vehicleLabel = getSelectedOrderVehicleLabel();
    const notesField = requestForm?.elements?.notes;

    if (action === "demo") {
      const message = `Hola, me encuentro interesado en la compra de una ${vehicleLabel} y quisiera hacer un Demo Drive para conocerla un poco más. ¿Podrías brindarme más información?`;
      openSequoiaWhatsappChat(message);
      return;
    }

    if (action === "finance") {
      const message = `Hola! estoy interesado en comprar ${vehicleLabel}, me gustaria que me ayudaras con el proceso de financiamiento para el vehiculo.`;
      openSequoiaWhatsappChat(message);
      return;
    }

    if (action === "design") {
      if (selectedOrderVehicle.key === "sequoia") {
        selectedSequoiaVersion = "sr5";
        selectedSequoiaColor = "lunar-rock";
        selectedSequoiaImageIndex = 0;
        selectedSequoiaInteriorColor = "tela-color-black";
        selectedSequoiaInteriorImageIndex = 0;
        setActiveView("order-configurator", { direction: "forward" });
        return;
      }

      if (notesField) {
        notesField.value = `Quiero disenar mi ${vehicleLabel} con especificaciones personalizadas.`;
      }
    }

    if (requestForm) {
      requestForm.scrollIntoView({ behavior: "smooth", block: "start" });
      requestForm.elements.customerPhone?.focus();
      setFeedback(requestFeedback, `Perfecto. Vamos con ${vehicleLabel}. Completa los datos y enviamos la solicitud.`, "success");
    }
  });

  orderOptionsBackButton?.addEventListener("click", () => {
    setActiveView("order", { direction: "backward" });
  });
}

function bindSequoiaConfigurator() {
  if (!sequoiaConfigVersions || !sequoiaConfigColors || !sequoiaConfigMainImage) {
    return;
  }

  sequoiaConfigVersions.addEventListener("click", (event) => {
    const versionButton = event.target.closest("[data-sequoia-version]");

    if (!versionButton) {
      return;
    }

    const nextVersion = versionButton.dataset.sequoiaVersion;
    const nextConfig = getSequoiaCatalog().versionConfig?.[nextVersion];

    if (!nextConfig) {
      return;
    }

    selectedSequoiaVersion = nextVersion;
    selectedSequoiaColor = nextConfig.colors[0]?.key || selectedSequoiaColor;
    selectedSequoiaImageIndex = 0;
    selectedSequoiaInteriorColor = getActiveSequoiaInteriorConfig().colors[0]?.key || selectedSequoiaInteriorColor;
    selectedSequoiaInteriorImageIndex = 0;
    renderSequoiaConfigurator();
  });

  sequoiaConfigColors.addEventListener("click", (event) => {
    const colorButton = event.target.closest("[data-sequoia-color]");

    if (!colorButton) {
      return;
    }

    selectedSequoiaColor = colorButton.dataset.sequoiaColor || selectedSequoiaColor;
    selectedSequoiaImageIndex = 0;
    renderSequoiaConfigurator();
  });

  sequoiaInteriorColors?.addEventListener("click", (event) => {
    const colorButton = event.target.closest("[data-sequoia-interior-color]");

    if (!colorButton) {
      return;
    }

    selectedSequoiaInteriorColor = colorButton.dataset.sequoiaInteriorColor || selectedSequoiaInteriorColor;
    selectedSequoiaInteriorImageIndex = 0;
    renderSequoiaInterior();
  });

  sequoiaConfigDots?.addEventListener("click", (event) => {
    const dotButton = event.target.closest("[data-sequoia-dot-index]");

    if (!dotButton) {
      return;
    }

    selectedSequoiaImageIndex = Number(dotButton.dataset.sequoiaDotIndex || 0);
    updateSequoiaMainImage();
  });

  sequoiaConfigPrevButton?.addEventListener("click", () => {
    spinSequoiaImage(-1);
  });

  sequoiaConfigNextButton?.addEventListener("click", () => {
    spinSequoiaImage(1);
  });

  sequoiaConfigImageFrame?.addEventListener("touchstart", (event) => {
    if ((event.touches?.length || 0) !== 1) {
      isSequoiaTouchDragging = false;
      return;
    }

    sequoiaTouchLastX = event.touches?.[0]?.clientX || 0;
    sequoiaTouchAccumulator = 0;
    isSequoiaTouchDragging = true;
  }, { passive: true });

  sequoiaConfigImageFrame?.addEventListener("touchmove", (event) => {
    if (!isSequoiaTouchDragging || (event.touches?.length || 0) !== 1) {
      return;
    }

    const currentX = event.touches?.[0]?.clientX || sequoiaTouchLastX;
    const deltaX = currentX - sequoiaTouchLastX;
    sequoiaTouchLastX = currentX;
    sequoiaTouchAccumulator += deltaX;

    const steps = Math.trunc(sequoiaTouchAccumulator / SEQUOIA_TOUCH_SPIN_STEP_PX);

    if (steps !== 0) {
      spinSequoiaImage(-steps);
      sequoiaTouchAccumulator -= steps * SEQUOIA_TOUCH_SPIN_STEP_PX;
    }

    // Keep the gesture dedicated to 360 rotation while the finger is over the frame.
    event.preventDefault();
  }, { passive: false });

  sequoiaConfigImageFrame?.addEventListener("touchend", () => {
    isSequoiaTouchDragging = false;
    sequoiaTouchAccumulator = 0;
  }, { passive: true });

  sequoiaConfigImageFrame?.addEventListener("touchcancel", () => {
    isSequoiaTouchDragging = false;
    sequoiaTouchAccumulator = 0;
  }, { passive: true });

  sequoiaConfigImageFrame?.addEventListener("wheel", (event) => {
    const horizontalIntent = event.deltaX;

    if (Math.abs(horizontalIntent) < 1) {
      return;
    }

    event.preventDefault();
    sequoiaWheelAccumulator += horizontalIntent;

    const steps = Math.trunc(sequoiaWheelAccumulator / SEQUOIA_SPIN_STEP_PX);

    if (steps !== 0) {
      spinSequoiaImage(steps);
      sequoiaWheelAccumulator -= steps * SEQUOIA_SPIN_STEP_PX;
    }
  }, { passive: false });

  sequoiaInteriorImageFrame?.addEventListener("touchstart", (event) => {
    if ((event.touches?.length || 0) !== 1) {
      isSequoiaInteriorTouchDragging = false;
      return;
    }

    sequoiaInteriorTouchLastX = event.touches?.[0]?.clientX || 0;
    sequoiaInteriorTouchAccumulator = 0;
    isSequoiaInteriorTouchDragging = true;
  }, { passive: true });

  sequoiaInteriorImageFrame?.addEventListener("touchmove", (event) => {
    if (!isSequoiaInteriorTouchDragging || (event.touches?.length || 0) !== 1) {
      return;
    }

    const currentX = event.touches?.[0]?.clientX || sequoiaInteriorTouchLastX;
    const deltaX = currentX - sequoiaInteriorTouchLastX;
    sequoiaInteriorTouchLastX = currentX;
    sequoiaInteriorTouchAccumulator += deltaX;

    const steps = Math.trunc(sequoiaInteriorTouchAccumulator / SEQUOIA_TOUCH_SPIN_STEP_PX);

    if (steps !== 0) {
      spinSequoiaInteriorImage(-steps);
      sequoiaInteriorTouchAccumulator -= steps * SEQUOIA_TOUCH_SPIN_STEP_PX;
    }

    // Keep the gesture dedicated to 360 rotation while the finger is over the frame.
    event.preventDefault();
  }, { passive: false });

  sequoiaInteriorImageFrame?.addEventListener("touchend", () => {
    isSequoiaInteriorTouchDragging = false;
    sequoiaInteriorTouchAccumulator = 0;
  }, { passive: true });

  sequoiaInteriorImageFrame?.addEventListener("touchcancel", () => {
    isSequoiaInteriorTouchDragging = false;
    sequoiaInteriorTouchAccumulator = 0;
  }, { passive: true });

  sequoiaInteriorImageFrame?.addEventListener("wheel", (event) => {
    const horizontalIntent = event.deltaX;

    if (Math.abs(horizontalIntent) < 1) {
      return;
    }

    event.preventDefault();
    sequoiaInteriorWheelAccumulator += horizontalIntent;

    const steps = Math.trunc(sequoiaInteriorWheelAccumulator / SEQUOIA_SPIN_STEP_PX);

    if (steps !== 0) {
      spinSequoiaInteriorImage(steps);
      sequoiaInteriorWheelAccumulator -= steps * SEQUOIA_SPIN_STEP_PX;
    }
  }, { passive: false });

  orderConfigBackButton?.addEventListener("click", () => {
    setActiveView("order-options", { direction: "backward" });
  });

  sequoiaDeliveryCityButton?.addEventListener("click", () => {
    if (!sequoiaCitySelector) {
      return;
    }

    const nextExpandedState = sequoiaCitySelector.hidden;
    sequoiaCitySelector.hidden = !nextExpandedState;
    sequoiaDeliveryCityButton.setAttribute("aria-expanded", String(nextExpandedState));
  });

  sequoiaCitySelector?.addEventListener("click", (event) => {
    const cityButton = event.target.closest("[data-delivery-city]");

    if (!cityButton) {
      return;
    }

    selectedSequoiaDeliveryCity = cityButton.dataset.deliveryCity || selectedSequoiaDeliveryCity;
    sequoiaCitySelector.hidden = true;
    sequoiaDeliveryCityButton?.setAttribute("aria-expanded", "false");
    renderSequoiaOrderSummary();
  });

  sequoiaOrderDetailsToggle?.addEventListener("click", () => {
    isSequoiaOrderDetailsExpanded = !isSequoiaOrderDetailsExpanded;
    renderSequoiaOrderSummary();
  });

  sequoiaOrderCardButton?.addEventListener("click", async () => {
    if (!sequoiaOrderCardButton) {
      return;
    }

    const originalLabel = sequoiaOrderCardButton.textContent;
    const summary = getSequoiaOrderSummaryData();
    const nativeExternalLinkHandler = window.webkit?.messageHandlers?.globalImportsExternalLink;
    const pendingExternalWindow = nativeExternalLinkHandler?.postMessage
      ? null
      : window.open("", "_blank", "noopener,noreferrer");

    sequoiaOrderCardButton.disabled = true;
    sequoiaOrderCardButton.textContent = "Preparando contrato...";

    try {
      const response = await fetchJson("/api/client/docusign/preagreement-signing-url", {
        method: "POST",
        body: JSON.stringify({
          vehicle: {
            brand: summary.brand,
            model: summary.model,
            version: summary.versionName,
            exteriorColor: summary.exteriorColorName,
            interiorColor: summary.interiorColorName,
          },
          deliveryCity: summary.deliveryCityLabel,
          totalPriceLabel: formatCopCurrency(summary.totalPrice),
          reservationAmountLabel: formatCopCurrency(SEQUOIA_ORDER_RESERVATION_AMOUNT),
        }),
      });

      if (!response?.signingUrl) {
        throw new Error("No fue posible iniciar la firma del preacuerdo.");
      }

      if (!openExternalBrowserUrl(response.signingUrl, pendingExternalWindow)) {
        window.location.assign(response.signingUrl);
      }
    } catch (error) {
      if (error?.message && /consentimiento jwt|consent_required|docusign requiere consentimiento/i.test(error.message)) {
        const consentUrlMatch = String(error.message).match(/https?:\/\/\S+/i);

        if (consentUrlMatch?.[0]) {
          if (!openExternalBrowserUrl(consentUrlMatch[0], pendingExternalWindow)) {
            window.location.assign(consentUrlMatch[0]);
          }
        }
      } else if (pendingExternalWindow && !pendingExternalWindow.closed) {
        pendingExternalWindow.close();
      }

      window.alert(error.message || "No se pudo iniciar la firma del preacuerdo.");
      sequoiaOrderCardButton.disabled = false;
      sequoiaOrderCardButton.textContent = originalLabel;
    }
  });
}

function goToTrackingPage() {
  const query = trackingInput.value.trim();

  if (!query) {
    setFeedback(trackingSearchFeedback, "Ingresa tu número de guía para continuar.", "error");
    return;
  }

  setFeedback(trackingSearchFeedback, "", "");
  rememberTrackingSearch(query);

  const trackingUrl = buildTrackingPageUrl(query);
  window.location.href = trackingUrl.toString();
}

function renderNotifications() {
  const unreadCount = state.notifications.length;

  notificationCount.textContent = String(unreadCount);
  notificationCount.hidden = unreadCount === 0;
  syncNativeAppBadge(unreadCount);

  if (!state.notifications.length) {
    renderEmptyState(notificationsList, "No hay notificaciones recientes.");
    return;
  }

  notificationsList.innerHTML = state.notifications
    .map(
      (item) => `
        <article class="notification-card ${escapeHtml(item.type)}">
          <div>
            <span>${escapeHtml(item.type)}</span>
            <strong>${escapeHtml(item.title)}</strong>
            <p>${escapeHtml(item.message)}</p>
          </div>
          <div class="notification-meta">
            <time>${escapeHtml(formatDate(item.date))}</time>
            <button
              type="button"
              class="notification-dismiss"
              data-notification-dismiss="${escapeHtml(item.id)}"
              aria-label="Eliminar notificacion"
            >
              x
            </button>
          </div>
        </article>
      `
    )
    .join("");
}

async function dismissNotification(notificationId) {
  const id = String(notificationId || "").trim();

  if (!id) {
    return;
  }

  await fetchJson(`/api/client/notifications/${encodeURIComponent(id)}`, {
    method: "DELETE",
  });

  state.notifications = state.notifications.filter((item) => item.id !== id);
  renderNotifications();
}

function renderVirtualDealership() {
  if (!virtualDealershipClientList) {
    return;
  }

  if (!state.virtualDealershipVehicles.length) {
    renderEmptyState(virtualDealershipClientList, "No hay vehículos de compra inmediata publicados por el momento.");
    if (virtualDealershipLoadMoreSentinel) {
      virtualDealershipLoadMoreSentinel.hidden = true;
    }
    return;
  }

  const visibleVehicles = state.virtualDealershipVehicles.slice(0, state.virtualDealershipVisibleCount);

  virtualDealershipClientList.innerHTML = visibleVehicles
    .map((vehicle, index) => {
      const vehicleImages = Array.isArray(vehicle.images)
        ? vehicle.images.filter((item) => item && item.url)
        : [];
      const vehicleKey = resolveVirtualVehicleKey(vehicle, index);
      const vehicleTitle = `${vehicle.brand || "Vehículo"} ${vehicle.model || ""} ${vehicle.version || ""}`.trim();
      const pricing = formatCopCurrency(vehicle.price || 0);
      const publicationUrl = new URL("/client.html", window.location.origin);
      publicationUrl.searchParams.set("view", "virtual-dealership");
      publicationUrl.hash = `virtual-vehicle-${vehicleKey}`;

      const whatsappMessage = `Hola, estoy muy interesado en comprar este vehículo (${publicationUrl.toString()}); ¿podrías darme más información o llamarme?`;
      const whatsappUrl = buildSequoiaWhatsappUrl(whatsappMessage);
      const detailsExpanded = state.virtualDealershipExpandedDetails.has(vehicleKey);

      return `
        <article class="virtual-dealership-card">
          <span id="virtual-vehicle-${escapeHtml(vehicleKey)}" class="virtual-dealership-anchor" aria-hidden="true"></span>
          ${vehicleImages.length
            ? `<div class="virtual-dealership-carousel" role="group" aria-label="Galería de ${escapeHtml(vehicleTitle)}">
                <div class="virtual-dealership-carousel-track">
                  ${vehicleImages
                    .map(
                      (image, index) => `
                        <button
                          type="button"
                          class="virtual-dealership-image-button virtual-dealership-carousel-slide"
                          data-virtual-image-url="${encodeURIComponent(image.url)}"
                          data-virtual-image-alt="${escapeHtml(image.caption || `${vehicleTitle} foto ${index + 1}`)}"
                          data-virtual-vehicle-key="${escapeHtml(vehicleKey)}"
                          data-virtual-image-index="${index}"
                          aria-label="Ver imagen ${index + 1} de ${vehicleImages.length}"
                        >
                          <img src="${escapeHtml(image.url)}" alt="${escapeHtml(image.caption || vehicleTitle)}" loading="lazy" />
                        </button>
                      `
                    )
                    .join("")}
                </div>
                ${vehicleImages.length > 1
                  ? `<div class="virtual-dealership-carousel-dots" aria-hidden="true">${vehicleImages
                      .map(() => '<span class="virtual-dealership-carousel-dot"></span>')
                      .join("")}</div>`
                  : ""}
                <div class="virtual-dealership-media-overlay">
                  <h3>${escapeHtml(vehicleTitle || "Vehículo")}</h3>
                  <strong class="virtual-dealership-media-price">${escapeHtml(pricing)}</strong>
                </div>
              </div>`
            : ""}
          <div class="virtual-dealership-card-body">
            <button type="button" class="virtual-dealership-details-toggle" data-virtual-details-toggle="${escapeHtml(vehicleKey)}" aria-expanded="${detailsExpanded ? "true" : "false"}">${detailsExpanded ? "Ocultar detalles" : "Ver detalles"}</button>
            <div class="virtual-dealership-details ${detailsExpanded ? "is-open" : "is-collapsed"}">
              <div class="virtual-dealership-card-meta">
                <span>${escapeHtml(vehicle.year || "Año N/D")}</span>
                <span>${escapeHtml((vehicle.status || "available") === "reserved" ? "Reservado" : "Disponible")}</span>
              </div>
              <p>${escapeHtml(vehicle.exteriorColor || "Color exterior por confirmar")} · ${escapeHtml(vehicle.interiorColor || "Coginería por confirmar")}</p>
              <p>${escapeHtml(vehicle.mileage != null ? `${vehicle.mileage} km` : "Kilometraje por confirmar")} · ${escapeHtml(vehicle.engine || "Motor por confirmar")} · ${escapeHtml(vehicle.horsepower != null ? `${vehicle.horsepower} HP` : "Potencia por confirmar")}</p>
              <p>${escapeHtml(vehicle.description || "Vehículo en vitrina para compra inmediata.")}</p>
              <div class="virtual-dealership-card-actions">
                <a class="secondary-button virtual-dealership-buy-button" href="${escapeHtml(whatsappUrl)}" data-whatsapp-message="${encodeURIComponent(whatsappMessage)}" rel="noopener noreferrer">Comprar ahora</a>
                <div class="virtual-dealership-video-column">
                  <button type="button" class="primary-button virtual-dealership-video-button" data-virtual-video-call="1" data-virtual-video-title="${encodeURIComponent(vehicleTitle)}" data-virtual-video-publication="${encodeURIComponent(publicationUrl.toString())}">Verla en vivo</button>
                </div>
              </div>
            </div>
          </div>
        </article>
      `;
    })
    .join("");

  if (virtualDealershipLoadMoreSentinel) {
    virtualDealershipLoadMoreSentinel.hidden = state.virtualDealershipVisibleCount >= state.virtualDealershipVehicles.length;
  }
}

async function loadVirtualDealership() {
  const data = await fetchJson("/api/client/virtual-dealership");
  state.virtualDealershipVehicles = Array.isArray(data.vehicles) ? data.vehicles : [];
  state.virtualDealershipVisibleCount = Math.min(VIRTUAL_DEALERSHIP_BATCH_SIZE, state.virtualDealershipVehicles.length);
  renderVirtualDealership();
}

function setActiveView(viewName, options = {}) {
  const direction = options.direction || "none";
  const previousView = state.activeView;
  let nextViewName = viewName;
  let enteringNode = viewNodes.find((node) => node.dataset.view === nextViewName);

  if (!enteringNode) {
    nextViewName = "home";
    enteringNode = viewNodes.find((node) => node.dataset.view === nextViewName) || viewNodes[0] || null;
  }

  if (!enteringNode) {
    return;
  }

  state.activeView = nextViewName;
  persistViewToUrl(nextViewName);
  syncFeedVideoScrollAutoplay();

  viewNodes.forEach((node) => {
    node.classList.remove("is-entering-right", "is-entering-left");
    node.classList.toggle("is-active", node === enteringNode);
  });

  if (enteringNode && direction !== "none") {
    enteringNode.classList.add(direction === "forward" ? "is-entering-right" : "is-entering-left");
  }

  navButtons.forEach((button) => {
    const targetView = button.dataset.viewTarget;
    const shouldHighlightOrder = targetView === "order" && (nextViewName === "order-options" || nextViewName === "order-configurator");
    const shouldHighlightTaller = targetView === "maintenance" && (nextViewName === "maintenance-includes" || nextViewName === "maintenance-detailing" || nextViewName === "maintenance-accesorios");
    button.classList.toggle("is-active", targetView === nextViewName || shouldHighlightOrder || shouldHighlightTaller);
  });

  window.moveClientNavRing?.({ animate: Boolean(previousView && previousView !== nextViewName) });

  if (previousView && previousView !== viewName) {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  if (nextViewName === "order-configurator") {
    ensureSequoiaConfiguratorReady()
      .then(() => {
        showSequoiaVisionHint();
      })
      .catch(() => {
        setSequoiaConfiguratorLoadingState("No se pudo cargar el configurador.");
        setFeedback(requestFeedback, "No se pudo cargar el configurador Sequoia. Intenta de nuevo.", "error");
      });
  }
  if (nextViewName === "maintenance-includes") {
    playWorkshopStory(maintenanceIncludesStory);
  } else {
    resetWorkshopStory(maintenanceIncludesStory);
  }

  if (nextViewName === "maintenance-detailing") {
    playWorkshopStory(detailingStory);
  } else {
    resetWorkshopStory(detailingStory);
  }

  if (nextViewName === "maintenance-accesorios") {
    playWorkshopStory(accesoriosStory);
  } else {
    resetWorkshopStory(accesoriosStory);
  }

  if (nextViewName === "pago-separacion") {
    initPagoSeparacionView();
  }
  if (nextViewName === "pago-exitoso") {
    initPagoExitosoView();
  }

  if (GLOBAL_HERO_GAME_ENABLED && nextViewName === "sequoia-game") {
    if (!window.SequoiaFlappyGame?.isMounted?.()) {
      window.SequoiaFlappyGame?.mount(sequoiaGameRoot, {
        authenticated: true,
        getPlayerName: () => String(state.user?.name || state.user?.fullName || "").trim(),
      });
    }
    window.SequoiaFlappyGame?.resume();
  } else if (GLOBAL_HERO_GAME_ENABLED) {
    window.SequoiaFlappyGame?.pause();
    window.SequoiaFlappyGame?.unmount();
  }
}

function openNotifications() {
  notificationsModal.hidden = false;
  document.body.classList.add("modal-open");

  loadDashboard().catch(() => null);
}

function closeNotifications() {
  notificationsModal.hidden = true;
  const shouldKeepModalOpen = (maintenanceVehicleModal && !maintenanceVehicleModal.hidden)
    || (virtualDealershipImageModal && !virtualDealershipImageModal.hidden)
    || (virtualDealershipVideoModal && !virtualDealershipVideoModal.hidden)
    || (deleteAccountModal && !deleteAccountModal.hidden);
  document.body.classList.toggle("modal-open", Boolean(shouldKeepModalOpen));
}

async function loadDashboard() {
  const data = await fetchJson("/api/client/dashboard");
  state.user = data.user || null;
  state.orders = data.orders || [];
  state.maintenance = data.maintenance || [];
  state.maintenanceVehicles = data.maintenanceVehicles || [];
  const validMaintenanceKeys = new Set(
    state.maintenanceVehicles.map((vehicle, index) => resolveMaintenanceVehicleKey(vehicle, index))
  );
  state.maintenanceExpandedDetails = new Set(
    Array.from(state.maintenanceExpandedDetails).filter((key) => validMaintenanceKeys.has(key))
  );
  state.notifications = data.notifications || [];
  loadTrackingHistory();

  updateSummary();
  renderTrackingOptions();
  renderTrackingHistory();
  renderMaintenanceList();
  renderNotifications();
  renderVirtualDealership();
  syncNativePushToken();
}

window.addEventListener("globalimports:push-token", (event) => {
  registerNativePushToken(event.detail || {}).catch((error) => {
    console.warn("[push][client-portal] No se pudo registrar el token nativo recibido por evento.", error);
  });
});

window.addEventListener("focus", () => {
  loadDashboard().catch(() => null);
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    loadDashboard().catch(() => null);
  }
});

navButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setActiveView(button.dataset.viewTarget);

    if (button.dataset.viewTarget === "home" && !state.feedPosts.length) {
      loadFeedPage({ reset: true }).catch((error) => {
        feedLoadingState.textContent = error.message;
      });
    }

    if (button.dataset.viewTarget === "virtual-dealership" && !state.virtualDealershipVehicles.length) {
      loadVirtualDealership().catch((error) => {
        renderEmptyState(virtualDealershipClientList, error.message);
      });
    }
  });
});

(() => {
  const nav = document.querySelector(".client-bottom-nav");
  let ring = nav?.querySelector(".client-nav-ring");
  if (!nav || !ring) {
    return;
  }

  let lastScrollY = window.scrollY || 0;
  let ticking = false;
  let ringAnimation = null;
  const expandAtTop = 18;
  const delta = 6;

  const resetRingStyles = () => {
    ring.style.inset = "0";
    ring.style.top = "0";
    ring.style.left = "0";
    ring.style.right = "0";
    ring.style.bottom = "0";
    ring.style.width = "auto";
    ring.style.height = "auto";
    ring.style.transform = "none";
  };

  const moveClientNavRing = ({ animate = true } = {}) => {
    const activeIcon = nav.querySelector(".client-nav-button.is-active .client-nav-icon");
    if (!activeIcon) {
      ring.classList.remove("is-ready");
      return;
    }

    if (ringAnimation) {
      ringAnimation.cancel();
      ringAnimation = null;
    }

    const alreadyHere = ring.parentElement === activeIcon;
    if (!animate || alreadyHere || !ring.classList.contains("is-ready")) {
      activeIcon.appendChild(ring);
      resetRingStyles();
      ring.classList.add("is-ready");
      return;
    }

    const first = ring.getBoundingClientRect();
    activeIcon.appendChild(ring);
    resetRingStyles();
    ring.classList.add("is-ready");
    const last = ring.getBoundingClientRect();

    const dx = first.left - last.left;
    const dy = first.top - last.top;
    const sx = first.width / Math.max(last.width, 1);
    const sy = first.height / Math.max(last.height, 1);
    const dist = Math.hypot(dx, dy);
    const stretch = Math.min(1.45, 1 + dist / 140);

    if (dist < 1) {
      return;
    }

    ringAnimation = ring.animate(
      [
        {
          transform: `translate3d(${dx}px, ${dy}px, 0) scale(${sx}, ${sy})`,
          offset: 0,
        },
        {
          transform: `translate3d(${dx / 2}px, ${dy / 2}px, 0) scale(${stretch}, ${Math.max(0.84, 2 - stretch)})`,
          offset: 0.45,
        },
        {
          transform: "translate3d(0, 0, 0) scale(1, 1)",
          offset: 1,
        },
      ],
      {
        duration: Math.min(460, 280 + dist * 0.5),
        easing: "cubic-bezier(0.22, 1, 0.36, 1)",
      }
    );

    ringAnimation.onfinish = () => {
      resetRingStyles();
      ringAnimation = null;
    };
  };

  window.moveClientNavRing = moveClientNavRing;

  const syncNavCompact = () => {
    const y = window.scrollY || 0;

    if (y <= expandAtTop) {
      nav.classList.remove("is-compact");
    } else if (y > lastScrollY + delta) {
      nav.classList.add("is-compact");
    } else if (y < lastScrollY - delta) {
      nav.classList.remove("is-compact");
    }

    lastScrollY = y;
    ticking = false;
  };

  window.addEventListener(
    "scroll",
    () => {
      if (ticking) {
        return;
      }
      ticking = true;
      window.requestAnimationFrame(syncNavCompact);
    },
    { passive: true }
  );

  navButtons.forEach((button) => {
    button.addEventListener("click", () => {
      nav.classList.remove("is-compact");
      lastScrollY = 0;
    });
  });

  requestAnimationFrame(() => moveClientNavRing({ animate: false }));
})();

trackingForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  goToTrackingPage();
});

trackingTabSearchButton?.addEventListener("click", () => {
  setTrackingActiveTab("search");
});

trackingTabOrdersButton?.addEventListener("click", () => {
  setTrackingActiveTab("orders");
});

trackingOrdersList?.addEventListener("click", (event) => {
  const removeButton = event.target.closest("[data-tracking-history-remove]");

  if (removeButton) {
    event.preventDefault();
    event.stopPropagation();
    removeTrackingHistoryItem(removeButton.getAttribute("data-tracking-history-remove"));
    return;
  }

  const trackingButton = event.target.closest("[data-tracking-history]");

  if (!trackingButton) {
    return;
  }

  const trackingNumber = String(trackingButton.getAttribute("data-tracking-history") || "").trim();

  if (!trackingNumber) {
    return;
  }

  const trackingUrl = buildTrackingPageUrl(trackingNumber);
  window.location.href = trackingUrl.toString();
});

trackingOrdersClearButton?.addEventListener("click", () => {
  trackingHistory = [];
  persistTrackingHistory();
  renderTrackingHistory();
});

if (requestForm) {
  requestForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formData = new FormData(requestForm);

    setFeedback(requestFeedback, "Enviando tu configuración...");

    try {
      await fetchJson("/api/client/requests", {
        method: "POST",
        body: JSON.stringify({
          customerPhone: formData.get("customerPhone"),
          reservationAmount: formData.get("reservationAmount"),
          currency: formData.get("currency"),
          notes: formData.get("notes"),
          vehicle: {
            brand: formData.get("brand"),
            model: formData.get("model"),
            year: formData.get("year"),
            version: formData.get("version"),
            color: formData.get("color"),
            upholstery: formData.get("upholstery"),
          },
        }),
      });

      requestForm.reset();

      const requestName = document.getElementById("request-name");
      const requestEmail = document.getElementById("request-email");

      if (requestName) {
        requestName.value = state.user?.name || "";
      }

      if (requestEmail) {
        requestEmail.value = state.user?.email || "";
      }

      const currencySelect = requestForm.querySelector('select[name="currency"]');
      if (currencySelect) {
        currencySelect.value = "USD";
      }

      setFeedback(requestFeedback, "Tu nueva orden fue enviada correctamente.", "success");
    } catch (error) {
      setFeedback(requestFeedback, error.message, "error");
    }
  });
}

maintenanceVehicleForm?.addEventListener("submit", async (event) => {
  event.preventDefault();

  try {
    await submitMaintenanceVehicleForm();
  } catch (error) {
    setFeedback(resolveWorkshopFeedback(), error.message, "error");
  }
});

addMaintenanceVehicleButton?.addEventListener("click", () => {
  workshopBookingService = "maintenance";
  openMaintenanceVehicleModal();
});

detailingCeramicButton?.addEventListener("click", () => {
  workshopBookingService = "ceramic";
  openMaintenanceVehicleModal();
});

detailingPolarizadoButton?.addEventListener("click", () => {
  workshopBookingService = "polarizado";
  openMaintenanceVehicleModal();
});

accesoriosQuoteButton?.addEventListener("click", () => {
  workshopBookingService = "accesorios";
  openMaintenanceVehicleModal();
});

document.querySelectorAll("[data-workshop-service]").forEach((button) => {
  button.addEventListener("click", () => {
    if (button.dataset.workshopService === "mantenimientos") {
      setActiveView("maintenance-includes", { direction: "forward" });
    }

    if (button.dataset.workshopService === "detailing") {
      setActiveView("maintenance-detailing", { direction: "forward" });
    }

    if (button.dataset.workshopService === "accesorios") {
      setActiveView("maintenance-accesorios", { direction: "forward" });
    }
  });
});

maintenanceIncludesBackButton?.addEventListener("click", () => {
  setActiveView("maintenance", { direction: "backward" });
});

maintenanceDetailingBackButton?.addEventListener("click", () => {
  setActiveView("maintenance", { direction: "backward" });
});

maintenanceAccesoriosBackButton?.addEventListener("click", () => {
  setActiveView("maintenance", { direction: "backward" });
});
maintenanceVehicleClose?.addEventListener("click", closeMaintenanceVehicleModal);
maintenanceVehicleOverlay?.addEventListener("click", closeMaintenanceVehicleModal);

notificationsButton?.addEventListener("click", openNotifications);
notificationsClose?.addEventListener("click", closeNotifications);
notificationsOverlay?.addEventListener("click", closeNotifications);
maintenanceList?.addEventListener("click", (event) => {
  const toggleDetailsButton = event.target.closest("[data-maintenance-toggle-details]");

  if (toggleDetailsButton) {
    const vehicleKey = String(toggleDetailsButton.getAttribute("data-maintenance-toggle-details") || "").trim();

    if (!vehicleKey) {
      return;
    }

    if (state.maintenanceExpandedDetails.has(vehicleKey)) {
      state.maintenanceExpandedDetails.delete(vehicleKey);
    } else {
      state.maintenanceExpandedDetails.add(vehicleKey);
    }

    renderMaintenanceList();
    return;
  }

  const editButton = event.target.closest("[data-maintenance-edit]");

  if (editButton) {
    const vehicleId = String(editButton.getAttribute("data-maintenance-edit") || "").trim();
    const vehicle = state.maintenanceVehicles.find((item) => String(item._id || item.id || "") === vehicleId);

    if (vehicle) {
      workshopBookingService = "maintenance";
      openMaintenanceVehicleModal(vehicle);
    }

    return;
  }

  const deleteButton = event.target.closest("[data-maintenance-delete]");

  if (deleteButton) {
    const vehicleId = String(deleteButton.getAttribute("data-maintenance-delete") || "").trim();

    if (!vehicleId) {
      return;
    }

    const shouldDelete = window.confirm("¿Quieres eliminar este vehículo de mantenimiento?");

    if (!shouldDelete) {
      return;
    }

    deleteMaintenanceVehicle(vehicleId).catch((error) => {
      setFeedback(maintenanceFeedback, error.message, "error");
    });
  }
});
virtualDealershipImageClose?.addEventListener("click", closeVirtualDealershipImageModal);
virtualDealershipImageOverlay?.addEventListener("click", closeVirtualDealershipImageModal);
virtualDealershipImagePrev?.addEventListener("click", () => stepVirtualDealershipImageModal(-1));
virtualDealershipImageNext?.addEventListener("click", () => stepVirtualDealershipImageModal(1));
virtualDealershipImageDots?.addEventListener("click", (event) => {
  const dot = event.target.closest("[data-virtual-modal-dot-index]");

  if (!dot) {
    return;
  }

  const dotIndex = Number(dot.getAttribute("data-virtual-modal-dot-index") || 0);

  if (Number.isNaN(dotIndex)) {
    return;
  }

  virtualDealershipModalImageIndex = Math.min(Math.max(dotIndex, 0), Math.max(virtualDealershipModalImages.length - 1, 0));
  renderVirtualDealershipImageModal(true);
});
virtualDealershipVideoClose?.addEventListener("click", closeVirtualDealershipVideoModal);
virtualDealershipVideoOverlay?.addEventListener("click", closeVirtualDealershipVideoModal);
virtualDealershipVideoDate?.addEventListener("change", () => {
  virtualDealershipVideoContext.selectedDate = String(virtualDealershipVideoDate.value || "").trim();
  virtualDealershipVideoContext.selectedTime = "";

  if (!isWeekday(parseDateInputValue(virtualDealershipVideoContext.selectedDate))) {
    setVirtualDealershipVideoFeedback("Solo puedes agendar de lunes a viernes.", "error");
  } else {
    setVirtualDealershipVideoFeedback("");
  }

  renderVirtualDealershipVideoSlots();
});
virtualDealershipVideoSlots?.addEventListener("change", () => {
  virtualDealershipVideoContext.selectedTime = String(virtualDealershipVideoSlots.value || "").trim();
  setVirtualDealershipVideoFeedback("");
});
virtualDealershipVideoConfirm?.addEventListener("click", () => {
  const selectedDate = virtualDealershipVideoContext.selectedDate;
  const selectedTime = virtualDealershipVideoContext.selectedTime;

  if (!selectedDate) {
    setVirtualDealershipVideoFeedback("Selecciona una fecha para continuar.", "error");
    return;
  }

  const parsedDate = parseDateInputValue(selectedDate);

  if (!isWeekday(parsedDate)) {
    setVirtualDealershipVideoFeedback("Solo puedes agendar de lunes a viernes.", "error");
    return;
  }

  if (!selectedTime) {
    setVirtualDealershipVideoFeedback("Selecciona un horario de 15 minutos.", "error");
    return;
  }

  const userName = String(state.user?.name || state.user?.fullName || "Cliente").trim() || "Cliente";
  const vehicleTitle = virtualDealershipVideoContext.vehicleTitle || "vehículo publicado";
  const publicationUrl = virtualDealershipVideoContext.publicationUrl || window.location.href;
  const formattedDate = parsedDate
    ? parsedDate.toLocaleDateString("es-CO", { weekday: "long", year: "numeric", month: "long", day: "numeric" })
    : selectedDate;
  const [hourPart, minutePart] = selectedTime.split(":").map((value) => Number(value));
  const formattedTime = Number.isNaN(hourPart) || Number.isNaN(minutePart)
    ? selectedTime
    : formatVideoSlotLabel(hourPart, minutePart);

  const message = [
    "Hola, quiero agendar una videollamada para verla en vivo.",
    `Cliente: ${userName}`,
    `Vehículo: ${vehicleTitle}`,
    `Fecha: ${formattedDate}`,
    `Hora: ${formattedTime}`,
    `Publicación: ${publicationUrl}`,
  ].join("\n");

  setVirtualDealershipVideoFeedback("Perfecto, te llevamos a WhatsApp para confirmar la videollamada.", "success");
  openSequoiaWhatsappChat(message);
});
document.addEventListener("click", (event) => {
  const whatsappTrigger = event.target.closest("[data-whatsapp-message]");

  if (!whatsappTrigger) {
    return;
  }

  event.preventDefault();
  const encodedMessage = whatsappTrigger.getAttribute("data-whatsapp-message") || "";
  const message = encodedMessage ? decodeURIComponent(encodedMessage) : "";
  openSequoiaWhatsappChat(message);
});
notificationsList?.addEventListener("click", (event) => {
  const dismissButton = event.target.closest("[data-notification-dismiss]");

  if (!dismissButton) {
    return;
  }

  const notificationId = dismissButton.getAttribute("data-notification-dismiss");

  dismissNotification(notificationId).catch(() => null);
});

virtualDealershipClientList?.addEventListener("click", (event) => {
  const detailsToggle = event.target.closest("[data-virtual-details-toggle]");

  if (detailsToggle) {
    const vehicleKey = String(detailsToggle.getAttribute("data-virtual-details-toggle") || "");

    if (vehicleKey) {
      const isExpanded = state.virtualDealershipExpandedDetails.has(vehicleKey);

      if (isExpanded) {
        state.virtualDealershipExpandedDetails.delete(vehicleKey);
      } else {
        state.virtualDealershipExpandedDetails.add(vehicleKey);
      }

      const card = detailsToggle.closest(".virtual-dealership-card");
      const detailsPanel = card?.querySelector(".virtual-dealership-details");
      const nextExpanded = !isExpanded;

      detailsToggle.setAttribute("aria-expanded", String(nextExpanded));
      detailsToggle.textContent = nextExpanded ? "Ocultar detalles" : "Ver detalles";

      if (detailsPanel) {
        detailsPanel.classList.toggle("is-open", nextExpanded);
        detailsPanel.classList.toggle("is-collapsed", !nextExpanded);
      }
    }

    return;
  }

  const videoCallButton = event.target.closest("[data-virtual-video-call]");

  if (videoCallButton) {
    const vehicleTitle = decodeURIComponent(videoCallButton.getAttribute("data-virtual-video-title") || "");
    const publicationUrl = decodeURIComponent(videoCallButton.getAttribute("data-virtual-video-publication") || "");
    openVirtualDealershipVideoModal(vehicleTitle, publicationUrl);
    return;
  }

  const imageButton = event.target.closest("[data-virtual-image-url]");

  if (!imageButton) {
    return;
  }

  openVirtualDealershipImageModal(
    imageButton.getAttribute("data-virtual-vehicle-key"),
    Number(imageButton.getAttribute("data-virtual-image-index") || 0)
  );
});

menuButton?.addEventListener("click", () => {
  const isOpen = !sessionMenu.hidden;
  sessionMenu.hidden = isOpen;
});

logoutButton?.addEventListener("click", async () => {
  await requestLogout();
  clearAuth();
  redirectToLogin();
});

deleteAccountOpenButton?.addEventListener("click", openDeleteAccountModal);
deleteAccountCloseButton?.addEventListener("click", closeDeleteAccountModal);
deleteAccountCancelButton?.addEventListener("click", closeDeleteAccountModal);
deleteAccountOverlay?.addEventListener("click", closeDeleteAccountModal);
deleteAccountForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  submitDeleteAccount().catch((error) => {
    setFeedback(deleteAccountFeedback, error.message, "error");
  });
});

document.addEventListener("click", (event) => {
  if (sessionMenu && menuButton && !sessionMenu.contains(event.target) && !menuButton.contains(event.target)) {
    sessionMenu.hidden = true;
  }

  if (
    sequoiaCitySelector
    && sequoiaDeliveryCityButton
    && !sequoiaCitySelector.hidden
    && !sequoiaCitySelector.contains(event.target)
    && !sequoiaDeliveryCityButton.contains(event.target)
  ) {
    sequoiaCitySelector.hidden = true;
    sequoiaDeliveryCityButton.setAttribute("aria-expanded", "false");
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeNotifications();
    closeMaintenanceVehicleModal();
    closeVirtualDealershipImageModal();
    closeVirtualDealershipVideoModal();
    closeDeleteAccountModal();
    sessionMenu.hidden = true;
    return;
  }

  if (virtualDealershipImageModal && !virtualDealershipImageModal.hidden) {
    if (event.key === "ArrowLeft") {
      stepVirtualDealershipImageModal(-1);
    }

    if (event.key === "ArrowRight") {
      stepVirtualDealershipImageModal(1);
    }
  }
});

window.addEventListener("touchstart", handlePullStart, { passive: true });
window.addEventListener("touchmove", handlePullMove, { passive: false });
window.addEventListener("touchend", handlePullEnd, { passive: true });
window.addEventListener("wheel", handleWheelRefresh, { passive: true });

window.addEventListener("load", () => {
  document.body.classList.add("motion-ready");
  setTrackingActiveTab("search");
});

// ─── Pago separación (post-DocuSign → Wompi) ─────────────────────────────
let pagoSepInitialized = false;

function initPagoSeparacionView() {
  if (pagoSepInitialized) return;
  pagoSepInitialized = true;

  const params = new URLSearchParams(window.location.search);
  const brand    = params.get("brand")    || "Vehículo";
  const model    = params.get("model")    || "";
  const version  = params.get("version")  || "";
  const extColor = params.get("extColor") || "";
  const intColor = params.get("intColor") || "";
  const city     = params.get("city")     || "";
  const price    = params.get("price")    || "";

  const container = document.getElementById("pago-sep-summary");
  const feedback  = document.getElementById("pago-sep-feedback");
  if (!container) return;

  const vehicleLabel = [brand, model, version].filter(Boolean).join(" ");

  container.innerHTML = `
    <header class="sequoia-order-summary-head">
      <h3>${escapeHtml(vehicleLabel)}</h3>
      <p>Has firmado el preacuerdo de compra exitosamente.</p>
    </header>
    <div style="margin:14px 0; font-size:14px; line-height:1.7;">
      ${extColor ? `<p><strong>Color exterior:</strong> ${escapeHtml(extColor)}</p>` : ""}
      ${intColor ? `<p><strong>Color interior:</strong> ${escapeHtml(intColor)}</p>` : ""}
      ${city     ? `<p><strong>Ciudad de entrega:</strong> ${escapeHtml(city)}</p>` : ""}
      ${price    ? `<p><strong>Precio total estimado:</strong> ${escapeHtml(price)}</p>` : ""}
    </div>
    <div class="sequoia-summary-paytoday">
      <div class="sequoia-summary-line">
        <strong>Paga hoy (separación)</strong>
        <strong>$ 1.000.000</strong>
      </div>
      <p>Monto no reembolsable salvo incumplimiento de Global Imports</p>
    </div>
    <button id="wompi-pay-button" class="sequoia-summary-order-button" type="button" disabled>
      Cargando pasarela de pago...
    </button>
  `;

  fetchJson("/api/client/payment/wompi-config")
    .then((cfg) => {
      const reference = `GI-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

      const successParams = new URLSearchParams();
      successParams.set("view", "pago-exitoso");
      if (brand)    successParams.set("brand",    brand);
      if (model)    successParams.set("model",    model);
      if (version)  successParams.set("version",  version);
      if (extColor) successParams.set("extColor", extColor);
      if (intColor) successParams.set("intColor", intColor);
      if (city)     successParams.set("city", city);
      successParams.set("reference", reference);
      const redirectAfterPayment = `${window.location.origin}/client.html?${successParams.toString()}`;

      // Siempre usar el dominio oficial de Wompi (sandbox y prod usan el mismo)
      const wompiUrl = new URL("https://checkout.wompi.co/p/");
      wompiUrl.searchParams.set("public-key",     cfg.publicKey);
      wompiUrl.searchParams.set("currency",        cfg.currency || "COP");
      wompiUrl.searchParams.set("amount-in-cents", String(cfg.amountInCents || 100000000));
      wompiUrl.searchParams.set("reference",       reference);
      wompiUrl.searchParams.set("redirect-url",    redirectAfterPayment);

      const btn = document.getElementById("wompi-pay-button");
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Proceder al pago →";
        btn.addEventListener("click", () => { window.location.href = wompiUrl.toString(); });
      }
    })
    .catch(() => {
      if (feedback) {
        feedback.textContent = "No se pudo cargar la pasarela de pago. Intenta de nuevo.";
        feedback.className = "feedback error";
      }
      const btn = document.getElementById("wompi-pay-button");
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Reintentar";
        btn.addEventListener("click", () => { pagoSepInitialized = false; initPagoSeparacionView(); });
      }
    });
}

// ─── Pago exitoso (post-Wompi → WhatsApp) ────────────────────────────────
let pagoExitoInitialized = false;

function initPagoExitosoView() {
  if (pagoExitoInitialized) {
    return;
  }

  pagoExitoInitialized = true;
  const params = new URLSearchParams(window.location.search);
  const brand    = params.get("brand")    || "Vehículo";
  const model    = params.get("model")    || "";
  const version  = params.get("version")  || "";
  const extColor = params.get("extColor") || "";
  const intColor = params.get("intColor") || "";
  const city = params.get("city") || "";
  const reference = params.get("reference") || "";
  const transactionId = params.get("id") || params.get("transactionId") || params.get("transaction_id") || "";
  const status = params.get("status") || "";

  const container = document.getElementById("pago-exito-body");
  if (!container) return;

  const vehicleLabel = [brand, model, version].filter(Boolean).join(" ");

  container.innerHTML = `
    <p style="font-size:14px; color:#6b7280; text-align:center;">Validando pago con Wompi...</p>
  `;

  if (!transactionId) {
    container.innerHTML = `
      <p style="font-size:14px; color:#dc2626; text-align:center;">
        No encontramos el identificador de la transacción. Si ya pagaste, contáctanos para validar manualmente.
      </p>
    `;
    return;
  }

  const waMessage =
    `¡Hola, Global Imports! Acabo de realizar el pago de separación de $1.000.000 para reservar mi ` +
    vehicleLabel +
    (extColor ? ` en color ${extColor}` : "") +
    (intColor ? ` con interior ${intColor}` : "") +
    `. ¿Cuál es el paso a seguir para formalizar el contrato de compra?`;

  const waUrl = buildSequoiaWhatsappUrl(waMessage);

  fetchJson("/api/client/payment/wompi-confirm", {
    method: "POST",
    body: JSON.stringify({
      transactionId,
      status,
      reference,
      brand,
      model,
      version,
      extColor,
      intColor,
      city,
      vehicle: {
        brand,
        model,
        version,
        exteriorColor: extColor,
        interiorColor: intColor,
      },
    }),
  }).then((result) => {
    if (!result?.paid) {
      container.innerHTML = `
        <p style="font-size:14px; color:#b45309; text-align:center;">
          El pago aún aparece como ${escapeHtml(String(result?.status || "PENDING"))}. Cuando se apruebe, verás tu confirmación aquí.
        </p>
      `;
      return;
    }

    container.innerHTML = `
      <div style="font-size:56px; margin-bottom:10px;">&#x2705;</div>
      <p style="font-size:15px; font-weight:600; margin-bottom:6px;">¡Pago confirmado y registrado!</p>
      <p style="font-size:13px; color:#4b5563; margin-bottom:20px;">
        Has separado tu <strong>${escapeHtml(vehicleLabel)}</strong>
        ${extColor ? `color <strong>${escapeHtml(extColor)}</strong>` : ""}.
        Tu compra ya fue notificada al sistema administrativo.
        Tracking: <strong>${escapeHtml(String(result?.trackingNumber || "por asignar"))}</strong>
      </p>
      <a href="${escapeHtml(waUrl)}"
         target="_blank" rel="noopener noreferrer"
         class="sequoia-summary-order-button"
         style="display:inline-block; text-decoration:none; background:#25d366; margin-bottom:14px;">
        &#x1F4AC; Contactar a Global Imports por WhatsApp
      </a>
      <p style="font-size:12px; color:#6b7280;">
        Al hacer clic entrarás a WhatsApp con un mensaje preescrito sobre tu vehículo reservado.
      </p>
    `;
  }).catch((error) => {
    container.innerHTML = `
      <p style="font-size:14px; color:#dc2626; text-align:center;">
        No pudimos validar el pago automáticamente. ${escapeHtml(error?.message || "Intenta recargar la página.")}
      </p>
    `;
  });
}

setActiveView(getInitialViewFromUrl());
registerClientImageCacheServiceWorker();

loadDashboard().catch((error) => {
  renderEmptyState(feedContainer, error.message);
  setFeedback(trackingSearchFeedback, error.message, "error");
  renderEmptyState(maintenanceList, error.message);
  renderEmptyState(notificationsList, error.message);
  renderEmptyState(virtualDealershipClientList, error.message);
});

if (state.activeView === "virtual-dealership") {
  loadVirtualDealership().catch(() => {
    // Keep dashboard usable if virtual dealership fetch fails during initial boot.
  });
}

setupInfiniteScroll();
setupVirtualDealershipInfiniteScroll();

if (feedContainer) {
  loadFeedPage({ reset: true }).catch((error) => {
    renderEmptyState(feedContainer, error.message);
    if (feedLoadingState) {
      feedLoadingState.textContent = error.message;
    }
  });
}
bindOrderExperience();
bindSequoiaConfigurator();