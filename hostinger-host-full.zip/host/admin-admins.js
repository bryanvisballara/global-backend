(() => {
  if (window.__adminAdminsScriptInitialized) {
    return;
  }

  window.__adminAdminsScriptInitialized = true;

  const {
    attachLogout,
    canCreateAdministrativeUsers,
    fetchJson,
    loadAdminSession,
    requireAdminAccess,
    setFeedback,
  } = window.AdminApp;

  if (!requireAdminAccess()) {
    return;
  }

  attachLogout();

  const createForm = document.getElementById("admin-create-form");
  const createCard = document.getElementById("admin-create-card");
  const managerWarning = document.getElementById("admin-manager-warning");
  const nameInput = document.getElementById("admin-create-name");
  const emailInput = document.getElementById("admin-create-email");
  const passwordInput = document.getElementById("admin-create-password");
  const roleRow = document.getElementById("admin-create-role-row");
  const roleSegment = document.getElementById("admin-create-role-segment");
  const submitButton = document.getElementById("admin-create-submit");
  const usersBody = document.getElementById("admin-users-body");
  const usersCount = document.getElementById("admin-users-count");
  const feedback = document.getElementById("admin-users-feedback");

  let currentRole = "";
  let currentUserId = "";

  const LATAM_CREATE_ROLES = [
    { value: "admin", label: "Administrador" },
    { value: "mechanic", label: "Mantenimiento" },
    { value: "vigilance", label: "Vigilancia" },
    { value: "brokerUSA", label: "Broker USA" },
  ];

  const USA_CREATE_ROLES = [
    { value: "adminUSA", label: "Administrador USA" },
    { value: "brokerUSA", label: "Broker USA" },
    { value: "mechanic", label: "Mantenimiento" },
    { value: "vigilance", label: "Vigilancia" },
  ];

  function escapeHtml(value) {
    return String(value || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function formatDate(value) {
    if (!value) {
      return "-";
    }

    return new Date(value).toLocaleDateString("es-CO", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
  }

  function formatRoleLabel(role) {
    const labels = {
      manager: "Gerente",
      gerenteUSA: "Gerente USA",
      admin: "Administrador",
      adminUSA: "Administrador USA",
      brokerUSA: "Broker USA",
      mechanic: "Mantenimiento",
      vigilance: "Vigilancia",
    };

    return labels[String(role || "").trim()] || String(role || "-");
  }

  function getCreatableRoles() {
    if (currentRole === "manager") {
      return LATAM_CREATE_ROLES;
    }

    if (currentRole === "gerenteUSA") {
      return USA_CREATE_ROLES;
    }

    return [];
  }

  function getDefaultRoleValue() {
    return getCreatableRoles()[0]?.value || "";
  }

  function getRoleInputs() {
    return Array.from(document.querySelectorAll('input[name="admin-create-role"]'));
  }

  function getSelectedAdministrativeRole() {
    const allowed = getCreatableRoles().map((item) => item.value);
    const checked = getRoleInputs().find((input) => input.checked);
    const value = String(checked?.value || "").trim();

    if (allowed.includes(value)) {
      return value;
    }

    return getDefaultRoleValue();
  }

  function setSelectedAdministrativeRole(role) {
    const allowed = getCreatableRoles().map((item) => item.value);
    const nextRole = allowed.includes(String(role || "").trim())
      ? String(role).trim()
      : getDefaultRoleValue();

    getRoleInputs().forEach((input) => {
      input.checked = input.value === nextRole;
    });
  }

  function renderRoleOptions(preferredRole = "") {
    if (!roleSegment) {
      return;
    }

    const options = getCreatableRoles();

    if (!options.length) {
      roleSegment.innerHTML = "";
      return;
    }

    const selected = options.some((item) => item.value === preferredRole)
      ? preferredRole
      : options[0].value;

    roleSegment.innerHTML = options
      .map(
        (item) => `
          <label class="admin-role-choice">
            <input type="radio" name="admin-create-role" value="${escapeHtml(item.value)}" ${item.value === selected ? "checked" : ""} />
            <span>${escapeHtml(item.label)}</span>
          </label>
        `
      )
      .join("");
  }

  function getRequestedAdministrativeRole() {
    if (currentRole === "gerenteUSA" || currentRole === "manager") {
      return getSelectedAdministrativeRole();
    }

    return "";
  }

  function canManageAdministrativeUsers() {
    return typeof canCreateAdministrativeUsers === "function"
      ? canCreateAdministrativeUsers(currentRole)
      : ["manager", "gerenteUSA"].includes(currentRole);
  }

  function canDeleteAdministrativeUser(user) {
    const userId = String(user?._id || user?.id || "").trim();
    const userRole = String(user?.role || "").trim();

    if (!canManageAdministrativeUsers() || !userId || userId === currentUserId) {
      return false;
    }

    if (currentRole === "manager") {
      return ["admin", "mechanic", "vigilance", "brokerUSA"].includes(userRole);
    }

    if (currentRole === "gerenteUSA") {
      return ["adminUSA", "brokerUSA", "mechanic", "vigilance"].includes(userRole);
    }

    return false;
  }

  async function deleteAdministrativeUserRequest(administrativeUserId) {
    const candidatePaths = [
      `/api/admin/users/admins/${encodeURIComponent(administrativeUserId)}`,
      `/api/admin/admins/${encodeURIComponent(administrativeUserId)}`,
    ];

    let lastError = null;

    for (const path of candidatePaths) {
      try {
        return await fetchJson(path, {
          method: "DELETE",
          loadingMessage: "Eliminando administrador...",
        });
      } catch (error) {
        lastError = error;

        if (!/route not found/i.test(String(error?.message || ""))) {
          throw error;
        }
      }
    }

    throw lastError || new Error("No se pudo eliminar el administrador.");
  }

  function renderUsers(users) {
    const list = Array.isArray(users) ? users : [];

    usersCount.textContent = `${list.length} usuario(s)`;

    if (!list.length) {
      usersBody.innerHTML = '<tr><td colspan="6"><div class="empty-state">No hay usuarios administrativos creados.</div></td></tr>';
      return;
    }

    usersBody.innerHTML = list
      .map((user) => {
        const isActive = user.isActive !== false;
        const userId = String(user._id || user.id || "").trim();
        const canDelete = canDeleteAdministrativeUser(user);
        const deleteCellMarkup = canDelete
          ? `<button class="admin-user-delete-button" type="button" data-delete-admin-id="${escapeHtml(userId)}" data-delete-admin-name="${escapeHtml(user.name || user.email || "administrador")}" aria-label="Eliminar administrador">x</button>`
          : '<span class="admin-user-delete-placeholder">-</span>';

        return `
          <tr>
            <td data-label="Nombre">${escapeHtml(user.name || "-")}</td>
            <td data-label="Email">${escapeHtml(user.email || "-")}</td>
            <td data-label="Rol">${escapeHtml(formatRoleLabel(user.role))}</td>
            <td data-label="Estado">${isActive ? "Activo" : "Inactivo"}</td>
            <td data-label="Creado">${escapeHtml(formatDate(user.createdAt))}</td>
            <td data-label="Acciones" class="admin-users-actions-cell">${deleteCellMarkup}</td>
          </tr>
        `;
      })
      .join("");
  }

  async function loadAdministrativeUsers() {
    const data = await fetchJson("/api/admin/users/admins", {
      loadingMessage: "Cargando usuarios administrativos...",
    });

    renderUsers(data.users || []);
  }

  function updateCreateAvailability() {
    const canCreateAdmins = canManageAdministrativeUsers();
    const canPickRole = ["manager", "gerenteUSA"].includes(currentRole);
    const previousRole = getSelectedAdministrativeRole();

    if (createCard) {
      createCard.hidden = !canCreateAdmins;
    }

    if (managerWarning) {
      managerWarning.hidden = canCreateAdmins;
    }

    if (submitButton) {
      submitButton.disabled = !canCreateAdmins;
    }

    if (roleRow) {
      roleRow.hidden = !canPickRole;
    }

    if (canPickRole) {
      renderRoleOptions(previousRole || getDefaultRoleValue());
    } else if (roleSegment) {
      roleSegment.innerHTML = "";
    }
  }

  createForm?.addEventListener("submit", async (event) => {
    event.preventDefault();

    const canCreateAdmins = canManageAdministrativeUsers();

    if (!canCreateAdmins) {
      setFeedback(feedback, "Solo un rol de gerente puede crear administradores.", "error");
      return;
    }

    const name = String(nameInput?.value || "").trim();
    const email = String(emailInput?.value || "").trim();
    const password = String(passwordInput?.value || "");
    const role = getRequestedAdministrativeRole();

    if (!name || !email || !password) {
      setFeedback(feedback, "Completa nombre, email y contraseña.", "error");
      return;
    }

    if (!role) {
      setFeedback(feedback, "Selecciona un tipo de usuario.", "error");
      return;
    }

    submitButton.disabled = true;
    setFeedback(feedback, "Creando administrador...");

    try {
      await fetchJson("/api/admin/users/admins", {
        method: "POST",
        body: JSON.stringify({ name, email, password, role }),
        loadingMessage: "Creando administrador...",
      });

      createForm.reset();
      updateCreateAvailability();
      setFeedback(feedback, "Usuario administrativo creado correctamente.", "success");
      await loadAdministrativeUsers();
    } catch (error) {
      setFeedback(feedback, error.message, "error");
    } finally {
      submitButton.disabled = false;
    }
  });

  usersBody?.addEventListener("click", async (event) => {
    const deleteButton = event.target.closest("[data-delete-admin-id]");

    if (!deleteButton) {
      return;
    }

    const administrativeUserId = String(deleteButton.getAttribute("data-delete-admin-id") || "").trim();
    const administrativeUserName = String(deleteButton.getAttribute("data-delete-admin-name") || "este administrador").trim();

    if (!administrativeUserId || !canManageAdministrativeUsers()) {
      setFeedback(feedback, "No tienes permisos para eliminar administradores.", "error");
      return;
    }

    const isConfirmed = window.confirm(`¿Seguro que quieres eliminar a ${administrativeUserName}?`);

    if (!isConfirmed) {
      return;
    }

    deleteButton.disabled = true;
    setFeedback(feedback, "Eliminando administrador...");

    try {
      await deleteAdministrativeUserRequest(administrativeUserId);

      setFeedback(feedback, "Administrador eliminado correctamente.", "success");
      await loadAdministrativeUsers();
    } catch (error) {
      deleteButton.disabled = false;
      setFeedback(feedback, error.message, "error");
    }
  });

  loadAdminSession()
    .then((user) => {
      currentRole = String(user?.role || "");
      currentUserId = String(user?._id || user?.id || "").trim();
      updateCreateAvailability();
      return loadAdministrativeUsers();
    })
    .catch((error) => {
      usersBody.innerHTML = `<tr><td colspan="6"><div class="empty-state">${escapeHtml(error.message || "No se pudo cargar la sesión administrativa")}</div></td></tr>`;
      setFeedback(feedback, error.message || "No se pudieron cargar los usuarios administrativos.", "error");
    });
})();
